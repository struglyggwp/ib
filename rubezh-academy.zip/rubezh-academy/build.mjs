import { randomBytes, pbkdf2Sync } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { Script } from 'node:vm';

const settings = new URL('admin.local.json', import.meta.url);
const isDemoEmail = value => typeof value === 'string' && /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i.test(value);
const args = process.argv.slice(2);
if (args.length) {
  const [action, address] = args;
  if (action !== '--setup-admin' || args.length !== 2 || !isDemoEmail(address)) {
    throw new Error('Используйте node build.mjs --setup-admin admin@example.test');
  }
  const email = address.toLowerCase();
  const password = randomBytes(18).toString('base64url');
  const salt = randomBytes(16).toString('hex');
  const hash = pbkdf2Sync(password,salt,210000,32,'sha256').toString('hex');
  try {
    await writeFile(settings,JSON.stringify({email,salt,hash},null,2) + '\n',{flag:'wx',mode:0o600});
  } catch (error) {
    if (error.code === 'EEXIST') throw new Error('Локальный администратор уже настроен. Запустите обычную сборку командой node build.mjs.');
    throw error;
  }
  console.log('Почта локального администратора ' + email);
  console.log('Сохраните сгенерированный учебный пароль ' + password);
}

let privateAdmin = null;
try {
  const {email,salt,hash} = JSON.parse(await readFile(settings,'utf8'));
  if (!isDemoEmail(email) ||
      typeof salt !== 'string' || !/^[a-f0-9]{32}$/.test(salt) ||
      typeof hash !== 'string' || !/^[a-f0-9]{64}$/.test(hash)) {
    throw new Error('Некорректные настройки локального администратора.');
  }
  privateAdmin = {email,salt,hash};
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}

const read = name => readFile(new URL(name,import.meta.url));
const [template,core,incidents,flows,style,hero] = await Promise.all(
  ['template.html','app-core.js','incidents.js','app-flows.js','style.css','hero.jpg'].map(read),
);
const source = [core,incidents,flows].map(part => part.toString('utf8')).join('\n');
const css = style.toString('utf8') + '\n:root{--hero-art:url(data:image/jpeg;base64,' + hero.toString('base64') + ')}';
const marker = '/* LOCAL_ADMIN */ null';
if (!source.includes(marker)) throw new Error('В исходниках отсутствует настройка локального администратора.');

async function build(directory, administrator) {
  const js = source.replace(marker,() => JSON.stringify(administrator));
  new Script(js,{filename:'academy.js'});
  const html = template.toString('utf8').replace('/* STYLE */',() => css).replace('/* APP */',() => js);
  await mkdir(new URL(directory + '/',import.meta.url),{recursive:true});
  await writeFile(new URL(directory + '/index.html',import.meta.url),html);
}

await build('dist',null);
if (privateAdmin) {
  await build('dist-local',privateAdmin);
  console.log('Версия с локальным администратором доступна в dist-local/index.html');
}
