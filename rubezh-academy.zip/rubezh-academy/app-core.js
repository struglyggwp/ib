
const paths = {
  shield:'<path d="M12 22s7-3.5 7-10V5l-7-3-7 3v7c0 6.5 7 10 7 10Z"/><path d="m9 12 2 2 4-4"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  book:'<path d="M12 6c-2.6-2.1-6-2.4-9-1v14c3-1.4 6.4-1.1 9 1 2.6-2.1 6-2.4 9-1V5c-3-1.4-6.4-1.1-9 1v14"/>',
  chart:'<path d="M3 3v18h18M8 16v-4m5 4V7m5 9v-7"/>',
  tools:'<path d="M4 7h16M4 17h16"/><rect x="7" y="4" width="4" height="6" rx="1"/><rect x="14" y="14" width="4" height="6" rx="1"/>',
  help:'<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 1 1 4.8 2.4c-1.1.8-1.9 1.3-1.9 2.6m0 3h.01"/>',
  alert:'<path d="M10.3 4.7 3 18a1.5 1.5 0 0 0 1.3 2.2h15.4A1.5 1.5 0 0 0 21 18L13.7 4.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4m0 3h.01"/>',
  laptop:'<rect x="5" y="4" width="14" height="12" rx="2"/><path d="m5 15-2 4h18l-2-4"/>',
  bell:'<path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 10h18c0-2-3-2-3-10m-8 13h4"/>',
  down:'<path d="m6 9 6 6 6-6"/>', right:'<path d="m9 6 6 6-6 6"/>', arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>', back:'<path d="M20 12H5m6 6-6-6 6-6"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>',
  file:'<path d="M13 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10z"/><path d="M13 3v7h7M8 14h8m-8 3h5"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a17 17 0 0 1 0 18 17 17 0 0 1 0-18Z"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18m-13 4h2m3 0h2m-7 3h2"/>',
  check:'<path d="m5 12 4 4L19 6"/>', plus:'<path d="M12 5v14M5 12h14"/>', x:'<path d="m6 6 12 12M6 18 18 6"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  edit:'<path d="m14 5 5 5M4 20l4-.8L20 7a2 2 0 0 0-3-3L5 16z"/>',
  trash:'<path d="M4 7h16m-10 0V4h4v3m4 0-1 13H7L6 7m4 4v5m4-5v5"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  building:'<path d="M4 21h16M6 21V4h12v17M10 8h.01M14 8h.01M10 12h.01M14 12h.01m-4 9v-4h4v4"/>',
  exit:'<path d="M10 17l5-5-5-5m5 5H3m12-8h5v16h-5"/>',
  user:'<circle cx="12" cy="8" r="3"/><path d="M5 20v-2a7 7 0 0 1 14 0v2"/>',
};
const icon = name => `<svg class="icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${paths[name] || paths.book}</svg>`;
const themes = {
  mail:{ title:'Почта и фишинг', color:'green' },
  lock:{ title:'Учётные записи', color:'blue' },
  file:{ title:'Защита данных', color:'violet' },
  globe:{ title:'Работа вне офиса', color:'amber' },
  shield:{ title:'Базовая безопасность', color:'green' },
};
const demo = { id:'demo', name:'Алексей Морозов', email:'employee@example.test' };
const localAdmin = /* LOCAL_ADMIN */ null;
const adminDemo = {
  id:'portal-admin-demo',
  name:'Администратор портала',
  email:localAdmin?.email || '',
  salt:localAdmin?.salt || '',
  hash:localAdmin?.hash || '',
};
const domainDemo = { id:'domain-demo', name:'Доменный сотрудник', email:'employee@corp.example' };

function relativeDate(offset) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const parts = [date.getFullYear(), date.getMonth() + 1, date.getDate()];
  return parts.map((part, index) => index ? String(part).padStart(2,'0') : part).join('-');
}

const seedCourses = [
  { id:'phishing', title:'Как распознать фишинг', theme:'mail', duration:25, required:true, due:relativeDate(7), status:'published',
    description:'Научитесь распознавать подозрительные письма, ссылки и запросы.',
    lesson:'Начните с проверки отправителя. Сравните полный адрес с корпоративным справочником, особенно если письмо просит срочно оплатить счёт или передать данные.\n\nЕсли письмо ведёт на страницу входа, откройте известный вам корпоративный портал из закладок. При неожиданной просьбе коллеги уточните её через привычный рабочий канал.\n\nСообщите о подозрительном письме через принятый в компании канал службы ИБ. При возможности используйте штатную кнопку сообщения о фишинге.',
    quiz:['В письме просят срочно войти по ссылке и обновить пароль. Что сделать?','Открыть корпоративный портал из закладок и сообщить о письме в службу ИБ.','Перейти по ссылке и сразу ввести пароль.'] },
  { id:'passwords', title:'Пароли и многофакторная аутентификация', theme:'lock', duration:20, required:true, due:relativeDate(14), status:'published',
    description:'Разберитесь, как защищать рабочие аккаунты и подтверждать вход.',
    lesson:'Используйте разные надёжные пароли для рабочих сервисов и храните их в одобренном менеджере паролей. Подключите многофакторную аутентификацию согласно правилам предприятия.\n\nПодтверждайте только тот запрос MFA, который вызвали сами. При неожиданном запросе отклоните его и сообщите о событии в службу ИБ.',
    quiz:['Вы получили неожиданный запрос на подтверждение входа. Что сделать?','Отклонить запрос и сообщить о событии.','Подтвердить запрос, чтобы закрыть уведомление.'] },
  { id:'data', title:'Работа с корпоративными данными', theme:'file', duration:35, required:true, due:relativeDate(21), status:'published',
    description:'Выбирайте подходящие инструменты для хранения и передачи рабочих файлов.',
    lesson:'Перед отправкой документа проверьте его категорию, список получателей и правила подразделения. Для хранения и передачи используйте корпоративные сервисы с нужным уровнем доступа.\n\nВыдавайте сотрудникам доступ к рабочим файлам на срок и в объёме, необходимом для задачи. Уточняйте правила для персональных данных у ответственного подразделения.',
    quiz:['Как передать рабочий документ коллеге?','Использовать согласованный сервис и выдать доступ конкретному получателю.','Опубликовать ссылку с доступом для всех.'] },
  { id:'remote', title:'Безопасная работа вне офиса', theme:'globe', duration:15, required:false, due:'', status:'published',
    description:'Повседневные меры защиты для удалённой работы и командировок.',
    lesson:'На выезде защищайте экран от посторонних взглядов и блокируйте устройство, когда отходите. Подключайтесь к рабочим ресурсам по утверждённой корпоративной инструкции.\n\nО потере рабочего устройства оперативно сообщите службе ИБ через предусмотренный канал.',
    quiz:['Что сделать, отходя от рабочего ноутбука в общественном месте?','Заблокировать экран и держать устройство при себе.','Оставить ноутбук открытым на столе.'] },
  { id:'basics', title:'Основы информационной безопасности', theme:'shield', duration:30, required:false, due:'', status:'published',
    description:'Базовые правила безопасной работы в компании.',
    lesson:'Блокируйте экран, когда оставляете рабочее место. Регулярно устанавливайте обновления по утверждённому процессу. Пользуйтесь корпоративными каналами связи.\n\nЕсли вы заметили подозрительную активность, запишите время и обстоятельства и сообщите о событии службе ИБ.',
    quiz:['Ваш рабочий компьютер ведёт себя необычно. Как поступить?','Сообщить о событии в службу ИБ через принятый канал.','Ждать, пока проблема повторится у коллег.'] },
];

const app = document.querySelector('#app');
const modal = document.querySelector('#modal');
const toast = document.querySelector('#toast');
const storeKey = 'rubezh-academy-v1';
const initialState = { courses:seedCourses, users:[], progress:{demo:{phishing:60, remote:100, basics:100}}, session:demo };
function loadState() {
  try {
    const saved = localStorage.getItem(storeKey);
    return saved ? JSON.parse(saved) : initialState;
  } catch {
    return initialState;
  }
}
let state = loadState();
let persistenceFailed = false;
let screen = 'overview';
let authView = 'login';
let courseId = '';
let signInCourseId = '';
let courseReturn = {screen:'catalog'};
let statusFilter = 'all';
let courseSearch = '';
let menu = '';
let navOpen = false;
let toastTimer;

const esc = value => String(value ?? '').replace(/[&<>"']/g, char => (
  {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]
));
const courses = () => state.courses.filter(c => c.status === 'published');
const completed = id => state.progress[state.session?.id]?.[id] || 0;
const findCourse = id => state.courses.find(c => c.id === id);
const canAdminister = () => Boolean(adminDemo.email)
  && state.session?.id === adminDemo.id && state.session.email === adminDemo.email;
function viewableCourse(id) {
  const course = findCourse(id);
  return course && (course.status === 'published' || canAdminister()) ? course : null;
}
const courseHash = id => `#course/${encodeURIComponent(id)}`;
const courseLink = (id, label, classes, symbol = '') =>
  `<a href="${courseHash(id)}" class="${classes}" data-action="lesson" data-id="${esc(id)}">${esc(label)}${symbol ? icon(symbol) : ''}</a>`;
const dayFormat = new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long'});
const fmtDate = value => { const date = new Date(`${value}T12:00:00`); return date.getFullYear() === new Date().getFullYear() ? dayFormat.format(date) : date.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'}); };
const earliest = () => courses().filter(c => c.due && completed(c.id) < 100).sort((a,b) => a.due.localeCompare(b.due))[0];
const brand = (extra = '') => `<button type="button" class="brand ${extra}" data-action="home"><span class="brand-mark">${icon('shield')}</span><span><strong>Рубеж Академия</strong><small>Обучение безопасности</small></span></button>`;
const button = (label, action, style = 'light', symbol = '', after = false, id = '') =>
  `<button type="button" class="btn btn-${style}" data-action="${action}"${id ? ` data-id="${esc(id)}"` : ''}>${symbol && !after ? icon(symbol) : ''}${esc(label)}${symbol && after ? icon(symbol) : ''}</button>`;
const linkButton = (label, action, id = '') => `<button type="button" class="text-btn" data-action="${action}"${id ? ` data-id="${esc(id)}"` : ''}>${esc(label)} ${icon('arrow')}</button>`;
const iconButton = (label, action, symbol, id = '', extra = '') => `<button type="button" title="${esc(label)}" aria-label="${esc(label)}" class="icon-button ${extra}" data-action="${action}"${id ? ` data-id="${esc(id)}"` : ''}>${icon(symbol)}</button>`;
function notify(message) {
  clearTimeout(toastTimer);
  toast.textContent = persistenceFailed ? `${message} Хранилище браузера недоступно.` : message;
  toastTimer = setTimeout(() => {toast.textContent = '';}, 4000);
}
function save() {
  try {
    localStorage.setItem(storeKey, JSON.stringify(state));
    persistenceFailed = false;
  } catch {
    persistenceFailed = true;
  }
}
const labels = {overview:'Обзор',catalog:'Каталог курсов',progress:'Мой прогресс',incidents:'Что делать, если…',admin:'Управление курсами',course:'Курс'};
const listScreens = new Set(['overview','catalog','progress','admin']);
const routeByHash = {'#overview':'overview','#catalog':'catalog','#progress':'progress','#incidents':'incidents','#admin':'admin','#login':'auth','#register':'auth'};
function navigate(next, {mode = 'login', replace = false, id = '', returnTo, list} = {}) {
  if (!state.session && next !== 'auth') next = 'auth';
  if (next === 'admin' && !canAdminister()) next = 'overview';
  screen = next;
  authView = mode;
  signInCourseId = next === 'auth' ? id : '';
  courseId = next === 'course' ? id : '';
  courseReturn = listScreens.has(returnTo?.screen) ? returnTo : {screen:'catalog'};
  statusFilter = list?.filter || 'all';
  courseSearch = list?.search || '';
  menu = '';
  navOpen = false;
  if (modal.open) modal.close();
  writeRoute(replace, list);
  render();
  window.scrollTo(0,0);
  app.querySelector('#course-title')?.focus({preventScroll:true});
}

function enterCourse(id) {
  const from = listScreens.has(screen)
    ? {screen, list:{filter:statusFilter, search:courseSearch}}
    : courseReturn;
  if (listScreens.has(screen)) rememberListView(from.list);
  navigate('course',{id, returnTo:from});
}

function writeRoute(replace, list) {
  const hash = screen === 'course' ? courseHash(courseId)
    : screen === 'auth' ? `#${authView}${signInCourseId ? `?course=${encodeURIComponent(signInCourseId)}` : ''}`
    : `#${screen}`;
  const details = {list, returnTo:screen === 'course' ? courseReturn : undefined};
  if (replace || location.hash === hash) history.replaceState(details,'',hash);
  else history.pushState(details,'',hash);
  document.title = screen === 'course'
    ? `${viewableCourse(courseId)?.title || 'Курс недоступен'} · Рубеж Академия`
    : 'Рубеж Академия · Обучение ИБ';
}
function rememberListView(list) {
  history.replaceState({list},'');
}
function readCourseHash(path) {
  try {
    return decodeURIComponent(path.slice('#course/'.length));
  } catch {
    return '';
  }
}
function selectHash() {
  const [path, query] = location.hash.split('?');
  const isCourse = path.startsWith('#course/');
  const isAuth = routeByHash[path] === 'auth';
  const id = isCourse ? readCourseHash(path) : isAuth ? new URLSearchParams(query).get('course') || '' : '';
  const next = isCourse ? 'course' : isAuth && state.session ? (id ? 'course' : 'overview')
    : routeByHash[path] || (state.session ? 'overview' : 'auth');
  const {list, returnTo} = history.state || {};
  navigate(next, {mode:path === '#register' ? 'register' : 'login', id, list, returnTo, replace:true});
}

function navigation(page, symbol) {
  const current = screen === page ? ' aria-current="page"' : '';
  return `<button type="button" class="nav-btn" data-action="nav" data-id="${page}"${current}>${icon(symbol)}${labels[page]}</button>`;
}
function renderMenu() {
  if (menu === 'profile') return `<div class="popover" id="top-menu">
    <button type="button" data-action="logout">${icon('exit')}Выйти из кабинета</button></div>`;
  if (menu !== 'notifications') return '';
  const due = earliest();
  return `<div class="popover" id="top-menu"><h3>Уведомления</h3>${due
    ? `<a class="notification-course" href="${courseHash(due.id)}" data-action="lesson" data-id="${esc(due.id)}">${icon('calendar')}<span>${esc(due.title)}<br><small>Срок до ${fmtDate(due.due)}</small></span></a>`
    : '<p>Новых уведомлений нет.</p>'}</div>`;
}
function shell() {
  const name = state.session.name;
  const initials = name.trim().split(/\s+/).slice(0,2).map(part => part[0]).join('').toLocaleUpperCase('ru-RU');
  return `<div class="app">
    <aside class="rail" id="rail" data-open="${navOpen}">${brand()}
      <nav class="nav" aria-label="Разделы портала">
        <p class="nav-label">ОБУЧЕНИЕ</p>
        ${navigation('overview','grid')}${navigation('catalog','book')}${navigation('progress','chart')}
        ${navigation('incidents','alert')}
        ${canAdminister() ? `<p class="nav-label second">АДМИНИСТРИРОВАНИЕ</p>${navigation('admin','tools')}` : ''}
      </nav>
      <div class="rail-footer"><button type="button" class="nav-btn" data-action="help">${icon('help')}Помощь</button><p class="rail-caption">Демонстрационный портал</p></div>
    </aside>
    <div class="main">
      <header class="topbar">
        <button type="button" aria-label="Открыть меню" aria-controls="rail" aria-expanded="${navOpen}" class="icon-button mobile-toggle" data-action="menu">${icon('menu')}</button>
        <div class="crumb"><span class="crumb-first">Учебный портал</span>${icon('right')}<b>${labels[screen]}</b></div>
        <div class="top-actions">
          <button type="button" aria-label="Уведомления" aria-expanded="${menu === 'notifications'}" class="icon-button ${earliest() ? 'notification' : ''}" data-action="notifications">${icon('bell')}</button>
          <button type="button" class="profile" aria-label="Профиль ${esc(name)}" aria-expanded="${menu === 'profile'}" data-action="profile"><span class="avatar">${esc(initials)}</span><span><strong>${esc(name)}</strong><small>${canAdminister() ? 'Администратор · Демо' : 'Сотрудник'}</small></span>${icon('down')}</button>
          ${renderMenu()}
        </div>
      </header>
      <main class="content" id="main-content"></main>
    </div>
  </div>`;
}

function progressNumbers() {
  const list = courses();
  const done = list.filter(c => completed(c.id) === 100).length;
  const started = list.filter(c => completed(c.id) > 0 && completed(c.id) < 100).length;
  return { done, started, waiting:list.length-done-started, percent:list.length ? Math.round(done/list.length*100) : 0 };
}
function progressPanel(withLink = true) {
  const {done, started, waiting, percent} = progressNumbers();
  return `<section class="panel progress-panel">
    <h2>Мой прогресс</h2><p class="panel-lead">По всем доступным курсам</p>
    <div class="progress-core"><div class="ring" style="--p:${percent}%" aria-label="Завершено ${percent}%"><strong>${percent}%</strong></div>
      <div class="progress-facts"><div><span class="dot"></span>Завершено <strong>${done}</strong></div><div><span class="dot live"></span>В процессе <strong>${started}</strong></div><div><span class="dot wait"></span>Не начато <strong>${waiting}</strong></div></div>
    </div>
    ${withLink ? `<div class="panel-bottom">${linkButton('Подробнее о прогрессе','nav','progress')}</div>` : ''}
  </section>`;
}
function dashboard() {
  const first = state.session.name.split(/\s+/)[0];
  const pending = earliest();
  const recommended = courses().find(c => completed(c.id) > 0 && completed(c.id) < 100) || pending || courses().find(c => completed(c.id) === 0);
  const cta = recommended
    ? courseLink(recommended.id,completed(recommended.id) ? 'Продолжить обучение' : 'Начать обучение','btn btn-mint','arrow')
    : button('Открыть каталог','nav','mint','arrow',true,'catalog');
  return `<section class="hero">
      <div class="hero-copy"><p class="hero-label">${icon('shield')} Информационная безопасность</p><h1>Здравствуйте, ${esc(first)}!</h1>
      <p>Пройдите назначенные курсы и закрепите навыки безопасной работы.</p>${cta}</div>
    </section>
    <div class="dashboard">
      <section><div class="section-head"><div><h2>Мои курсы</h2><p>Назначенные и начатые курсы</p></div>${linkButton('Открыть каталог','nav','catalog')}</div>
        <div id="course-tabs">${courseTabs()}</div><div id="course-list" class="course-list">${courseList()}</div>
      </section><aside class="stack">${progressPanel()}
        <section class="panel deadline-panel"><span class="calendar-icon">${icon('calendar')}</span><div><h3>Ближайший срок</h3>${pending
          ? `<p>До ${fmtDate(pending.due)}</p>${courseLink(pending.id,pending.title,'text-btn','arrow')}`
          : '<p>Курсов с предстоящим сроком нет.</p>'}</div>
        </section>
        <section class="panel deadline-panel incident-shortcut"><span class="calendar-icon">${icon('alert')}</span>
          <div><h3>Заметили инцидент?</h3><p>Первые действия и связь со службой ИБ.</p>
          ${linkButton('Открыть памятки','nav','incidents')}</div>
        </section>
      </aside>
    </div>`;
}
function courseTabs() {
  return `<div class="tabs" role="group" aria-label="Статус курса">${[
    ['all','Все курсы'],['live','В процессе'],['done','Завершены'],
  ].map(([key,label]) => `<button type="button" class="tab" aria-pressed="${statusFilter === key}" data-action="filter" data-id="${key}">${label}</button>`).join('')}</div>`;
}
function courseRow(course) {
  const value = completed(course.id);
  const {color} = themes[course.theme] || themes.shield;
  const action = value === 100 ? 'Повторить' : value ? 'Продолжить' : 'Начать';
  return `<article class="course-row"><span class="course-icon ${color}">${icon(course.theme)}</span><div>
    <h3>${courseLink(course.id,course.title,'course-name')}</h3>
    ${courseMetadata(course,value)}
    ${value > 0 && value < 100 ? `<div class="mini-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${value}" aria-label="Прогресс по курсу"><div class="track"><span style="width:${value}%"></span></div><span>${value}%</span></div>` : ''}
    </div><div class="course-action">${courseLink(course.id,action,`btn btn-${value > 0 && value < 100 ? 'primary' : 'light'}`)}</div>
  </article>`;
}
function courseMetadata(course, value) {
  const badge = course.status === 'draft' ? '<span class="badge draft">Черновик</span>'
    : value === 100 ? '<span class="badge done">Завершён</span>'
    : course.required ? '<span class="badge must">Обязательный</span>' : '';
  return `<div class="course-meta"><span>${icon('clock')}${course.duration} мин</span>
    ${course.due ? `<span>${icon('calendar')}До ${fmtDate(course.due)}</span>` : ''}${badge}
  </div>`;
}
function courseList() {
  const query = courseSearch.trim().toLocaleLowerCase('ru-RU');
  return courses().filter(course => {
    const value = completed(course.id);
    if (screen === 'overview' && !course.required && !value) return false;
    if (screen === 'progress' && !value && !course.required) return false;
    if (statusFilter === 'live' && (value === 0 || value === 100)) return false;
    if (statusFilter === 'done' && value !== 100) return false;
    return `${course.title} ${course.description}`.toLocaleLowerCase('ru-RU').includes(query);
  }).map(courseRow).join('') || '<p class="panel empty">Подходящих курсов пока нет.</p>';
}
function head(title, about, action = '') {
  return `<header class="page-head"><div><h1>${esc(title)}</h1><p>${esc(about)}</p></div>${action}</header>`;
}
function catalog(isProgress = false) {
  return `${isProgress
    ? `${head('Мой прогресс','Отслеживайте прохождение и возвращайтесь к начатым курсам.')}<div class="wide-progress">${progressPanel(false)}</div>`
    : head('Каталог курсов','Найдите курс по информационной безопасности и начните обучение.')}
    <div class="catalog-tools"><div id="course-tabs">${courseTabs()}</div>${isProgress ? '' : `<label class="search">${icon('search')}<input type="search" id="search" placeholder="Найти курс" aria-label="Поиск по курсам" value="${esc(courseSearch)}"></label>`}</div>
    <div class="course-list catalog-list" id="course-list">${courseList()}</div>`;
}
function admin() {
  const rows = state.courses.map(course => `<tr>
    <td>${courseLink(course.id,course.title,'course-name')}</td><td>${esc(themes[course.theme]?.title || themes.shield.title)}</td>
    <td><span class="badge ${course.status === 'published' ? 'live' : 'draft'}">${course.status === 'published' ? 'Опубликован' : 'Черновик'}</span></td>
    <td>${course.duration} мин</td><td class="table-actions">
    ${iconButton(`Редактировать: ${course.title}`,'edit','edit',course.id)}
    ${iconButton(`Удалить: ${course.title}`,'delete','trash',course.id,'danger')}</td>
  </tr>`).join('');
  return `${head('Управление курсами','Создавайте материалы, публикуйте их для сотрудников и обновляйте программу.',button('Добавить курс','add','primary','plus'))}
    <p class="admin-caption">Курсов в каталоге · ${state.courses.length}</p>
    ${rows ? `<div class="panel table-wrap admin"><table><thead><tr><th scope="col">Название курса</th><th scope="col">Тема</th><th scope="col">Статус</th><th scope="col">Длительность</th><th scope="col">Действия</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p class="panel empty">Курсов пока нет. Добавьте первый курс.</p>'}`;
}
