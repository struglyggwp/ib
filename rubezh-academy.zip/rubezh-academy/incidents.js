const incidentGuides = [
  {
    id:'phishing', title:'Подозрительное письмо', icon:'mail', color:'green',
    steps:[
      'Не отвечайте на письмо, не переходите по ссылкам и не открывайте вложения.',
      'Воспользуйтесь кнопкой «Сообщить о фишинге» в рабочей почте, если она доступна. Иначе свяжитесь со службой ИБ через корпоративный канал.',
      'Сохраните письмо до ответа службы ИБ. Если перешли по ссылке или открыли вложение, сообщите об этом сразу.',
    ],
    details:'Укажите отправителя, тему письма, время получения и действия, которые вы уже выполнили.',
  },
  {
    id:'clicked', title:'Открыли ссылку или вложение', icon:'globe', color:'blue',
    steps:[
      'Прекратите взаимодействие со страницей или файлом. Если страница просит данные, закройте её.',
      'Сразу сообщите службе ИБ, что успели сделать. Уточните, если открыли или запустили файл, ввели пароль либо подтвердили вход.',
      'Если ввели пароль, после сообщения в ИБ смените его через известный корпоративный портал с другого доверенного устройства или следуйте инструкции службы ИБ.',
    ],
    details:'Укажите устройство, время и адрес страницы, если он уже известен. Оставьте пароли и коды подтверждения при себе.',
  },
  {
    id:'mfa', title:'Неожиданный запрос MFA', icon:'lock', color:'violet',
    steps:[
      'Отклоните запрос, если вы в этот момент не входили в рабочую систему.',
      'Отметьте запрос как подозрительный в приложении аутентификации, если там есть такая функция.',
      'Сообщите службе ИБ через корпоративный канал. Если запрос уже подтверждён, скажите об этом сразу.',
    ],
    details:'Укажите рабочую учётную запись, время запроса и подтвердили ли вы вход. Коды MFA держите при себе.',
  },
  {
    id:'lost-device', title:'Потеряли рабочее устройство', icon:'laptop', color:'amber',
    steps:[
      'Как можно скорее сообщите о пропаже службе ИБ с другого устройства.',
      'Вспомните, где и когда видели устройство в последний раз, и было ли оно заблокировано.',
      'Согласуйте со службой ИБ блокировку устройства и действия с рабочей учётной записью.',
    ],
    details:'Укажите тип устройства, инвентарный номер, если он известен, последнее известное местоположение и номер для обратной связи.',
  },
  {
    id:'wrong-recipient', title:'Отправили файл не тому адресату', icon:'file', color:'violet',
    steps:[
      'Если отправили ссылку на файл, отзовите доступ у ошибочного получателя, когда это позволяет корпоративный сервис.',
      'Сразу сообщите службе ИБ. Если отправили вложение, уточните это при обращении.',
      'Сохраните сведения об отправке и согласуйте со службой ИБ дальнейшие действия.',
    ],
    details:'Укажите получателя, время отправки, тип сведений и текущий статус доступа. Описания файла достаточно для первого сообщения.',
  },
];
let activeIncidentId = incidentGuides[0].id;

function incidentsPage() {
  const selected = incidentGuides.find(guide => guide.id === activeIncidentId);
  const choices = incidentGuides.map(guide =>
    `<button type="button" class="incident-choice" id="incident-${guide.id}" data-action="incident-topic" data-id="${guide.id}" aria-pressed="${guide === selected}">
      <span class="course-icon ${guide.color}">${icon(guide.icon)}</span><span>${esc(guide.title)}</span>${icon('right')}
    </button>`).join('');
  return `${head(labels.incidents,'Первые действия при инцидентах информационной безопасности.')}
    <div class="incidents-layout">
      <div class="panel incident-index" role="group" aria-label="Ситуации">${choices}</div>
      <div class="incident-details">
        <article class="panel incident-card" aria-labelledby="incident-title">
          <div class="incident-heading"><span class="course-icon ${selected.color}">${icon(selected.icon)}</span><h2 id="incident-title">${esc(selected.title)}</h2></div>
          <h3>Что сделать сейчас</h3>
          <ol class="incident-steps">${selected.steps.map(step => `<li>${esc(step)}</li>`).join('')}</ol>
          <div class="incident-report-details"><h3>Что указать при обращении</h3><p>${esc(selected.details)}</p></div>
        </article>
        ${incidentContactPanel()}
      </div>
    </div>`;
}

function incidentContactPanel() {
  const {channel, email, phone} = state.incidentContact || {};
  const channels = [
    channel ? `<div><dt>Внутренний канал</dt><dd>${esc(channel)}</dd></div>` : '',
    email ? `<div><dt>Почта</dt><dd><a href="mailto:${esc(encodeURIComponent(email).replaceAll('%40','@'))}">${esc(email)}</a></dd></div>` : '',
    phone ? `<div><dt>Телефон</dt><dd>${esc(phone)}</dd></div>` : '',
  ].filter(Boolean).join('');
  return `<section class="panel incident-contact">
    <div class="incident-contact-head"><h2>Связаться со службой ИБ</h2>
      ${canAdminister() ? button('Настроить контакт','incident-settings','light','edit') : ''}</div>
    ${channels ? `<dl class="incident-channel-list">${channels}</dl>`
      : '<p>Контакт в портале ещё не настроен. Найдите службу ИБ во внутреннем справочнике предприятия.</p>'}
  </section>`;
}

function selectIncident(id) {
  if (!incidentGuides.some(guide => guide.id === id)) return;
  activeIncidentId = id;
  render();
  app.querySelector(`#incident-${id}`)?.focus({preventScroll:true});
}

function editIncidentContact() {
  if (!canAdminister()) return;
  const {channel, email, phone} = state.incidentContact || {};
  openModal('Контакт службы ИБ','Укажите корпоративный канал, почту или телефон. Контакт появится во всех памятках.',
    `<form id="incident-contact-form" class="form-grid">
      <label class="field">Внутренний канал<input name="channel" maxlength="160" value="${esc(channel)}" placeholder="Например, Service Desk → Информационная безопасность"></label>
      <label class="field">Почта<input name="email" type="email" maxlength="120" value="${esc(email)}"></label>
      <label class="field">Телефон или внутренний номер<input name="phone" type="tel" maxlength="50" value="${esc(phone)}"></label>
      <div class="dialog-actions">${button('Отмена','close')}<button type="submit" class="btn btn-primary">Сохранить контакт</button></div>
    </form>`);
}

function saveIncidentContact(data) {
  if (!canAdminister()) return;
  state.incidentContact = {
    channel:data.get('channel').trim(),
    email:data.get('email').trim(),
    phone:data.get('phone').trim(),
  };
  save();
  modal.close();
  render();
  app.querySelector('[data-action="incident-settings"]')?.focus();
  notify('Контакт службы ИБ сохранён.');
}
