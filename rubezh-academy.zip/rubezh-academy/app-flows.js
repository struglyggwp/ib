
function auth() {
  const isRegister = authView === 'register';
  return `<div class="auth"><aside class="auth-art">${brand()}<h2>Безопасность начинается с привычек</h2><p>Корпоративный портал обучения информационной безопасности.</p></aside>
    <main class="auth-main"><div class="auth-card">${brand('mobile-brand')}
      <h1>${isRegister ? 'Регистрация' : 'Вход в кабинет'}</h1><p>${isRegister ? 'Создайте учебную учётную запись, чтобы сохранять свой прогресс.' : 'Войдите, чтобы открыть назначенные курсы и продолжить обучение.'}</p>
      <div class="tabs" role="group" aria-label="Способ доступа"><button type="button" class="tab" aria-pressed="${!isRegister}" data-action="auth" data-id="login">Вход</button><button type="button" class="tab" aria-pressed="${isRegister}" data-action="auth" data-id="register">Регистрация</button></div>
      <form class="form-grid" id="auth-form">
        ${isRegister ? '<label class="field">Имя и фамилия<input name="name" placeholder="Алексей Морозов" maxlength="60" autocomplete="name" required></label>' : ''}
        <label class="field">Учебная почта<input name="email" type="email" placeholder="employee@example.test" maxlength="100" autocomplete="username" required></label>
        <label class="field">Учебный пароль<input name="password" type="password" autocomplete="${isRegister ? 'new-password' : 'current-password'}" minlength="8" maxlength="128" required>${isRegister ? '<small>От 8 символов</small>' : ''}</label>
        <p class="error" role="alert"></p><button type="submit" class="btn btn-primary">${isRegister ? 'Зарегистрироваться' : 'Войти'}</button>
      </form>
      <div class="divider">или</div>
      ${button('Войти с доменной учётной записью','domain','light','building')}
      <button type="button" class="btn btn-light auth-link" data-action="demo">${icon('user')}Открыть демо-кабинет</button>
      <p class="auth-help">Для проверки используйте вымышленные данные. Демо-записи хранятся в этом браузере.</p>
    </div></main></div>`;
}
function render() {
  if (!state.session || screen === 'auth') {
    app.innerHTML = auth();
    return;
  }
  app.innerHTML = shell();
  app.querySelector('#main-content').innerHTML = screen === 'overview' ? dashboard()
    : screen === 'admin' ? admin() : screen === 'course' ? coursePage()
    : screen === 'incidents' ? incidentsPage() : catalog(screen === 'progress');
}
function openModal(title, description, body) {
  modal.innerHTML = `<div class="dialog-box"><header class="dialog-heading"><div><h2 id="modal-title">${esc(title)}</h2>${description ? `<p>${esc(description)}</p>` : ''}</div>${iconButton('Закрыть','close','x')}</header>${body}</div>`;
  if (!modal.open) modal.showModal();
}
function domain() {
  openModal('Вход через домен', 'Демонстрация корпоративного входа. Данные реальной учётной записи не требуются.',
    `<form id="domain-form" class="form-grid">
      <label class="field">Демонстрационная учётная запись
        <select name="account"><option value="employee">employee@corp.example</option></select></label>
      <div class="dialog-actions">${button('Отмена','close')}<button class="btn btn-primary" type="submit">${icon('building')}Войти в демо</button></div>
    </form>`);
}
function help() {
  openModal('Помощь', '', `<div class="lesson-body">Чтобы пройти назначенный курс, откройте раздел «Мои курсы» и выберите нужный материал. Результат сохранится после проверки знаний.\n\nПервые действия при инциденте и контакт службы ИБ находятся в разделе «Что делать, если…».</div>
    <div class="dialog-actions lesson-actions">${button('Закрыть','close','primary')}</div>`);
}
function courseExit(label, classes, extra = '') {
  return `<a href="#${courseReturn.screen}" class="${classes}" data-action="leave-course" ${extra}>${icon('back')}${esc(label)}</a>`;
}
function coursePage() {
  const course = viewableCourse(courseId);
  const exitLabels = {
    overview:'Назад к обзору',
    catalog:'Назад в каталог',
    progress:'Назад к моему прогрессу',
    admin:'Назад к управлению курсами',
  };
  const back = courseExit(exitLabels[courseReturn.screen], 'text-btn course-back');
  if (!course) {
    return `${back}<header class="page-head"><div><h1 id="course-title" tabindex="-1">Курс недоступен</h1>
      <p>Возможно, курс удалён или ещё не опубликован.</p></div></header>`;
  }
  const value = completed(course.id);
  const isDraft = course.status === 'draft';
  const theme = themes[course.theme] || themes.shield;
  const study = isDraft ? ''
    : value === 100 ? `<div class="course-actions">${courseExit('К списку курсов', 'btn btn-light', 'id="course-finished"')}</div>`
    : lessonForm(course);
  return `<article class="course-page" aria-labelledby="course-title">${back}
    <header class="panel course-header">
      <span class="course-icon ${theme.color}">${icon(course.theme)}</span>
      <div><p class="course-topic">${esc(theme.title)}</p>
        <h1 id="course-title" tabindex="-1">${esc(course.title)}</h1>
        <p class="course-description">${esc(course.description)}</p>
        ${courseMetadata(course,value)}
      </div>
    </header>
    <div class="course-page-grid">
      <div class="course-study">
        <section class="panel course-reading"><h2>Материал курса</h2>
          <div class="lesson-body">${esc(course.lesson)}</div>
        </section>${study}
      </div>
      <aside class="panel course-progress">${isDraft
        ? '<h2>Публикация</h2><p class="panel-lead">Курс появится в каталоге сотрудников после публикации.</p>'
        : `<h2>Прогресс по курсу</h2><div class="course-progress-value"><span>${value === 100 ? 'Завершён' : value ? 'В процессе' : 'Не начат'}</span><strong>${value}%</strong></div>
          <div class="track" role="progressbar" aria-label="Прогресс по курсу" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${value}"><span style="width:${value}%"></span></div>`}
      </aside>
    </div>
  </article>`;
}
function lessonForm(course) {
  const quiz = course.quiz;
  const questions = quiz ? `<fieldset class="course-question"><legend>Проверка знаний</legend><p>${esc(quiz[0])}</p>
    ${(course.id.length % 2 ? [2,1] : [1,2]).map(entry => `<label class="check"><input type="radio" name="answer" value="${entry}" required><span>${esc(quiz[entry])}</span></label>`).join('')}</fieldset>` : '';
  return `<form class="panel course-assessment" id="lesson-form" data-id="${esc(course.id)}">${questions}
    <p class="error" role="alert"></p><div class="course-actions">
      ${button('Сохранить и выйти','pause','light','',false,course.id)}
      <button type="submit" class="btn btn-primary">${icon('check')}${quiz ? 'Проверить ответ' : 'Завершить курс'}</button>
    </div></form>`;
}
function editor(id) {
  if (!canAdminister()) return;
  const c = id ? findCourse(id) : null;
  if (id && !c) return;
  const quiz = c?.quiz || [];
  openModal(c ? 'Редактировать курс' : 'Добавить курс','Опубликованные курсы сразу появятся в каталоге сотрудников.',
    `<form id="course-form" class="form-grid" data-id="${esc(id)}">
      <label class="field">Название<input name="title" maxlength="110" required value="${esc(c?.title)}"></label>
      <div class="fields-2">
        <label class="field">Тема<select name="theme">${Object.entries(themes).map(([key,theme]) => `<option value="${key}"${c?.theme === key ? ' selected' : ''}>${esc(theme.title)}</option>`).join('')}</select></label>
        <label class="field">Длительность, мин<input name="duration" type="number" min="1" max="600" value="${c?.duration || 20}" required></label>
      </div>
      <label class="field">Краткое описание<textarea name="description" rows="2" maxlength="350" required>${esc(c?.description)}</textarea></label>
      <label class="field">Материал курса<textarea name="lesson" rows="3" maxlength="6500" required>${esc(c?.lesson)}</textarea></label>
      <details><summary>Вопрос для проверки знаний</summary><div class="form-grid" style="margin-top:8px">
        <label class="field">Вопрос<input name="question" maxlength="240" value="${esc(quiz[0])}"></label>
        <label class="field">Верный вариант<input name="correct" maxlength="180" value="${esc(quiz[1])}"></label>
        <label class="field">Неверный вариант<input name="incorrect" maxlength="180" value="${esc(quiz[2])}"></label>
      </div></details>
      <div class="fields-2">
        <label class="field">Статус<select name="status"><option value="draft">Черновик</option><option value="published"${c?.status === 'published' ? ' selected' : ''}>Опубликован</option></select></label>
        <label class="field">Срок прохождения<input name="due" type="date" value="${esc(c?.due)}"></label>
      </div>
      <label class="check"><input name="required" type="checkbox"${c?.required ? ' checked' : ''}> Обязательный для сотрудников</label>
      <p class="error" role="alert"></p><div class="dialog-actions">${button('Отмена','close')}
        <button class="btn btn-primary" type="submit">Сохранить курс</button></div>
    </form>`);
}
function deleteCourse(id) {
  if (!canAdminister()) return;
  const c = findCourse(id);
  if (!c) return;
  openModal('Удалить курс?', `«${c.title}» будет удалён вместе с результатами прохождения.`,
    `<div class="dialog-actions">${button('Отмена','close')}${button('Удалить курс','confirm-delete','danger','trash',false,id)}</div>`);
}
function setProgress(id, value) {
  const key = state.session.id;
  state.progress[key] ||= {};
  state.progress[key][id] = Math.max(completed(id), value);
  save();
}
function updateRows() {
  const list = document.querySelector('#course-list');
  if (list) list.innerHTML = courseList();
}
function toggleTop(action) {
  menu = menu === action ? '' : action;
  render();
  app.querySelector(`[data-action="${action}"]`)?.focus();
}
function useSession(account) {
  const id = account ? signInCourseId : '';
  state.session = account;
  save();
  const next = account ? (canAdminister() ? 'admin' : 'overview') : 'auth';
  navigate(id ? 'course' : next, {id, replace:true});
}
function handleClick(event) {
  const target = event.target.closest('[data-action]');
  if (!target) {
    if (menu && !event.target.closest('.top-actions') && !modal.open) {
      menu = '';
      render();
    }
    if (navOpen && !event.target.closest('.rail')) {
      navOpen = false;
      render();
    }
    return;
  }
  const {action,id} = target.dataset;
  if (target instanceof HTMLAnchorElement) {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
  }
  switch (action) {
    case 'home': if (state.session) navigate('overview'); else navigate('auth',{id:signInCourseId}); break;
    case 'nav': navigate(id); break;
    case 'menu': navOpen = !navOpen; render(); break;
    case 'profile':
    case 'notifications': toggleTop(action); break;
    case 'filter':
      statusFilter = id;
      document.querySelectorAll('[data-action="filter"]').forEach(tab => tab.setAttribute('aria-pressed',String(tab.dataset.id === id)));
      updateRows();
      break;
    case 'logout': useSession(null); break;
    case 'auth': navigate('auth',{mode:id, id:signInCourseId}); break;
    case 'demo': useSession(demo); break;
    case 'domain': domain(); break;
    case 'help': help(); break;
    case 'incident-topic': selectIncident(id); break;
    case 'incident-settings': editIncidentContact(); break;
    case 'lesson': enterCourse(id); break;
    case 'leave-course': navigate(courseReturn.screen,courseReturn); break;
    case 'pause':
      setProgress(id,50);
      navigate(courseReturn.screen,courseReturn);
      notify('Прогресс сохранён.');
      break;
    case 'add': editor(); break;
    case 'edit': editor(id); break;
    case 'delete': deleteCourse(id); break;
    case 'confirm-delete':
      if (!canAdminister()) break;
      state.courses = state.courses.filter(c => c.id !== id);
      for (const progress of Object.values(state.progress)) delete progress[id];
      save();
      modal.close();
      render();
      notify('Курс удалён.');
      break;
    case 'close': modal.close(); break;
  }
}
function report(form, message) {
  form.querySelector('.error').textContent = message;
}
function demoRandom(bytes = 16) {
  return Array.from(crypto.getRandomValues(new Uint8Array(bytes)), byte => byte.toString(16).padStart(2,'0')).join('');
}
async function derive(password,salt) {
  const encoding = new TextEncoder();
  const key = await crypto.subtle.importKey('raw',encoding.encode(password),'PBKDF2',false,['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2',salt:encoding.encode(salt),iterations:210000,hash:'SHA-256'},key,256);
  return Array.from(new Uint8Array(bits), byte => byte.toString(16).padStart(2,'0')).join('');
}
async function authSubmit(form, data) {
  const isRegister = authView === 'register';
  const email = data.get('email').trim().toLowerCase();
  const password = data.get('password');
  const usesAdminEmail = Boolean(adminDemo.email) && email === adminDemo.email;
  const employee = state.users.find(user => user.email === email);
  const submit = form.querySelector('[type="submit"]');
  if (!crypto.subtle) {
    report(form,'Браузер не поддерживает учебный вход в этом режиме. Доступен демо-кабинет.');
    return;
  }
  submit.disabled = true;
  report(form,'');
  try {
    if (isRegister) {
      if (usesAdminEmail || employee) return report(form,'Такая учебная почта уже зарегистрирована. Войдите в кабинет.');
      const name = data.get('name').trim().replace(/\s+/g,' ');
      if (name.length < 2) return report(form,'Укажите имя и фамилию.');
      const salt = demoRandom();
      const user = {id:`local-${demoRandom(8)}`, email, name};
      const hash = await derive(password,salt);
      if (!form.isConnected) return;
      state.users.push({...user,salt,hash});
      useSession(user);
      notify('Учебная учётная запись создана.');
    } else {
      const adminMatches = usesAdminEmail && await derive(password,adminDemo.salt) === adminDemo.hash;
      const existing = adminMatches ? adminDemo : employee;
      if (!existing || (!adminMatches && await derive(password,existing.salt) !== existing.hash)) {
        return report(form,'Проверьте учебную почту и пароль.');
      }
      if (!form.isConnected) return;
      useSession({id:existing.id, name:existing.name, email});
      notify('Вы вошли в кабинет.');
    }
  } catch {
    report(form,'Учебный вход временно недоступен. Попробуйте снова.');
  } finally {
    submit.disabled = false;
  }
}
function saveCourse(form, data) {
  if (!canAdminister()) return;
  const title = data.get('title').trim();
  const description = data.get('description').trim();
  const lesson = data.get('lesson').trim();
  const quiz = ['question','correct','incorrect'].map(field => data.get(field).trim());
  if (!title || !description || !lesson) return report(form,'Заполните название, описание и материал курса.');
  if (quiz.some(Boolean) && (!quiz.every(Boolean) || quiz[1].toLowerCase() === quiz[2].toLowerCase())) {
    form.querySelector('details').open = true;
    return report(form,'Заполните вопрос и два разных варианта ответа.');
  }
  const id = form.dataset.id || `course-${demoRandom(8)}`;
  const c = {
    id, title, description, lesson, quiz:quiz.every(Boolean) ? quiz : null,
    theme:data.get('theme'), status:data.get('status'), duration:Number(data.get('duration')),
    due:data.get('due'), required:data.has('required'),
  };
  state.courses = form.dataset.id ? state.courses.map(existing => existing.id === id ? c : existing) : [...state.courses,c];
  save();
  modal.close();
  render();
  notify(form.dataset.id ? 'Изменения сохранены.' : 'Курс добавлен.');
}
document.addEventListener('click',handleClick);
document.addEventListener('input',event => {
  if (event.target.id !== 'search') return;
  courseSearch = event.target.value;
  updateRows();
});
function submitPortalForm(form) {
  const data = new FormData(form);
  if (form.id === 'domain-form') {
    modal.close();
    useSession(domainDemo);
    notify('Выполнен демонстрационный вход через домен.');
  } else if (form.id === 'auth-form') {
    authSubmit(form,data);
  } else if (form.id === 'course-form') {
    saveCourse(form,data);
  } else if (form.id === 'incident-contact-form') {
    saveIncidentContact(data);
  } else if (form.id === 'lesson-form') {
    const id = form.dataset.id;
    const course = viewableCourse(id);
    if (screen !== 'course' || id !== courseId || course?.status !== 'published') return;
    if (course.quiz && data.get('answer') !== '1') {
      report(form,'Ответ неверный. Вернитесь к материалу и попробуйте ещё раз.');
      return;
    }
    setProgress(id,100);
    render();
    app.querySelector('#course-finished')?.focus();
    notify('Курс завершён. Прогресс обновлён.');
  }
}
document.addEventListener('submit',event => {
  const form = event.target;
  if (!['domain-form','auth-form','course-form','lesson-form','incident-contact-form'].includes(form.id)) return;
  event.preventDefault();
  submitPortalForm(form);
});
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape' || modal.open) return;
  if (menu || navOpen) {
    const action = menu || 'menu';
    menu = '';
    navOpen = false;
    render();
    app.querySelector(`[data-action="${action}"]`)?.focus();
  }
});
window.addEventListener('popstate',selectHash);
selectHash();
