import os

from django import forms
from django.db.models import Q

from email_templates.models import EmailTemplate
from employees.models import Department, Employee
from landing_pages.models import LandingPage
from .models import Campaign, CampaignParticipant
from scenarios.models import Scenario


class AudienceSelect(forms.SelectMultiple):
    def value_from_datadict(self, data, files, name):
        values = super().value_from_datadict(data, files, name)
        # Older forms submit one empty option when no recipients are selected.
        if isinstance(values, (list, tuple)):
            return [value for value in values if value != ""]
        return values


class AddCampaignMembersForm(forms.Form):
    employees = forms.ModelMultipleChoiceField(
        label="Добавить сотрудников", queryset=Employee.objects.none(),
        widget=forms.SelectMultiple(attrs={"class": "form-select", "size": 10}),
        help_text="Чтобы выбрать несколько сотрудников, удерживайте Ctrl или ⌘.",
    )

    def __init__(self, *args, campaign=None, **kwargs):
        super().__init__(*args, **kwargs)
        existing = CampaignParticipant.objects.filter(campaign=campaign).values_list("employee_id", flat=True) if campaign else []
        self.fields["employees"].queryset = Employee.objects.filter(is_active=True).exclude(pk__in=existing).order_by("last_name", "first_name", "email")


class CampaignForm(forms.ModelForm):
    manual_fields = ("sender_email", "email_template", "landing_page")

    scenario = forms.ModelChoiceField(
        label="Сценарий проверки", queryset=Scenario.objects.none(), required=False,
        empty_label="Без сценария",
        widget=forms.Select(attrs={"class": "form-select"}),
        help_text="Готовый сценарий задаёт письмо, отправителя и учебную страницу.",
    )
    employees = forms.ModelMultipleChoiceField(
        label="Сотрудники", queryset=Employee.objects.none(), required=False,
        widget=AudienceSelect(attrs={"class": "form-select", "size": 6}),
        help_text="Чтобы выбрать несколько сотрудников, удерживайте Ctrl или ⌘.",
    )
    departments = forms.ModelMultipleChoiceField(
        label="Подразделения", queryset=Department.objects.none(), required=False,
        widget=AudienceSelect(attrs={"class": "form-select", "size": 6}),
        help_text="Добавляет всех активных сотрудников выбранных подразделений.",
    )

    class Meta:
        model = Campaign
        fields = ("scenario", "name", "description", "sender_email", "email_template", "landing_page", "employees", "departments")
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Название учебной кампании"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "sender_email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "training@your-domain.test"}),
            "email_template": forms.Select(attrs={"class": "form-select"}),
            "landing_page": forms.Select(attrs={"class": "form-select"}),
        }
        labels = {"name": "Название", "description": "Описание", "sender_email": "Отправитель (From)", "email_template": "Шаблон учебного письма", "landing_page": "Учебная HTML-страница (необязательно)"}
        help_texts = {"sender_email": "Для Zimbra нужна авторизованная идентичность SMTP. В Mailpit допустим любой тестовый адрес: почта не выходит наружу."}

    def __init__(self, *args, scenario=None, allow_scenarios=True, **kwargs):
        super().__init__(*args, **kwargs)
        current_scenario_id = self.instance.scenario_id if self.instance.pk and not self.instance._state.adding else None
        self.show_scenario_picker = allow_scenarios or bool(current_scenario_id)
        if self.is_bound and self.data.get(self.add_prefix("scenario")):
            # The scenario supplies these values, including when an older form
            # POSTs stale or invalid values for the manual controls.
            self.data = self.data.copy()
            for name in self.manual_fields:
                self.data.pop(self.add_prefix(name), None)
        allowed = Scenario.objects.filter(status=Scenario.Status.READY)
        if current_scenario_id:
            allowed = Scenario.objects.filter(Q(status=Scenario.Status.READY) | Q(pk=current_scenario_id))
        if not allow_scenarios:
            allowed = Scenario.objects.filter(pk=current_scenario_id) if current_scenario_id else Scenario.objects.none()
        self.fields["scenario"].queryset = allowed.select_related("email_template", "landing_page").distinct().order_by("name")
        if scenario is not None:
            self.fields["scenario"].initial = scenario.pk
        # A scenario prefills the form; on POST it is also saved and frozen as a snapshot.
        if scenario is not None and (not self.instance.pk or self.instance._state.adding):
            self.fields["name"].initial = scenario.name
            self.fields["description"].initial = scenario.description
            self.fields["sender_email"].initial = scenario.sender_email or os.environ.get("SMTP_FROM_EMAIL", "")
            self.fields["email_template"].initial = scenario.email_template_id
            self.fields["landing_page"].initial = scenario.landing_page_id
            self.fields["employees"].initial = list(scenario.employees.filter(is_active=True).values_list("pk", flat=True))
            self.fields["departments"].initial = list(scenario.departments.filter(is_active=True).values_list("pk", flat=True))
        current = list(self.instance.participants.values_list("employee_id", flat=True)) if self.instance.pk and not self.instance._state.adding else []
        self.fields["employees"].queryset = Employee.objects.filter(Q(is_active=True) | Q(pk__in=current)).distinct().order_by("last_name", "first_name")
        self.fields["departments"].queryset = Department.objects.filter(is_active=True).order_by("name")
        self.fields["email_template"].queryset = EmailTemplate.objects.filter(
            Q(status=EmailTemplate.Status.ACTIVE) | Q(pk=self.instance.email_template_id)
        ).distinct().order_by("name")
        self.fields["landing_page"].queryset = LandingPage.objects.filter(
            Q(active=True) | Q(pk=self.instance.landing_page_id)
        ).distinct().order_by("name")
        if self.instance.pk and not self.instance._state.adding:
            self.fields["employees"].initial = current
        elif scenario is None:
            self.fields["sender_email"].initial = os.environ.get("SMTP_FROM_EMAIL", "")

    def clean_landing_page(self):
        page = self.cleaned_data.get("landing_page")
        if page is not None and not page.active:
            raise forms.ValidationError("Выберите активную учебную страницу.")
        return page

    def clean(self):
        data = super().clean()
        scenario = data.get("scenario")
        if scenario is not None:
            if scenario.status != Scenario.Status.READY:
                self.add_error("scenario", "Выберите готовый сценарий.")
            template = scenario.email_template
            if template is None or template.status != EmailTemplate.Status.ACTIVE or not (template.html_body.strip() or template.text_body.strip()):
                self.add_error("scenario", "У сценария должен быть активный шаблон письма с содержимым.")
            if scenario.landing_page and not scenario.landing_page.active:
                self.add_error("scenario", "Учебная страница сценария отключена.")
            # Ignore posted overrides: scenario is the source of email content, sender and landing page.
            data["email_template"] = template
            data["landing_page"] = scenario.landing_page
            data["sender_email"] = scenario.sender_email or os.environ.get("SMTP_FROM_EMAIL", "")
            if not data.get("description"):
                data["description"] = scenario.description
        if not self.errors.get("employees") and not self.errors.get("departments"):
            direct = data.get("employees")
            departments = data.get("departments")
            has_direct = direct is not None and direct.filter(is_active=True).exists()
            has_department_staff = (departments is not None and
                                    Employee.objects.filter(is_active=True, department__in=departments).exists())
            if not has_direct and not has_department_staff:
                self.add_error("employees", "Выберите хотя бы одного активного сотрудника или подразделение с сотрудниками.")
        return data

    def audience_ids(self):
        direct = set(self.cleaned_data["employees"].filter(is_active=True).values_list("pk", flat=True))
        departments = list(self.cleaned_data["departments"].values_list("pk", flat=True))
        if departments:
            direct.update(Employee.objects.filter(is_active=True, department_id__in=departments).values_list("pk", flat=True))
        return direct
