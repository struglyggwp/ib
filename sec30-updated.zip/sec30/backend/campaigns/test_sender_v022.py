"""Regression tests for explicit From selection and one-click campaign sending."""
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse
from campaigns.models import Campaign, CampaignParticipant
from campaigns.launch import launch_campaign
from delivery.models import CampaignDispatch
from employees.models import Employee
from email_templates.models import EmailTemplate

ENV = {
    'SMTP_HOST':'mailpit','SMTP_PORT':'1025','SMTP_FROM_EMAIL':'default@training.test',
    'SMTP_ALLOWED_RECIPIENT_DOMAINS':'training.test','SMTP_CAMPAIGN_ENABLED':'1',
    'SIMULATION_LOCAL_BASE_URL':'http://127.0.0.1:8080',
}
class SenderSelectionTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_superuser('sender-test','admin@training.test','SafeTestPassword123!')
        self.template=EmailTemplate.objects.create(name='Тест',subject='Тест',text_body='Тестовое письмо',status='active',created_by=self.user)
        self.employee=Employee.objects.create(first_name='А',last_name='Б',email='employee@training.test')

    @patch.dict('os.environ',ENV)
    def test_form_accepts_sender_and_launch_records_it(self):
        self.client.force_login(self.user)
        res=self.client.post(reverse('campaign_create'),{
            'name':'Выбор From','email_template':str(self.template.pk),
            'sender_email':'notifications@local.example', 'employees':[self.employee.pk],
        })
        self.assertEqual(res.status_code,302)
        campaign=Campaign.objects.get(name='Выбор From')
        self.assertEqual(campaign.sender_email,'notifications@local.example')
        with self.captureOnCommitCallbacks(execute=False):
            result=self.client.post(reverse('campaign_start',args=[campaign.pk]))
        self.assertEqual(result.status_code,302)
        self.assertEqual(CampaignDispatch.objects.get(campaign=campaign).sender,'notifications@local.example')

    @patch.dict('os.environ',{**ENV,'SMTP_HOST':'mail.corp.test','SMTP_USERNAME':'real@company.test'})
    def test_zimbra_disallows_unknown_sender(self):
        campaign=Campaign.objects.create(name='Тест',email_template=self.template,created_by=self.user,sender_email='arbitrary@other.tld')
        CampaignParticipant.objects.create(campaign=campaign,employee=self.employee)
        with self.assertRaises(ValidationError):
            launch_campaign(campaign.pk,self.user)
        self.assertFalse(CampaignDispatch.objects.exists())

    @patch.dict('os.environ',{**ENV,'SMTP_HOST':'mail.corp.test','SMTP_USERNAME':'real@company.test','SMTP_AUTHORIZED_FROM_ADDRESSES':'notifications@company.test', 'SIMULATION_PUBLIC_BASE_URL':'https://training.corp.example', 'SIMULATION_ALLOWED_LINK_HOSTS':'training.corp.example'})
    def test_zimbra_authorized_alias_is_accepted(self):
        campaign=Campaign.objects.create(name='Тест2',email_template=self.template,created_by=self.user,sender_email='notifications@company.test')
        CampaignParticipant.objects.create(campaign=campaign,employee=self.employee)
        dispatch,_=launch_campaign(campaign.pk,self.user)
        self.assertEqual(dispatch.sender,'notifications@company.test')
