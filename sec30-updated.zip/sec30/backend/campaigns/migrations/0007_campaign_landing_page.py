from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("landing_pages", "0001_initial"),
        ("campaigns", "0006_participantevent_email_open_signal"),
    ]
    operations = [
        migrations.AddField(
            model_name="campaign",
            name="landing_page",
            field=models.ForeignKey(
                to="landing_pages.landingpage", verbose_name="Учебная HTML-страница",
                on_delete=django.db.models.deletion.PROTECT, related_name="campaigns",
                null=True, blank=True,
            ),
        ),
    ]
