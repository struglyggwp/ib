from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("campaigns", "0009_campaign_sender_email"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.AddField(
            model_name="campaign", name="deleted_at",
            field=models.DateTimeField("Удалена из интерфейса", null=True, blank=True, db_index=True),
        ),
        migrations.AddField(
            model_name="campaign", name="deleted_by",
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL, related_name="deleted_awareness_campaigns", null=True, blank=True, on_delete=django.db.models.deletion.PROTECT),
        ),
    ]
