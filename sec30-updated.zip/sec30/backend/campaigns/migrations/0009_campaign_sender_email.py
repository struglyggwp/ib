from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [("campaigns", "0008_participantevent_page_interacted")]
    operations = [
        migrations.AddField(
            model_name="campaign",
            name="sender_email",
            field=models.EmailField(blank=True, help_text="Адрес почтовой учётной записи или разрешённой ей идентичности", max_length=254, verbose_name="Адрес отправителя"),
        ),
    ]
