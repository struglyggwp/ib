"""Operator lifecycle for a controlled employee training campaign."""
from datetime import timedelta

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from delivery.models import CampaignDispatch, DeliveryRecord, DispatchAudit
from delivery.policy import campaign_enabled, limits, validate_destination, validate_sender
from delivery.service import stop_dispatch
from employees.models import Employee
from .models import Campaign, CampaignParticipant, TrainingLink


@transaction.atomic
def add_campaign_members(campaign_id, employee_ids, actor):
    """Add selected, allowed employees without re-sending to existing recipients.

    The dispatch row lock serializes membership changes with Celery claiming and
    finalizing its queue. If the SMTP queue already finished, reopen ONLY the
    newly added recipients' pending records.
    """
    requested = set(employee_ids)
    if not requested:
        raise ValidationError("Выберите хотя бы одного нового сотрудника.")

    # Lock dispatch first, matching the task's lock order, then campaign.
    dispatch = CampaignDispatch.objects.select_for_update().select_related("domain").filter(campaign_id=campaign_id).first()
    campaign = Campaign.objects.select_for_update().get(pk=campaign_id)
    if campaign.deleted_at is not None or campaign.status == Campaign.Status.CANCELLED:
        raise ValidationError("Кампания удалена или остановлена.")
    if dispatch:
        if campaign.status != Campaign.Status.RUNNING or dispatch.state == CampaignDispatch.State.STOPPED:
            raise ValidationError("Добавлять адресатов можно только в выполняющуюся кампанию.")
        if not campaign_enabled():
            raise ValidationError("Отправка SMTP отключена настройками.")
        if not dispatch.domain.active:
            raise ValidationError("Домен отправителя отключён.")
        validate_sender(dispatch.domain, dispatch.sender)
    elif campaign.status not in (Campaign.Status.DRAFT, Campaign.Status.APPROVED):
        raise ValidationError("У этой кампании нельзя изменить список участников.")

    selected = list(Employee.objects.filter(pk__in=requested, is_active=True))
    if {item.pk for item in selected} != requested:
        raise ValidationError("В списке есть несуществующий или неактивный сотрудник.")
    existing = set(CampaignParticipant.objects.filter(campaign=campaign).values_list("employee_id", flat=True))
    fresh = [item for item in selected if item.pk not in existing]
    if not fresh:
        raise ValidationError("Эти сотрудники уже участвуют в кампании.")
    maximum, _ = limits()
    if len(existing) + len(fresh) > maximum:
        raise ValidationError(f"Превышен лимит сотрудников кампании: {maximum}.")
    if dispatch and any(not validate_destination(item.email) for item in fresh):
        raise ValidationError("Адрес сотрудника вне разрешённых получателей SMTP.")

    now = timezone.now()
    for employee in fresh:
        participant = CampaignParticipant.objects.create(campaign=campaign, employee=employee)
        if dispatch:
            TrainingLink.objects.create(participant=participant, created_by=actor, expires_at=now + timedelta(days=30))
            DeliveryRecord.objects.create(dispatch=dispatch, participant=participant, recipient_email=employee.email)

    should_enqueue = bool(dispatch and dispatch.state == CampaignDispatch.State.FINISHED)
    if dispatch:
        if should_enqueue:
            dispatch.state = CampaignDispatch.State.QUEUED
            dispatch.finished_at = None
            dispatch.save(update_fields=["state", "finished_at"])
        DispatchAudit.objects.create(dispatch=dispatch, actor=actor, action="add_members", note=f"Добавлено участников: {len(fresh)}")
    return len(fresh), str(dispatch.pk) if should_enqueue else None


@transaction.atomic
def stop_campaign_now(campaign_id, actor):
    campaign = Campaign.objects.get(pk=campaign_id)
    if campaign.deleted_at is not None:
        raise ValidationError("Кампания уже удалена.")
    if CampaignDispatch.objects.filter(campaign=campaign).exists():
        stop_dispatch(campaign_id, actor)
    else:
        Campaign.objects.filter(pk=campaign.pk).update(status=Campaign.Status.CANCELLED)
    return campaign


@transaction.atomic
def hide_campaign(campaign_id, actor):
    """Delete from the UI, retaining historical events and SMTP evidence."""
    campaign = Campaign.objects.get(pk=campaign_id)
    if campaign.deleted_at is not None:
        return campaign
    if CampaignDispatch.objects.filter(campaign=campaign).exists():
        stop_dispatch(campaign_id, actor)
    campaign.deleted_at = timezone.now()
    campaign.deleted_by = actor
    campaign.status = Campaign.Status.CANCELLED
    campaign.save(update_fields=["deleted_at", "deleted_by", "status", "updated_at"])
    return campaign


@transaction.atomic
def resume_campaign_now(campaign_id, actor):
    """Resume a stopped campaign without duplicating SMTP-accepted messages.

    Only rows blocked specifically by the operator's stop are requeued. Failed,
    accepted and ambiguous SENDING records are left untouched. The existing
    dispatch and personal links are reused, preserving historical events.
    """
    # Keep the lock order consistent with Celery tasks: dispatch, then campaign.
    dispatch = CampaignDispatch.objects.select_for_update().select_related("domain").filter(
        campaign_id=campaign_id
    ).first()
    campaign = Campaign.objects.select_for_update().get(pk=campaign_id)
    if campaign.deleted_at is not None:
        raise ValidationError("Удалённую кампанию нельзя возобновить.")
    if not dispatch or dispatch.state != CampaignDispatch.State.STOPPED or campaign.status != Campaign.Status.CANCELLED:
        raise ValidationError("Возобновить можно только остановленную кампанию с историей рассылки.")
    if not campaign_enabled():
        raise ValidationError("Рассылка отключена в настройках SMTP.")
    if not dispatch.domain.active:
        raise ValidationError("Почтовый домен отправителя отключён.")
    validate_sender(dispatch.domain, dispatch.sender)

    waiting = list(
        DeliveryRecord.objects.filter(
            dispatch=dispatch,
            status=DeliveryRecord.State.BLOCKED,
            error_code="operator_stopped",
        ).select_related("participant__employee")
    )
    if any(
        not item.participant.employee.is_active
        or item.participant.employee.email.lower() != item.recipient_email.lower()
        or not validate_destination(item.recipient_email)
        for item in waiting
    ):
        raise ValidationError("Проверьте активность сотрудников и разрешённые домены получателей.")

    restored = DeliveryRecord.objects.filter(
        pk__in=[item.pk for item in waiting],
        status=DeliveryRecord.State.BLOCKED,
        error_code="operator_stopped",
    ).update(status=DeliveryRecord.State.PENDING, error_code="")

    dispatch.state = CampaignDispatch.State.QUEUED if restored else CampaignDispatch.State.FINISHED
    dispatch.finished_at = None if restored else timezone.now()
    dispatch.save(update_fields=["state", "finished_at"])
    campaign.status = Campaign.Status.RUNNING
    campaign.save(update_fields=["status", "updated_at"])
    DispatchAudit.objects.create(
        dispatch=dispatch,
        actor=actor,
        action="operator_resumed",
        note=f"Возобновлена кампания; ожидающих писем: {restored}. Принятые SMTP письма не повторяются.",
    )
    return dispatch, restored
