from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from django.urls import reverse

from campaigns.models import Campaign, CampaignParticipant, TrainingLink
from campaigns.lifecycle import resume_campaign_now
from delivery.models import CampaignDispatch, DeliveryRecord, DispatchAudit, SimulationDomain
from delivery.service import prepare_dispatch, stop_dispatch
from email_templates.models import EmailTemplate
from employees.models import Employee

ENV = {
    "SMTP_HOST": "mailpit", "SMTP_PORT": "1025", "SMTP_CAMPAIGN_ENABLED": "1",
    "SMTP_FROM_EMAIL": "training@training.test",
    "SMTP_ALLOWED_RECIPIENT_DOMAINS": "training.test", "SIMULATION_LOCAL_BASE_URL": "http://127.0.0.1:8080",
    "SMTP_MAX_PER_CAMPAIGN": "30", "SMTP_MAX_PER_MINUTE": "10",
    "SMTP_USE_STARTTLS": "0", "SMTP_USE_SSL": "0",
}

class ResumeCampaignTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.operator = get_user_model().objects.create_superuser("resumeadmin", "admin@training.test", "LongSafePassword!881")
        cls.sender_domain = SimulationDomain.objects.create(domain="training.test",sandbox_only=True, created_by=cls.operator)
        cls.mail = EmailTemplate.objects.create(name="Урок",subject="Учебное письмо", text_body="Здравствуйте!",status="active",created_by=cls.operator)
        cls.person1 = Employee.objects.create(first_name="Анна",last_name="Иванова", email="anna@training.test")
        cls.person2 = Employee.objects.create(first_name="Борис",last_name="Петров", email="boris@training.test")
        cls.person3 = Employee.objects.create(first_name="Вера",last_name="Сидорова", email="vera@training.test")

    def create_dispatch(self, name="Возобновление"):
        campaign = Campaign.objects.create(name=name,created_by=self.operator,email_template=self.mail,status=Campaign.Status.APPROVED)
        for e in (self.person1,self.person2,self.person3):
            CampaignParticipant.objects.create(campaign=campaign, employee=e)
        dispatch = prepare_dispatch(campaign.pk,self.sender_domain.pk,self.operator)
        return campaign,dispatch

    @patch.dict("os.environ", ENV)
    def test_resume_only_queues_operator_stopped_pending(self):
        campaign,dispatch = self.create_dispatch()
        a,b,c = list(dispatch.records.order_by("pk"))
        a.status=DeliveryRecord.State.ACCEPTED; a.save(update_fields=["status"])
        c.status=DeliveryRecord.State.FAILED; c.save(update_fields=["status"])
        stop_dispatch(campaign.pk,self.operator)
        b.refresh_from_db();self.assertEqual(b.status,DeliveryRecord.State.BLOCKED)
        self.client.force_login(self.operator)
        with patch("delivery.tasks.dispatch_campaign.delay") as send, self.captureOnCommitCallbacks(execute=True):
            response=self.client.post(reverse("campaign_resume", args=[campaign.pk]))
        self.assertEqual(response.status_code,302)
        send.assert_called_once_with(str(dispatch.pk))
        campaign.refresh_from_db();dispatch.refresh_from_db()
        a.refresh_from_db();b.refresh_from_db();c.refresh_from_db()
        self.assertEqual(campaign.status,Campaign.Status.RUNNING)
        self.assertEqual(dispatch.state,CampaignDispatch.State.QUEUED)
        self.assertEqual((a.status,b.status,c.status),(DeliveryRecord.State.ACCEPTED,DeliveryRecord.State.PENDING,DeliveryRecord.State.FAILED))
        self.assertEqual(CampaignDispatch.objects.filter(campaign=campaign).count(),1)
        self.assertEqual(DeliveryRecord.objects.filter(dispatch=dispatch).count(),3)
        self.assertTrue(DispatchAudit.objects.filter(dispatch=dispatch,action="operator_resumed").exists())

    @patch.dict("os.environ", ENV)
    def test_resume_with_no_pending_only_reopens_training(self):
        campaign,dispatch=self.create_dispatch("Всё уже отправлено")
        dispatch.records.update(status=DeliveryRecord.State.ACCEPTED)
        stop_dispatch(campaign.pk,self.operator)
        self.client.force_login(self.operator)
        with patch("delivery.tasks.dispatch_campaign.delay") as send:
            response=self.client.post(reverse("campaign_resume",args=[campaign.pk]))
        self.assertEqual(response.status_code,302)
        send.assert_not_called()
        dispatch.refresh_from_db();campaign.refresh_from_db()
        self.assertEqual(dispatch.state,CampaignDispatch.State.FINISHED)
        self.assertEqual(campaign.status,Campaign.Status.RUNNING)
        self.assertFalse(DeliveryRecord.objects.filter(dispatch=dispatch,status=DeliveryRecord.State.PENDING).exists())

    @patch.dict("os.environ", ENV)
    def test_resume_cannot_run_twice_or_on_deleted_campaign(self):
        campaign,dispatch=self.create_dispatch("Никаких дублей")
        stop_dispatch(campaign.pk,self.operator)
        resume_campaign_now(campaign.pk,self.operator)
        self.client.force_login(self.operator)
        with patch("delivery.tasks.dispatch_campaign.delay") as send:
            response=self.client.post(reverse("campaign_resume",args=[campaign.pk]))
        self.assertEqual(response.status_code,302)
        send.assert_not_called()

    @patch.dict("os.environ", ENV)
    def test_deleted_campaign_cannot_resume(self):
        campaign,dispatch=self.create_dispatch("Удалена")
        stop_dispatch(campaign.pk,self.operator)
        from campaigns.lifecycle import hide_campaign
        hide_campaign(campaign.pk,self.operator)
        self.client.force_login(self.operator)
        self.assertEqual(self.client.post(reverse("campaign_resume",args=[campaign.pk])).status_code,404)

    @patch.dict("os.environ", ENV)
    def test_list_shows_resume_action(self):
        campaign,dispatch=self.create_dispatch("Остановленная")
        stop_dispatch(campaign.pk,self.operator)
        self.client.force_login(self.operator)
        response=self.client.get(reverse("campaign_list"))
        self.assertContains(response,"Продолжить")

    @patch.dict("os.environ", ENV)
    def test_resume_permissions_and_csrf(self):
        campaign,dispatch=self.create_dispatch("Роли")
        stop_dispatch(campaign.pk,self.operator)
        person=get_user_model().objects.create_user("resumeguest", password="LongSafePassword!881")
        self.client.force_login(person)
        self.assertEqual(self.client.post(reverse("campaign_resume", args=[campaign.pk])).status_code,403)
        checking=Client(enforce_csrf_checks=True)
        checking.force_login(self.operator)
        self.assertEqual(checking.post(reverse("campaign_resume",args=[campaign.pk])).status_code,403)

    def test_login_screen_branding(self):
        response=self.client.get("/admin/login/")
        self.assertEqual(response.status_code,200)
        self.assertContains(response, "Управление обучением безопасности")
        self.assertContains(response, "csrfmiddlewaretoken")
        self.assertContains(response, "name=\"password\"")
