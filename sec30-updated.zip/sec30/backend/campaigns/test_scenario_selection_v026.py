"""Scenario selection from campaign form; tests never send live email."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from campaigns.models import Campaign, CampaignParticipant
from employees.models import Department, Employee
from email_templates.models import EmailTemplate
from scenarios.models import Scenario


class CampaignScenarioSelectionTests(TestCase):
    def setUp(self):
        self.admin = get_user_model().objects.create_superuser(
            username="scenario-v026-admin", email="admin@example.test", password="test-password-for-v026"
        )
        self.client.force_login(self.admin)
        self.dept = Department.objects.create(name="Тестовый отдел")
        self.anna = Employee.objects.create(first_name="Анна", last_name="Первая", email="anna@example.test", department=self.dept)
        self.boris = Employee.objects.create(first_name="Борис", last_name="Второй", email="boris@example.test", department=self.dept)
        self.template = EmailTemplate.objects.create(
            name="Сценарное письмо", subject="Тест", html_body="<p>Учебное письмо</p>", status="active", created_by=self.admin
        )
        self.other_template = EmailTemplate.objects.create(
            name="Чужое письмо", subject="Не должно примениться", text_body="test", status="active", created_by=self.admin
        )
        self.scenario = Scenario.objects.create(
            name="Сценарий ИБ", description="Учебная фишинговая проверка", email_template=self.template,
            sender_email="training@example.test", status=Scenario.Status.READY, created_by=self.admin
        )
        self.scenario.employees.add(self.anna)

    def test_scenario_is_available_directly_in_new_campaign_form(self):
        response = self.client.get(reverse("campaign_create"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="scenario"')
        self.assertContains(response, "Сценарий ИБ")
        self.assertContains(response, "Сотрудники")

    def test_select_scenario_and_employee_with_plain_post(self):
        response = self.client.post(reverse("campaign_create"), {
            "name": "Первая кампания", "scenario": str(self.scenario.pk),
            "employees": [self.boris.pk], "departments": [],
        })
        self.assertEqual(response.status_code, 302)
        campaign = Campaign.objects.get(name="Первая кампания")
        self.assertEqual(campaign.scenario_id, self.scenario.pk)
        self.assertEqual(campaign.scenario_version, 1)
        self.assertEqual(campaign.email_template_id, self.template.pk)
        self.assertEqual(campaign.sender_email, "training@example.test")
        self.assertEqual(set(campaign.participants.values_list("employee_id", flat=True)), {self.boris.pk})

    def test_scenario_settings_override_posted_template_and_sender(self):
        response = self.client.post(reverse("campaign_create"), {
            "name": "Выбор без подмены", "scenario": str(self.scenario.pk),
            "sender_email": "forged@example.test", "email_template": str(self.other_template.pk),
            "employees": [self.anna.pk],
        })
        self.assertEqual(response.status_code, 302)
        campaign = Campaign.objects.get(name="Выбор без подмены")
        self.assertEqual(campaign.email_template_id, self.template.pk)
        self.assertEqual(campaign.sender_email, "training@example.test")

    def test_scenario_ignores_invalid_values_in_manual_fields(self):
        response = self.client.post(reverse("campaign_create"), {
            "name": "Кампания с устаревшей формой", "scenario": str(self.scenario.pk),
            "sender_email": "invalid", "email_template": "missing", "landing_page": "missing",
            "employees": [self.anna.pk],
        })
        self.assertEqual(response.status_code, 302)
        campaign = Campaign.objects.get(name="Кампания с устаревшей формой")
        self.assertEqual(campaign.email_template_id, self.template.pk)
        self.assertEqual(campaign.sender_email, self.scenario.sender_email)

    def test_query_prefill_and_legacy_post_compatibility(self):
        url = reverse("campaign_create") + "?scenario=" + str(self.scenario.pk)
        response = self.client.get(url)
        self.assertContains(response, 'name="scenario"')
        self.assertContains(response, "Сценарий ИБ")
        response = self.client.post(url, {"name": "Из сценария", "employees": [self.anna.pk]})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Campaign.objects.get(name="Из сценария").scenario_id, self.scenario.pk)

    def test_archived_scenario_is_not_accepted(self):
        self.scenario.status = Scenario.Status.ARCHIVED
        self.scenario.save(update_fields=["status"])
        response = self.client.post(reverse("campaign_create"), {
            "name": "Не создаётся", "scenario": str(self.scenario.pk), "employees": [self.anna.pk],
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Campaign.objects.filter(name="Не создаётся").exists())

    def test_new_campaign_needs_at_least_one_recipient(self):
        response = self.client.post(reverse("campaign_create"), {
            "name": "Без аудитории", "scenario": str(self.scenario.pk),
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Campaign.objects.filter(name="Без аудитории").exists())
        self.assertContains(response, "Выберите хотя бы одного активного сотрудника")

    def test_edit_draft_updates_scenario_and_employee_selection(self):
        campaign = Campaign.objects.create(name="Черновик", created_by=self.admin)
        CampaignParticipant.objects.create(campaign=campaign, employee=self.anna)
        response = self.client.post(reverse("campaign_edit", args=[campaign.pk]), {
            "name": "Черновик", "scenario": str(self.scenario.pk),
            "employees": [self.boris.pk], "departments": [],
        })
        self.assertEqual(response.status_code, 302)
        campaign.refresh_from_db()
        self.assertEqual(campaign.scenario_id, self.scenario.pk)
        self.assertEqual(set(campaign.participants.values_list("employee_id", flat=True)), {self.boris.pk})
