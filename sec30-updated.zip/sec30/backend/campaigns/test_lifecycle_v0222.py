"""Lifecycle integration tests. No real SMTP messages leave the test process."""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from campaigns.models import Campaign, CampaignParticipant, TrainingLink
from delivery.models import CampaignDispatch, DeliveryRecord, DispatchAudit, SimulationDomain
from delivery.service import prepare_dispatch
from email_templates.models import EmailTemplate
from employees.models import Employee

ENV = {
    "SMTP_HOST": "mailpit", "SMTP_PORT": "1025",
    "SMTP_FROM_EMAIL": "training@training.test",
    "SMTP_CAMPAIGN_ENABLED": "1", "SMTP_USE_STARTTLS": "0", "SMTP_USE_SSL": "0",
    "SMTP_ALLOWED_RECIPIENT_DOMAINS": "training.test",
    "SMTP_MAX_PER_CAMPAIGN": "30", "SMTP_MAX_PER_MINUTE": "3",
    "SIMULATION_LOCAL_BASE_URL": "http://127.0.0.1:8080",
}


class CampaignLifecycleTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = get_user_model().objects.create_superuser(
            "lifecycleadmin", "admin@training.test", "UniqueLongPass!4471"
        )
        cls.first = Employee.objects.create(first_name="Анна", last_name="Первая", email="anna@training.test")
        cls.second = Employee.objects.create(first_name="Борис", last_name="Второй", email="boris@training.test")
        cls.external = Employee.objects.create(first_name="Ника", last_name="Внешняя", email="nika@external.example")
        cls.template = EmailTemplate.objects.create(
            name="Тестовое письмо", subject="Учебный тест", text_body="Пройдите упражнение",
            status="active", created_by=cls.admin,
        )
        cls.domain = SimulationDomain.objects.create(
            domain="training.test", sandbox_only=True, created_by=cls.admin,
        )

    def _campaign(self, name):
        campaign = Campaign.objects.create(
            name=name, created_by=self.admin, email_template=self.template,
            status=Campaign.Status.APPROVED,
        )
        CampaignParticipant.objects.create(campaign=campaign, employee=self.first)
        return campaign

    @patch.dict("os.environ", ENV)
    def test_add_to_finished_dispatch_only_queues_new_participant(self):
        campaign = self._campaign("Уже отправлена")
        dispatch = prepare_dispatch(campaign.pk, self.domain.pk, self.admin)
        old = dispatch.records.get()
        old.status = DeliveryRecord.State.ACCEPTED
        old.save(update_fields=["status"])
        dispatch.state = CampaignDispatch.State.FINISHED
        dispatch.save(update_fields=["state"])
        self.client.force_login(self.admin)
        with patch("delivery.tasks.dispatch_campaign.delay") as send, self.captureOnCommitCallbacks(execute=True):
            result = self.client.post(reverse("campaign_members_add", args=[campaign.pk]), {
                "employees": [str(self.second.pk)],
            })
        self.assertEqual(result.status_code, 302)
        dispatch.refresh_from_db()
        self.assertEqual(dispatch.state, CampaignDispatch.State.QUEUED)
        self.assertEqual(dispatch.records.count(), 2)
        old.refresh_from_db()
        self.assertEqual(old.status, DeliveryRecord.State.ACCEPTED)
        added = dispatch.records.get(recipient_email=self.second.email)
        self.assertEqual(added.status, DeliveryRecord.State.PENDING)
        self.assertTrue(TrainingLink.objects.filter(participant=added.participant).exists())
        self.assertTrue(DispatchAudit.objects.filter(dispatch=dispatch, action="add_members").exists())
        send.assert_called_once_with(str(dispatch.pk))

    @patch.dict("os.environ", ENV)
    def test_no_duplicate_record_for_existing_employee(self):
        campaign = self._campaign("Нет дублей")
        dispatch = prepare_dispatch(campaign.pk, self.domain.pk, self.admin)
        self.client.force_login(self.admin)
        with self.captureOnCommitCallbacks(execute=False):
            response = self.client.post(reverse("campaign_members_add", args=[campaign.pk]), {
                "employees": [str(self.first.pk)],
            })
        self.assertEqual(response.status_code, 200)  # already a participant, form invalid
        self.assertEqual(dispatch.records.count(), 1)

    @patch.dict("os.environ", ENV)
    def test_different_domain_not_added_to_active_mailout(self):
        campaign = self._campaign("Ограничение получателей")
        dispatch = prepare_dispatch(campaign.pk, self.domain.pk, self.admin)
        self.client.force_login(self.admin)
        with self.captureOnCommitCallbacks(execute=False):
            response = self.client.post(reverse("campaign_members_add", args=[campaign.pk]), {
                "employees": [str(self.external.pk)],
            })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Адрес сотрудника вне разрешённых получателей SMTP.")
        self.assertEqual(dispatch.records.count(), 1)
        self.assertFalse(CampaignParticipant.objects.filter(campaign=campaign, employee=self.external).exists())

    @patch.dict("os.environ", ENV)
    def test_stop_prevents_new_outbound_queue(self):
        campaign = self._campaign("Остановка")
        dispatch = prepare_dispatch(campaign.pk, self.domain.pk, self.admin)
        self.client.force_login(self.admin)
        response = self.client.post(reverse("campaign_stop", args=[campaign.pk]))
        self.assertEqual(response.status_code, 302)
        campaign.refresh_from_db()
        dispatch.refresh_from_db()
        self.assertEqual(campaign.status, Campaign.Status.CANCELLED)
        self.assertEqual(dispatch.state, CampaignDispatch.State.STOPPED)
        self.assertEqual(dispatch.records.get().status, DeliveryRecord.State.BLOCKED)
        self.assertEqual(self.client.get(reverse("training_visit", args=[campaign.participants.get().training_link.token])).status_code, 403)

    @patch.dict("os.environ", ENV)
    def test_delete_hides_running_campaign_but_preserves_db_history(self):
        campaign = self._campaign("Видимая")
        dispatch = prepare_dispatch(campaign.pk, self.domain.pk, self.admin)
        self.client.force_login(self.admin)
        # GET is only confirmation, never deletes.
        self.assertEqual(self.client.get(reverse("campaign_delete", args=[campaign.pk])).status_code, 200)
        campaign.refresh_from_db()
        self.assertIsNone(campaign.deleted_at)
        response = self.client.post(reverse("campaign_delete", args=[campaign.pk]))
        self.assertRedirects(response, reverse("campaign_list"))
        campaign.refresh_from_db()
        dispatch.refresh_from_db()
        self.assertIsNotNone(campaign.deleted_at)
        self.assertEqual(campaign.deleted_by, self.admin)
        self.assertEqual(dispatch.state, CampaignDispatch.State.STOPPED)
        self.assertEqual(self.client.get(reverse("campaign_detail", args=[campaign.pk])).status_code, 404)
        self.assertNotContains(self.client.get(reverse("campaign_list")), "Видимая")
        self.assertEqual(CampaignParticipant.objects.filter(campaign=campaign).count(), 1)
        self.assertEqual(DeliveryRecord.objects.filter(dispatch=dispatch).count(), 1)

    @patch.dict("os.environ", ENV)
    def test_permissions_and_csrf_not_bypassed(self):
        campaign = self._campaign("Права доступа")
        visitor = get_user_model().objects.create_user("nosend", password="UniqueLongPass!4471")
        self.client.force_login(visitor)
        self.assertEqual(self.client.get(reverse("campaign_members_add", args=[campaign.pk])).status_code, 403)
        self.assertEqual(self.client.post(reverse("campaign_stop", args=[campaign.pk])).status_code, 403)
        self.assertEqual(self.client.post(reverse("campaign_delete", args=[campaign.pk])).status_code, 403)
        self.client.force_login(self.admin)
        from django.test import Client
        enforce = Client(enforce_csrf_checks=True)
        enforce.force_login(self.admin)
        self.assertEqual(enforce.post(reverse("campaign_delete", args=[campaign.pk])).status_code, 403)
