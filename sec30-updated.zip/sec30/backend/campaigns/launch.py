"""One click to start an existing campaign, atomically creating the SMTP queue."""
import os

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from delivery.models import CampaignDispatch, SimulationDomain
from delivery.policy import sandbox_mode
from delivery.service import prepare_dispatch
from .models import Campaign


@transaction.atomic
def launch_campaign(campaign_id, actor):
    campaign = Campaign.objects.select_for_update().get(pk=campaign_id)
    if campaign.deleted_at is not None:
        raise ValidationError("Удалённую кампанию нельзя запустить.")
    current = CampaignDispatch.objects.filter(campaign_id=campaign_id).first()
    if current:
        return current, False
    if campaign.status in (Campaign.Status.COMPLETED, Campaign.Status.CANCELLED):
        raise ValidationError("Завершённую или отменённую кампанию нельзя запускать повторно.")

    sender = (campaign.sender_email or os.environ.get("SMTP_FROM_EMAIL", "")).strip().lower()
    if sender.count("@") != 1 or not sender.rsplit("@", 1)[-1]:
        raise ValidationError("Настройте SMTP_FROM_EMAIL в .env.")
    if not os.environ.get("SMTP_HOST", "").strip():
        raise ValidationError("Настройте SMTP_HOST в .env.")
    domain_name = sender.rsplit("@", 1)[-1]
    from delivery.policy import sender_identity_allowed
    if not sender_identity_allowed(sender):
        raise ValidationError("Этот From не разрешён SMTP: укажите SMTP_USERNAME или разрешённую ему идентичность. Для Mailpit действует тестовый режим.")

    domain, _ = SimulationDomain.objects.get_or_create(
        domain=domain_name,
        defaults={"created_by": actor, "sandbox_only": sandbox_mode()},
    )
    if not domain.active:
        raise ValidationError("Отправитель отключён администратором.")

    # Status is an internal detail, not a separate approval step in the interface.
    campaign.status = Campaign.Status.APPROVED
    campaign.save(update_fields=["status", "updated_at"])
    dispatch = prepare_dispatch(campaign_id, domain.pk, actor)
    return dispatch, True
