from django.contrib.auth.decorators import login_required
from django.db import DatabaseError, connections
from django.db.models import Count, F, Q
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET
from campaigns.models import Campaign, SafeEvent, ParticipantEvent
from employees.models import Employee
from email_templates.models import EmailTemplate

@login_required
def dashboard(request):
    stats = {}
    recent = []
    if request.user.has_perm("campaigns.view_campaign"):
        campaigns = Campaign.objects.filter(deleted_at__isnull=True)
        stats.update(campaigns.aggregate(
            total=Count("pk"),
            draft=Count("pk", filter=Q(status=Campaign.Status.DRAFT)),
            active=Count("pk", filter=Q(status__in=[Campaign.Status.APPROVED, Campaign.Status.RUNNING])),
        ))
        stats["events"] = (
            SafeEvent.objects.filter(campaign__deleted_at__isnull=True).count()
            + ParticipantEvent.objects.filter(participant__campaign__deleted_at__isnull=True).count()
        )
        recent = campaigns.annotate(
            legacy_count=Count("events", distinct=True),
            tracked_count=Count("participants__training_events", distinct=True),
        ).annotate(event_count=F("legacy_count") + F("tracked_count")).order_by("-updated_at", "pk")[:5]
    if request.user.has_perm("employees.view_employee"):
        stats["employees"] = Employee.objects.count()
    if request.user.has_perm("email_templates.view_emailtemplate"):
        stats["templates"] = EmailTemplate.objects.count()
    return render(request, "dashboard.html", {"stats": stats, "recent_campaigns": recent})

@require_GET
def health(request):
    try:
        with connections["default"].cursor() as cursor:
            cursor.execute("SELECT 1")
    except DatabaseError:
        return JsonResponse({"status": "degraded", "database": False}, status=503)
    return JsonResponse({"status": "ok", "database": True})

def csrf_failure(request, reason=""):
    return render(request, "csrf_error.html", status=403)
