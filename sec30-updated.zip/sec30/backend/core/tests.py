from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.core.management import call_command
from django.db import OperationalError
from django.test import TestCase
from django.urls import reverse

from campaigns.models import Campaign
from email_templates.models import EmailTemplate
from employees.models import Employee


class AwarenessRoleTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("setup_awareness_roles", stdout=StringIO())
        cls.operator = get_user_model().objects.create_user(username="operator")
        cls.operator.groups.add(Group.objects.get(name="ИБ-оператор"))
        cls.auditor = get_user_model().objects.create_user(username="auditor")
        cls.auditor.groups.add(Group.objects.get(name="ИБ-аудитор"))
        cls.other = get_user_model().objects.create_user(username="other")
        cls.employee = Employee.objects.create(
            first_name="Ирина", last_name="Иванова", email="irina@example.test",
        )
        cls.template = EmailTemplate.objects.create(
            name="Учебный шаблон", subject="Учебная тема", text_body="Текст",
            created_by=cls.operator,
        )
        cls.campaign = Campaign.objects.create(name="Внутренняя кампания", created_by=cls.operator)

    def test_auditor_cannot_access_employee_or_template_views_without_permission(self):
        self.client.force_login(self.auditor)
        for route, args in (
            ("employee_list", []),
            ("employee_detail", [self.employee.pk]),
            ("email_template_list", []),
            ("email_template_detail", [self.template.pk]),
            ("email_template_preview", [self.template.pk]),
        ):
            with self.subTest(route=route):
                self.assertEqual(self.client.get(reverse(route, args=args)).status_code, 403)

    def test_auditor_cannot_make_employee_or_template_changes(self):
        self.client.force_login(self.auditor)
        for route, args in (
            ("employee_create", []),
            ("employee_edit", [self.employee.pk]),
            ("employee_csv_import", []),
            ("email_template_create", []),
            ("email_template_edit", [self.template.pk]),
            ("email_template_delete", [self.template.pk]),
        ):
            with self.subTest(route=route):
                self.assertEqual(self.client.post(reverse(route, args=args)).status_code, 403)
        self.assertTrue(EmailTemplate.objects.filter(pk=self.template.pk).exists())

    def test_operator_can_open_templates_and_read_employee_directory(self):
        self.client.force_login(self.operator)
        self.assertContains(self.client.get(reverse("employee_list")), self.employee.email)
        self.assertEqual(self.client.get(reverse("email_template_create")).status_code, 200)
        self.assertEqual(self.client.get(reverse("email_template_edit", args=[self.template.pk])).status_code, 200)
        self.assertEqual(self.client.post(reverse("email_template_delete", args=[self.template.pk])).status_code, 403)
        self.assertEqual(self.client.get(reverse("employee_create")).status_code, 403)
        self.assertEqual(self.client.get(reverse("employee_csv_import")).status_code, 403)

    def test_view_permission_only_hides_edit_action(self):
        self.other.user_permissions.add(Permission.objects.get(
            content_type__app_label="email_templates", codename="view_emailtemplate",
        ))
        self.client.force_login(self.other)
        response = self.client.get(reverse("email_template_detail", args=[self.template.pk]))
        self.assertContains(response, self.template.name)
        self.assertNotContains(response, reverse("email_template_edit", args=[self.template.pk]))
        self.assertNotContains(response, reverse("email_template_delete", args=[self.template.pk]))

    def test_dashboard_only_includes_permitted_sections(self):
        self.client.force_login(self.other)
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.context["stats"], {})
        self.assertNotContains(response, self.campaign.name)
        self.assertNotContains(response, reverse("employee_list"))
        self.assertNotContains(response, reverse("email_template_list"))

        self.client.force_login(self.auditor)
        response = self.client.get(reverse("dashboard"))
        self.assertContains(response, self.campaign.name)
        self.assertEqual(response.context["stats"]["total"], 1)
        self.assertNotIn("employees", response.context["stats"])
        self.assertNotIn("templates", response.context["stats"])


class ReadinessTests(TestCase):
    def test_readiness_executes_database_query(self):
        response = self.client.get(reverse("health"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok", "database": True})

    @patch("core.views.connections")
    def test_database_error_returns_service_unavailable(self, connections):
        cursor = connections["default"].cursor.return_value.__enter__.return_value
        cursor.execute.side_effect = OperationalError("database unavailable")
        response = self.client.get(reverse("health"))
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json(), {"status": "degraded", "database": False})
        cursor.execute.assert_called_once_with("SELECT 1")
