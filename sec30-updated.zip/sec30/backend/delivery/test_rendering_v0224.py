"""Offline-compatible regression tests for HTML email rendering in v0.22.4."""
import unittest
from types import SimpleNamespace

from delivery.rendering import render_email
from email_templates.rendering import preview_html

TRAINING = "https://training.example.test/learn/123abc/"
PIXEL = "https://training.example.test/pixel/abc/"


def _sample(html_body, text_body=""):
    template = SimpleNamespace(subject="Проверка, {{first_name}}", html_body=html_body, text_body=text_body)
    employee = SimpleNamespace(
        first_name="Иван", last_name="Петров", middle_name="", email="ivan@example.test",
        department=None, position=None,
    )
    return render_email(template, employee, TRAINING)


class EmailRenderingV0224Tests(unittest.TestCase):
    def test_existing_links_point_only_to_personal_training_url(self):
        html = '<a href="https://external.invalid/a">Перейти</a> <a href="mailto:x@example.org">Написать</a>'
        _, text, rendered = _sample(html, 'Проверьте https://bad.invalid/x?x=1 и www.bad.invalid/a.')
        self.assertEqual(rendered.count('href="' + TRAINING + '"'), 2)
        self.assertNotIn('external.invalid', rendered)
        self.assertNotIn('mailto:', rendered)
        self.assertNotIn('bad.invalid', text)
        self.assertEqual(text.count(TRAINING), 2)
        self.assertNotIn('Учебная ссылка:', text)
        self.assertNotIn('Открыть учебную страницу</a></p>', rendered)

    def test_bare_urls_are_replaced_and_autolinking_is_prevented(self):
        _, text, rendered = _sample('<p>Переход: https://old.invalid/verify, затем www.old.invalid/abc.</p>')
        self.assertEqual(rendered.count('href="' + TRAINING + '"'), 2)
        self.assertNotIn('old.invalid', rendered)
        self.assertTrue(text.endswith('Учебная ссылка: ' + TRAINING + '\n'))
        self.assertNotIn('href="https://old.invalid', rendered)

    def test_no_links_uses_one_default_link_in_each_mime_part(self):
        _, text, rendered = _sample('<p>Здравствуйте</p>', 'Здравствуйте')
        self.assertEqual(rendered.count('href="' + TRAINING + '"'), 1)
        self.assertEqual(text.count(TRAINING), 1)
        self.assertIn('Учебная ссылка: ', text)

    def test_email_css_is_inlined_instead_of_printed_as_text(self):
        html = '''<!DOCTYPE html><html><head><title>Госпочта</title>
        <style>body { font-family: Arial, sans-serif; background-color: #f4f4f4; }
        .header { background-color: #4CAF50; color: white; padding: 15px; }
        </style></head><body><div class="header">Важная информация</div>
        <a href="https://old.invalid/redirect">Подтвердить</a></body></html>'''
        _, _, rendered = _sample(html)
        self.assertIn('font-family: Arial', rendered)
        self.assertIn('background-color: #4CAF50', rendered)
        self.assertNotIn('<style', rendered.lower())
        self.assertNotIn('body {', rendered)
        self.assertNotIn('Госпочта', rendered)
        self.assertIn('href="' + TRAINING + '"', rendered)
        self.assertNotIn('old.invalid', rendered)

    def test_script_form_and_risky_css_do_not_run(self):
        html = '''<style>p { color: red; background-image: url(https://evil.invalid/pixel); }</style>
        <script>alert('x')</script><form action="https://old.invalid"><p>Проверка</p>
        <button type="submit">Отправить</button><input name="password" /></form>
        <a href="javascript:alert(1)" onclick="alert(1)">Тут</a>'''
        _, _, rendered = _sample(html)
        self.assertNotIn('<script', rendered)
        self.assertNotIn('<form', rendered)
        self.assertNotIn('<input', rendered)
        self.assertNotIn('<button', rendered)
        self.assertNotIn('javascript:', rendered)
        self.assertNotIn('onclick=', rendered)
        self.assertNotIn('evil.invalid', rendered)
        self.assertIn('href="' + TRAINING + '"', rendered)
        self.assertIn('Проверка', rendered)

    def test_variables_are_escaped_in_html(self):
        template = SimpleNamespace(subject='Привет', html_body='<p>{{ first_name }}</p>', text_body='')
        employee = SimpleNamespace(first_name='<img src=x onerror=alert(1)>',last_name='',middle_name='',email='x@example.test',department=None,position=None)
        _, _, rendered = render_email(template, employee, TRAINING)
        self.assertNotIn('<img src=x', rendered)
        self.assertIn('&lt;img', rendered)

    def test_pixel_is_unchanged_and_not_in_plain_text(self):
        template = SimpleNamespace(subject='Привет', html_body='<p>Текст</p>', text_body='')
        employee = SimpleNamespace(first_name='Иван',last_name='',middle_name='',email='x@example.test',department=None,position=None)
        _, text, rendered = render_email(template, employee, TRAINING, open_pixel_url=PIXEL)
        self.assertIn('src="' + PIXEL + '"', rendered)
        self.assertNotIn(PIXEL, text)

    def test_preview_does_not_navigate_external_link(self):
        html = preview_html('<style>.x {color: red}</style><a class="x" href="https://old.invalid">Текст</a>')
        self.assertIn('href="#"', html)
        self.assertIn('color: red', html)
        self.assertNotIn('old.invalid', html)


if __name__ == '__main__':
    unittest.main()
