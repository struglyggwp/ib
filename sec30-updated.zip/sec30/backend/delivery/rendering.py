"""Safe multi-part email: every template link points to its unique training URL."""
import html
import re

import bleach

from email_templates.rendering import sanitize_email_html

_VARIABLE = re.compile(r"{{\s*(\.[A-Za-z_][A-Za-z0-9_]*|[a-z_]+)\s*}}")
_GO_ALIASES = {
    ".FirstName": "first_name",
    ".LastName": "last_name",
    ".MiddleName": "middle_name",
    ".Email": "email",
    ".Department": "department",
    ".Position": "position",
    ".CompanyName": "company_name",
}
_TEXT_URL = re.compile(r"(?i)(?<![\w@])(?:https?://|www\.)[^\s<>\"'\u00ab\u00bb]+")
_URL_END = '.,;:!?)]}'


def _replace_text_urls(text, training_url):
    """Replace every bare URL in text/plain, retain trailing punctuation."""
    count = 0
    def replace(match):
        nonlocal count
        candidate = match.group(0)
        matched_url = candidate.rstrip(_URL_END)
        if not matched_url:
            return candidate
        count += 1
        return training_url + candidate[len(matched_url):]
    return _TEXT_URL.sub(replace, text), count


def render_email(template, employee, url, open_pixel_url=None, inline_images=None):
    values = {
        "first_name": employee.first_name, "last_name": employee.last_name,
        "middle_name": employee.middle_name, "email": employee.email,
        "department": employee.department.name if employee.department else "",
        "position": employee.position.name if employee.position else "",
        "company_name": "Организация",
    }

    def replace(source, escape=False):
        def replacement(match):
            key = _GO_ALIASES.get(match.group(1), match.group(1))
            if key not in values:
                return match.group(0)
            value = str(values[key])
            return html.escape(value, quote=True) if escape else value
        return _VARIABLE.sub(replacement, source or "")

    subject = bleach.clean(replace(template.subject), tags=[], strip=True).replace("\r", " ").replace("\n", " ")[:250]
    raw_text = replace(template.text_body)
    safe_html, html_links = sanitize_email_html(
        replace(template.html_body, escape=True), training_url=url,
        image_assets=inline_images,
    )
    # If the text alternative is empty, extract readable text from the sanitized HTML.
    text = raw_text or bleach.clean(safe_html, tags=[], strip=True)
    text, text_links = _replace_text_urls(text, url)
    if text_links == 0:
        text = text.rstrip() + "\n\nУчебная ссылка: " + url + "\n"
    # Imported full-page HTML can consist almost entirely of JavaScript,
    # unsupported backgrounds or positioning. Never send an effectively blank
    # MIME HTML part: fall back to the template's visible text instead.
    import bs4
    visible = bs4.BeautifulSoup(safe_html, "html.parser")
    has_visible_content = bool(visible.get_text(" ", strip=True) or visible.find("img"))
    if has_visible_content:
        html_body = safe_html
    else:
        fallback = raw_text.strip() or "Учебное уведомление"
        html_body = "<p>" + html.escape(fallback).replace("\n", "<br>") + "</p>"
    if html_links == 0:
        html_body += '<p><a href="' + html.escape(url, quote=True) + '">Открыть учебную страницу</a></p>'
    if open_pixel_url:
        html_body += ('<img src="' + html.escape(open_pixel_url, quote=True)
                      + '" alt="" width="1" height="1" '
                      + 'style="display:block;width:1px;height:1px;border:0" />')
    return subject, text, html_body
