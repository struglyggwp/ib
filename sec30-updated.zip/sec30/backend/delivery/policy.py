"""Outbound policy: denies by default; never uses a caller-supplied recipient address."""
import os
from urllib.parse import urlparse

from django.core.exceptions import ValidationError


def allowed_recipient_domains():
    return {x.strip().lower().lstrip("@") for x in os.environ.get("SMTP_ALLOWED_RECIPIENT_DOMAINS", "").split(",") if x.strip()}


def campaign_enabled():
    return os.environ.get("SMTP_CAMPAIGN_ENABLED", "0") == "1"


def sandbox_mode():
    return os.environ.get("SMTP_HOST", "").lower().strip() == "mailpit"


def validate_destination(email):
    domain = email.rsplit("@", 1)[-1].strip().lower()
    allowed = allowed_recipient_domains()
    return bool(allowed and domain in allowed and email.count("@") == 1 and not any(c.isspace() for c in email))


def sender_identity_allowed(sender):
    """Mailpit is a capture-only sink. Real SMTP uses configured identities.

    SMTP_AUTHORIZED_FROM_ADDRESSES must contain only identities that the SMTP
    server permits the authenticated account to send as. It is not a way to
    forge addresses or bypass recipient checks.
    """
    from django.core.validators import validate_email
    try:
        validate_email(sender)
    except ValidationError:
        return False
    sender = sender.strip().lower()
    if sandbox_mode():
        return True
    login = os.environ.get("SMTP_USERNAME", "").strip().lower()
    aliases = {x.strip().lower() for x in os.environ.get("SMTP_AUTHORIZED_FROM_ADDRESSES", "").split(",") if x.strip()}
    return bool(login and (sender == login or sender in aliases))


def validate_sender(domain, sender_override=None):
    sender = (sender_override or os.environ.get("SMTP_FROM_EMAIL", "")).strip().lower()
    if sender.count("@") != 1 or sender.rsplit("@", 1)[-1] != domain.domain.lower():
        raise ValidationError("Адрес отправителя должен принадлежать выбранному почтовому домену.")
    if not domain.active or not sender_identity_allowed(sender):
        raise ValidationError("Для этого From нет разрешённой SMTP-идентичности.")
    if domain.sandbox_only and not sandbox_mode():
        raise ValidationError("Домен Mailpit нельзя использовать для отправки через Zimbra без настройки SMTP.")
    return sender


def landing_url(domain):
    if sandbox_mode():
        base = os.environ.get("SIMULATION_LOCAL_BASE_URL", "http://127.0.0.1:8080").strip().rstrip("/")
        parsed = urlparse(base)
        if (parsed.scheme not in ("http", "https") or not parsed.hostname
                or parsed.hostname not in ("127.0.0.1", "localhost", "::1")
                or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment):
            raise ValidationError("SIMULATION_LOCAL_BASE_URL допускает только адрес localhost/127.0.0.1.")
        return base
    base = os.environ.get("SIMULATION_PUBLIC_BASE_URL", "").strip().rstrip("/")
    parsed = urlparse(base)
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValidationError("Некорректный порт учебной ссылки.") from exc
    allowed_hosts = {host.strip().lower() for host in os.environ.get("SIMULATION_ALLOWED_LINK_HOSTS", "").split(",") if host.strip()}
    # Explicitly configured recipient-facing HTTPS URL. Sender identity and landing host are independent.
    if parsed.scheme != "https" or parsed.username or parsed.password or port not in (None, 443):
        raise ValidationError("Для SMTP требуется HTTPS-ссылка на порту 443 (SIMULATION_PUBLIC_BASE_URL).")
    if not parsed.hostname or parsed.hostname.lower() not in allowed_hosts or parsed.path or parsed.query or parsed.fragment:
        raise ValidationError("Укажите хост ссылки в SIMULATION_ALLOWED_LINK_HOSTS и настройте внутренний DNS.")
    return base


def limits():
    try:
        max_campaign = min(250, max(1, int(os.environ.get("SMTP_MAX_PER_CAMPAIGN", "100"))))
        per_minute = min(10, max(1, int(os.environ.get("SMTP_MAX_PER_MINUTE", "10"))))
    except ValueError as exc:
        raise ValidationError("Некорректные ограничения отправки в .env") from exc
    return max_campaign, per_minute
