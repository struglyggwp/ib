from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator
from django.db.models import Count, Max
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_http_methods, require_POST
from django.utils import timezone

from campaigns.models import Campaign
from .models import CampaignDispatch, DeliveryRecord
from .service import stop_dispatch


@login_required
@require_GET
def domains(request):
    messages.info(request, "Домен отправителя берётся из SMTP_FROM_EMAIL автоматически. DNS TXT больше не требуется.")
    return redirect("campaign_list")


@login_required
@require_http_methods(["GET", "POST"])
def domain_create(request):
    return redirect("campaign_list")


@login_required
@require_POST
def domain_verify(request, pk):
    # Old links must not unexpectedly trigger a DNS verification lookup.
    return redirect("campaign_list")


@login_required
@permission_required("delivery.view_campaigndispatch", raise_exception=True)
@permission_required("campaigns.view_campaign", raise_exception=True)
@require_GET
def dispatch_detail(request, campaign_id):
    campaign = get_object_or_404(Campaign.objects.select_related("email_template"), pk=campaign_id, deleted_at__isnull=True)
    dispatch = CampaignDispatch.objects.filter(campaign=campaign).first()
    context = {"campaign": campaign, "dispatch": dispatch}
    if dispatch is None:
        return render(request, "delivery/dispatch.html", context)

    status = request.GET.get("status", "")
    if status not in DeliveryRecord.State.values:
        status = ""
    records = dispatch.records.all()
    totals = dict(records.values("status").order_by().annotate(n=Count("pk")).values_list("status", "n"))
    cutoff = timezone.now() - timedelta(minutes=5)
    summary = records.aggregate(
        last_claim=Max("attempted_at"),
        last_acceptance=Max("smtp_accepted_at"),
    )
    latest_publication = dispatch.audit.filter(action__in=["queue_published", "queue_publish_failed"]).first()
    last_worker_activity = max((date for date in summary.values() if date), default=None)
    last_queue_activity = max(
        dispatch.created_at,
        last_worker_activity or dispatch.created_at,
        latest_publication.created_at if latest_publication else dispatch.created_at,
    )
    pending = totals.get(DeliveryRecord.State.PENDING, 0)
    active = dispatch.state in (CampaignDispatch.State.QUEUED, CampaignDispatch.State.RUNNING)
    page = Paginator(
        (records.filter(status=status) if status else records)
        .select_related("participant__employee")
        .order_by("participant__employee__last_name", "participant__employee__first_name", "pk"),
        30,
    ).get_page(request.GET.get("page"))
    context.update({
        "page": page,
        "status": status,
        "active": active,
        "total": sum(totals.values()),
        "counts": [(value, label, totals.get(value, 0)) for value, label in DeliveryRecord.State.choices],
        "last_worker_activity": last_worker_activity,
        "latest_publication": latest_publication,
        "publication_failed": bool(
            active and pending and latest_publication and latest_publication.action == "queue_publish_failed"
            and (last_worker_activity is None or last_worker_activity <= latest_publication.created_at)
        ),
        "queue_delayed": active and pending and last_queue_activity < cutoff,
        "stale_sending": records.filter(status=DeliveryRecord.State.SENDING, attempted_at__lt=cutoff).count(),
        "audits": dispatch.audit.exclude(action="queue_published").select_related("actor")[:15],
    })
    return render(request, "delivery/dispatch.html", context)


@login_required
@permission_required("delivery.stop_dispatch", raise_exception=True)
@permission_required("campaigns.change_campaign", raise_exception=True)
@require_POST
def dispatch_stop(request, campaign_id):
    try:
        stop_dispatch(campaign_id, request.user)
        messages.success(request, "Очередь остановлена. Уже принятые SMTP письма отозвать нельзя.")
    except CampaignDispatch.DoesNotExist:
        messages.error(request, "Рассылка не найдена.")
    return redirect("delivery_dispatch", campaign_id=campaign_id)
