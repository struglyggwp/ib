"""Standalone regression checks for imported email images and formatting."""
import base64
import unittest
from email.message import EmailMessage
from types import SimpleNamespace

from delivery.rendering import render_email
from email_templates.rendering import preview_html, sanitize_email_html

PIXEL = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9R9CqWcAAAAASUVORK5CYII="
)
URL = "https://training.example.test/learn/unique-token/"


def sample(source, image_assets=None):
    template = SimpleNamespace(subject="Проверка", html_body=source, text_body="")
    employee = SimpleNamespace(first_name="Тест", last_name="Сотрудник", middle_name="",
        email="test@example.test", department=None, position=None)
    return render_email(template, employee, URL, inline_images=image_assets)


class ImportedHtmlRegressionTests(unittest.TestCase):
    def test_html_picture_and_css_are_not_stripped(self):
        html = ('<html><head><style>.hero {padding: 20px;background-color:#123456}</style></head>'
                '<body><div class="hero"><img src="https://images.example.test/logo.png" '
                'alt="Логотип" width="150"><a href="https://old.example.test/">Читать</a></div></body></html>')
        _, _, rendered = sample(html)
        self.assertIn('img', rendered)
        self.assertIn('https://images.example.test/logo.png', rendered)
        self.assertIn('width="150"', rendered)
        self.assertIn('background-color: #123456', rendered)
        self.assertIn('href="' + URL + '"', rendered)
        self.assertNotIn('href="https://old.example.test/"', rendered)
        self.assertNotIn('<style', rendered)

    def test_base64_image_is_attached_to_email_via_cid(self):
        data_url = 'data:image/png;base64,' + base64.b64encode(PIXEL).decode()
        assets=[]
        _, text, rendered = sample('<p>Инструкция <img src="'+data_url+'" alt="logo"></p>', assets)
        self.assertEqual(len(assets), 1)
        cid, mime, payload = assets[0]
        self.assertEqual(mime, 'image/png')
        self.assertEqual(payload, PIXEL)
        self.assertIn('src="cid:' + cid + '"', rendered)
        message=EmailMessage()
        message['From']='training@example.test'
        message['To']='test@example.test'
        message.set_content(text)
        message.add_alternative(rendered, subtype='html')
        message.get_body(preferencelist=('html',)).add_related(payload, maintype='image', subtype='png', cid=f'<{cid}>')
        self.assertTrue(any(part.get_content_type()=='image/png' for part in message.walk()))

    def test_preview_keeps_safe_embedded_image(self):
        data_url = 'data:image/png;base64,' + base64.b64encode(PIXEL).decode()
        self.assertIn('src="'+data_url+'"', preview_html('<img alt="logo" src="'+data_url+'">'))

    def test_bad_image_protocol_is_removed(self):
        safe, _ = sanitize_email_html('<img src="javascript:alert(1)" onerror="alert(2)">'
            '<img src="data:image/svg+xml;base64,PHN2Zz4=" />', training_url=URL)
        self.assertNotIn('javascript:', safe)
        self.assertNotIn('onerror', safe)
        self.assertNotIn('svg+xml', safe)

    def test_embedded_identical_images_are_deduplicated(self):
        uri='data:image/png;base64,'+base64.b64encode(PIXEL).decode()
        assets=[]
        _,_,rendered=sample('<img src="'+uri+'"><img src="'+uri+'">', assets)
        self.assertEqual(len(assets), 1)
        self.assertEqual(rendered.count('src="cid:'), 2)


if __name__ == '__main__':
    unittest.main()
