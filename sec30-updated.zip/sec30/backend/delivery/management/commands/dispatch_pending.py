"""Recovery after broker outage. Never retries already claimed/ambiguous messages."""
from django.core.management.base import BaseCommand, CommandError
from delivery.models import CampaignDispatch, DeliveryRecord
from delivery.tasks import publish_dispatch


class Command(BaseCommand):
    help = "Повторно поставить в Celery ожидающие задания. Не повторяет SENDING/FAILED/ACCEPTED."

    def handle(self, *args, **kwargs):
        count = 0
        failures = 0
        qs = CampaignDispatch.objects.filter(state__in=[CampaignDispatch.State.QUEUED, CampaignDispatch.State.RUNNING])
        for dispatch in qs:
            if not DeliveryRecord.objects.filter(dispatch=dispatch, status=DeliveryRecord.State.PENDING).exists():
                continue
            if publish_dispatch(dispatch.pk):
                count += 1
            else:
                failures += 1
        self.stdout.write(self.style.SUCCESS(f"Перепоставлено в очередь кампаний: {count}"))
        if failures:
            raise CommandError(f"Брокер не подтвердил задачи для {failures} кампаний.")
