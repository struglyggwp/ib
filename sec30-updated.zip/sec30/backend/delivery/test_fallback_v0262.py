from types import SimpleNamespace

from django.test import SimpleTestCase
from .rendering import render_email


class EmailFallbackTests(SimpleTestCase):
    def setUp(self):
        self.employee = SimpleNamespace(first_name='Иван', last_name='Петров', middle_name='',
                                        email='ivan@training.test', department=None, position=None)
        self.url = 'https://training.test/learn/example/'

    def test_empty_script_only_export_gets_visible_fallback(self):
        template = SimpleNamespace(subject='Учебное письмо', text_body='',
                                   html_body='<html><body><script>alert(1)</script></body></html>')
        subject, text, html = render_email(template, self.employee, self.url)
        self.assertIn('Учебное уведомление', html)
        self.assertIn(self.url, html)
        self.assertNotIn('<script>', html)

    def test_noscript_fallback_is_kept_and_sanitized(self):
        template = SimpleNamespace(subject='Тема', text_body='',
                                   html_body='<html><body><noscript><p>Текст рассылки</p></noscript></body></html>')
        subject, text, html = render_email(template, self.employee, self.url)
        self.assertIn('Текст рассылки', html)
        self.assertIn(self.url, html)
