"""Regression tests for HTML captured from an email viewer iframe[srcdoc]."""
import html
from types import SimpleNamespace

from django.test import SimpleTestCase
from email_templates.forms import decode_uploaded_html
from email_templates.rendering import extract_embedded_email, sanitize_email_html
from delivery.rendering import render_email


def export(inner):
    return ('<div class="_emails__content__mail_eultc_353">'
            '<div class="_iframe-wrapper_b7qnt_6">'
            '<iframe sandbox="allow-scripts" srcdoc="'
            + html.escape(inner, quote=True) + '"></iframe></div></div>')


class EmbeddedEmailTests(SimpleTestCase):
    def setUp(self):
        self.original = ('<html><head><style>p { color: red; }</style></head>'
                         '<body><table><tr><td><p>Привет, коллега!</p>'
                         '<a href="https://test.example">Читать</a>'
                         '</td></tr></table></body></html>')
        self.wrapper = export(self.original)

    def test_extract_real_html_from_viewer_srcdoc(self):
        extracted = extract_embedded_email(self.wrapper)
        self.assertIn('<table>', extracted)
        self.assertIn('Привет, коллега!', extracted)
        self.assertNotIn('<iframe', extracted)

    def test_render_stored_old_dispatch_snapshot(self):
        employee = SimpleNamespace(first_name="Иван", last_name="Иванов", middle_name="",
            email="ivan@example.test", department=None, position=None)
        template = SimpleNamespace(subject="Тест", text_body="", html_body=self.wrapper)
        _, _, rendered = render_email(template, employee, "https://training.test/learn/uuid/")
        self.assertIn("Привет, коллега!", rendered)
        self.assertIn("<table", rendered)
        self.assertIn('href="https://training.test/learn/uuid/"', rendered)
        self.assertNotIn("<iframe", rendered)
        self.assertNotIn("Учебное уведомление", rendered)

    def test_import_saves_original_not_viewer(self):
        imported = decode_uploaded_html(self.wrapper.encode("utf-8"))
        self.assertIn("<table>", imported)
        self.assertNotIn("<iframe", imported)

    def test_normal_plain_html_unchanged(self):
        self.assertEqual(extract_embedded_email(self.original), self.original)

    def test_no_active_script_after_import(self):
        wrapped = export('<html><body><p>Тест</p><script>alert(1)</script></body></html>')
        safe, _ = sanitize_email_html(wrapped, training_url="https://training.test/learn/t/")
        self.assertIn("Тест", safe)
        self.assertNotIn("<script", safe)
