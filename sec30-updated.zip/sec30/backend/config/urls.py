from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from core import views
from campaigns.views import training_visit, training_page_content, training_interaction, training_complete
from campaigns.open_tracking import email_open_pixel

admin.site.login_template = "admin/awareness_login.html"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("health/", views.health, name="health"),
    path("admin/", admin.site.urls),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("campaigns/", include("campaigns.urls")),
    path("learn/<uuid:token>/", training_visit, name="training_visit"),
    path("learn/<uuid:token>/interaction/", training_interaction, name="training_interaction"),
    path("learn/<uuid:token>/complete/", training_complete, name="training_complete"),
    path("track/open/<uuid:token>.gif", email_open_pixel, name="email_open_pixel"),
    path("employees/", include("employees.urls")),
    path("pages/", include("landing_pages.urls")),
    path("learn/<uuid:token>/page/", training_page_content, name="training_page_content"),
    path("templates/", include("email_templates.urls")),
    path("scenarios/", include("scenarios.urls")),
    path("delivery/", include("delivery.urls")),
]
