from django.urls import path
from . import views

urlpatterns = [
    path("", views.scenario_list, name="scenario_list"),
    path("new/", views.scenario_create, name="scenario_create"),
    path("<uuid:scenario_id>/", views.scenario_detail, name="scenario_detail"),
    path("<uuid:scenario_id>/edit/", views.scenario_edit, name="scenario_edit"),
    path("<uuid:scenario_id>/steps/new/", views.scenario_step_create, name="scenario_step_create"),
    path("<uuid:scenario_id>/steps/<uuid:step_id>/edit/", views.scenario_step_edit, name="scenario_step_edit"),
    path("<uuid:scenario_id>/steps/<uuid:step_id>/delete/", views.scenario_step_delete, name="scenario_step_delete"),
]
