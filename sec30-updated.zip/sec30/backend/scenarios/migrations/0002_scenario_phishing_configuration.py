from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("scenarios", "0001_initial"),
        ("landing_pages", "0001_initial"),
    ]
    operations = [
        migrations.AddField(model_name="scenario", name="landing_page", field=models.ForeignKey(
            to="landing_pages.landingpage", on_delete=django.db.models.deletion.PROTECT,
            null=True, blank=True, related_name="scenarios", verbose_name="Учебная HTML-страница")),
        migrations.AddField(model_name="scenario", name="sender_email", field=models.EmailField(
            max_length=254, blank=True, verbose_name="Отправитель (From)")),
        migrations.AddField(model_name="scenario", name="learning_objective", field=models.TextField(
            blank=True, verbose_name="Цель проверки", help_text="Чему должен научиться сотрудник")),
        migrations.AddField(model_name="scenario", name="risk_indicators", field=models.TextField(
            blank=True, verbose_name="Признаки фишинга для разбора", help_text="Какие признаки обсудить после упражнения")),
    ]
