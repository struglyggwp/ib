"""Scenario editor: configuration only, no executable steps or credential capture."""
from django import forms
from django.db.models import Q

from email_templates.models import EmailTemplate
from employees.models import Department, Employee
from landing_pages.models import LandingPage
from .models import Scenario, ScenarioStep


class ScenarioForm(forms.ModelForm):
    class Meta:
        model = Scenario
        fields = (
            "name", "description", "category", "difficulty", "status",
            "email_template", "landing_page", "sender_email",
            "departments", "employees", "learning_objective", "risk_indicators",
        )
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "category": forms.Select(attrs={"class": "form-select"}),
            "difficulty": forms.Select(attrs={"class": "form-select"}),
            "status": forms.Select(attrs={"class": "form-select"}),
            "email_template": forms.Select(attrs={"class": "form-select"}),
            "landing_page": forms.Select(attrs={"class": "form-select"}),
            "sender_email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "training@example.test"}),
            "departments": forms.SelectMultiple(attrs={"class": "form-select", "size": 5}),
            "employees": forms.SelectMultiple(attrs={"class": "form-select", "size": 8}),
            "learning_objective": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "risk_indicators": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
        }
        help_texts = {
            "email_template": "Выберите активное письмо. HTML-письмо можно загрузить через раздел «Шаблоны писем».",
            "landing_page": "Необязательно. Если страницу не выбрать, используется штатная учебная.",
            "sender_email": "Укажите адрес, разрешённый SMTP/Zimbra. Пустое поле использует SMTP_FROM_EMAIL.",
            "departments": "Активные сотрудники выбранных подразделений включаются в новую кампанию.",
            "employees": "Дополнительные сотрудники (Ctrl для выбора нескольких).",
            "status": "Статус «Готов» разрешает создание кампании по этому сценарию.",
            "learning_objective": "Внутренние методические заметки, не отправляются сотруднику.",
            "risk_indicators": "Не отправляются по email; видны специалистам ИБ в карточке сценария.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        old_template = self.instance.email_template_id if self.instance.pk else None
        old_page = self.instance.landing_page_id if self.instance.pk else None
        self.fields["email_template"].queryset = EmailTemplate.objects.filter(
            Q(status=EmailTemplate.Status.ACTIVE) | Q(pk=old_template)
        ).distinct().order_by("name")
        self.fields["landing_page"].queryset = LandingPage.objects.filter(
            Q(active=True) | Q(pk=old_page)
        ).distinct().order_by("name")
        self.fields["departments"].queryset = Department.objects.filter(is_active=True).order_by("name")
        self.fields["employees"].queryset = Employee.objects.filter(is_active=True).order_by("last_name", "first_name")

    def clean(self):
        data = super().clean()
        if data.get("status") == Scenario.Status.READY:
            template = data.get("email_template")
            if template is None or template.status != EmailTemplate.Status.ACTIVE:
                self.add_error("email_template", "Для готового сценария нужен активный шаблон письма.")
            elif not (template.html_body.strip() or template.text_body.strip()):
                self.add_error("email_template", "У выбранного шаблона нет содержимого.")
            page = data.get("landing_page")
            if page is not None and not page.active:
                self.add_error("landing_page", "Учебная страница должна быть активной.")
        return data


class ScenarioStepForm(forms.ModelForm):
    class Meta:
        model = ScenarioStep
        fields = ("kind", "title", "instructions")
        widgets = {
            "kind": forms.Select(attrs={"class": "form-select"}),
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "instructions": forms.Textarea(attrs={"class": "form-control", "rows": 5}),
        }
        help_texts = {"instructions": "Внутренние инструкции, без исполняемых скриптов и запросов учётных данных."}
