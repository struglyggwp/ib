from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from campaigns.models import Campaign
from email_templates.models import EmailTemplate
from employees.models import Department, Employee
from .models import Scenario, ScenarioActivity, ScenarioStep


class ReintroducedScenariosTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_superuser(
            username="scenario-admin", email="admin@example.test", password="test-password-123"
        )
        self.client.force_login(self.user)
        self.department = Department.objects.create(name="Аналитики")
        self.employee = Employee.objects.create(
            first_name="Ирина", last_name="Иванова", email="irina@example.test", department=self.department,
        )
        self.email = EmailTemplate.objects.create(
            name="Письмо-обучение", subject="Обучение", html_body="<p>Учебный пример</p>",
            status="active", created_by=self.user,
        )

    def _scenario(self):
        scenario = Scenario.objects.create(
            name="Проверка фишинга", email_template=self.email, sender_email="trainer@example.test",
            category=Scenario.Category.PHISHING, status=Scenario.Status.READY,
            learning_objective="Проверка адреса", created_by=self.user,
        )
        scenario.departments.add(self.department)
        return scenario

    def test_scenario_list_and_detail_are_available(self):
        scenario = self._scenario()
        self.assertContains(self.client.get(reverse("scenario_list")), "Проверка фишинга")
        self.assertContains(self.client.get(reverse("scenario_detail", args=[scenario.pk])), "Создать кампанию")

    def test_create_scenario(self):
        resp = self.client.post(reverse("scenario_create"), {
            "name": "Новый сценарий", "category": "phishing", "difficulty": "basic",
            "status": "ready", "email_template": self.email.pk,
            "landing_page": "", "sender_email": "trainer@example.test",
            "employees": [str(self.employee.pk)], "departments": [],
            "description": "Описание", "learning_objective": "Цель", "risk_indicators": "Признаки",
        })
        self.assertEqual(resp.status_code, 302)
        obj = Scenario.objects.get(name="Новый сценарий")
        self.assertEqual(list(obj.employees.values_list("pk", flat=True)), [self.employee.pk])
        self.assertEqual(obj.version, 1)
        self.assertTrue(ScenarioActivity.objects.filter(scenario=obj, action="created").exists())

    def test_new_campaign_prefills_scenario_and_freezes_revision(self):
        scenario = self._scenario()
        url = reverse("campaign_create") + "?scenario=" + str(scenario.pk)
        get_resp = self.client.get(url)
        self.assertEqual(get_resp.status_code, 200)
        self.assertContains(get_resp, "Проверка фишинга")
        resp = self.client.post(url, {
            "name": "Кампания от сценария", "description": "",
            "sender_email": "trainer@example.test", "email_template": self.email.pk,
            "landing_page": "", "employees": "", "departments": [self.department.pk],
        })
        self.assertEqual(resp.status_code, 302)
        campaign = Campaign.objects.get(name="Кампания от сценария")
        self.assertEqual(campaign.scenario_id, scenario.pk)
        self.assertEqual(campaign.scenario_version, 1)
        self.assertEqual(campaign.sender_email, "trainer@example.test")
        self.assertEqual(set(campaign.participants.values_list("employee_id", flat=True)), {self.employee.pk})
        scenario.name = "Переименовано позже"
        scenario.version = 2
        scenario.save()
        campaign.refresh_from_db()
        self.assertEqual(campaign.name, "Кампания от сценария")
        self.assertEqual(campaign.scenario_version, 1)

    def test_step_lifecycle_does_not_send_emails(self):
        scenario = self._scenario()
        create_url = reverse("scenario_step_create", args=[scenario.pk])
        resp = self.client.post(create_url, {"kind": "teach", "title": "Разбор", "instructions": "Проверить URL"})
        self.assertEqual(resp.status_code, 302)
        step = ScenarioStep.objects.get(scenario=scenario)
        self.assertEqual(step.position, 1)
        scenario.refresh_from_db()
        self.assertEqual(scenario.version, 2)
        self.assertEqual(self.client.post(reverse("scenario_step_delete", args=[scenario.pk, step.pk])).status_code, 302)
        self.assertFalse(ScenarioStep.objects.filter(scenario=scenario).exists())

    def test_draft_scenario_cannot_be_launched_as_campaign(self):
        scenario = self._scenario()
        scenario.status = Scenario.Status.DRAFT
        scenario.save()
        resp = self.client.get(reverse("campaign_create") + "?scenario=" + str(scenario.pk))
        self.assertEqual(resp.status_code, 404)

    def test_scenario_views_require_authorization(self):
        self.client.logout()
        self.assertEqual(self.client.get(reverse("scenario_list")).status_code, 302)
        self.assertEqual(self.client.get(reverse("scenario_create")).status_code, 302)
