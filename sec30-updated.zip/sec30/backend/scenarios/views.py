"""Operator-managed phishing awareness scenario presets.

Scenarios are configuration templates. Sending happens only through campaigns,
with all existing SMTP limits, allowlists, and access control still enforced.
"""
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.db import transaction
from django.db.models import Max, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_POST, require_http_methods

from .forms import ScenarioForm, ScenarioStepForm
from .models import Scenario, ScenarioActivity, ScenarioStep


def _activity(scenario, actor, action, description=""):
    ScenarioActivity.objects.create(
        scenario=scenario, actor=actor, action=action, description=description[:300]
    )


@login_required
@permission_required("scenarios.view_scenario", raise_exception=True)
@require_GET
def scenario_list(request):
    qs = Scenario.objects.select_related("email_template", "landing_page", "created_by")
    query = request.GET.get("q", "").strip()
    if query:
        qs = qs.filter(Q(name__icontains=query) | Q(description__icontains=query))
    status = request.GET.get("status", "")
    if status in Scenario.Status.values:
        qs = qs.filter(status=status)
    return render(request, "scenarios/list.html", {
        "scenarios": qs, "query": query, "selected_status": status,
        "statuses": Scenario.Status.choices,
    })


@login_required
@permission_required("scenarios.add_scenario", raise_exception=True)
@require_http_methods(["GET", "POST"])
def scenario_create(request):
    form = ScenarioForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            scenario = form.save(commit=False)
            scenario.created_by = request.user
            scenario.save()
            form.save_m2m()
            _activity(scenario, request.user, ScenarioActivity.Action.CREATED)
        messages.success(request, "Сценарий создан. Теперь можно создать из него кампанию.")
        return redirect("scenario_detail", scenario_id=scenario.pk)
    return render(request, "scenarios/form.html", {"form": form, "page_title": "Новый сценарий"})


@login_required
@permission_required("scenarios.view_scenario", raise_exception=True)
@require_GET
def scenario_detail(request, scenario_id):
    scenario = get_object_or_404(Scenario.objects.select_related("email_template", "landing_page", "created_by")
                                 .prefetch_related("departments", "employees", "steps", "activity"), pk=scenario_id)
    return render(request, "scenarios/detail.html", {
        "scenario": scenario,
        "audience_count": scenario.employees.filter(is_active=True).count(),
        "steps": scenario.steps.all(),
        "activity": scenario.activity.all()[:10],
    })


@login_required
@permission_required("scenarios.change_scenario", raise_exception=True)
@require_http_methods(["GET", "POST"])
def scenario_edit(request, scenario_id):
    scenario = get_object_or_404(Scenario, pk=scenario_id)
    form = ScenarioForm(request.POST or None, instance=scenario)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            # Increment revision for future campaigns, preserving old campaign snapshots.
            locked = Scenario.objects.select_for_update().get(pk=scenario.pk)
            scenario.version = locked.version + 1
            scenario = form.save()
            _activity(scenario, request.user, ScenarioActivity.Action.EDITED)
        messages.success(request, "Сценарий сохранён. Ревизия обновлена; отправленные кампании не изменены.")
        return redirect("scenario_detail", scenario_id=scenario.pk)
    return render(request, "scenarios/form.html", {
        "form": form, "scenario": scenario, "page_title": "Изменить сценарий",
    })


@login_required
@permission_required("scenarios.change_scenario", raise_exception=True)
@require_http_methods(["GET", "POST"])
def scenario_step_create(request, scenario_id):
    scenario = get_object_or_404(Scenario, pk=scenario_id)
    form = ScenarioStepForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            scenario = Scenario.objects.select_for_update().get(pk=scenario.pk)
            step = form.save(commit=False)
            step.scenario = scenario
            step.position = (scenario.steps.aggregate(last=Max("position"))["last"] or 0) + 1
            step.save()
            scenario.version += 1
            scenario.save(update_fields=["version", "updated_at"])
            _activity(scenario, request.user, ScenarioActivity.Action.STEP_CHANGED, "Этап добавлен")
        messages.success(request, "Этап сценария добавлен.")
        return redirect("scenario_detail", scenario_id=scenario.pk)
    return render(request, "scenarios/step_form.html", {"scenario": scenario, "form": form, "page_title": "Добавить этап"})


@login_required
@permission_required("scenarios.change_scenario", raise_exception=True)
@require_http_methods(["GET", "POST"])
def scenario_step_edit(request, scenario_id, step_id):
    scenario = get_object_or_404(Scenario, pk=scenario_id)
    step = get_object_or_404(ScenarioStep, pk=step_id, scenario=scenario)
    form = ScenarioStepForm(request.POST or None, instance=step)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            scenario = Scenario.objects.select_for_update().get(pk=scenario.pk)
            form.save()
            scenario.version += 1
            scenario.save(update_fields=["version", "updated_at"])
            _activity(scenario, request.user, ScenarioActivity.Action.STEP_CHANGED, "Этап изменён")
        messages.success(request, "Этап сохранён.")
        return redirect("scenario_detail", scenario_id=scenario.pk)
    return render(request, "scenarios/step_form.html", {"scenario": scenario, "form": form, "page_title": "Изменить этап"})


@login_required
@permission_required("scenarios.change_scenario", raise_exception=True)
@require_POST
def scenario_step_delete(request, scenario_id, step_id):
    with transaction.atomic():
        scenario = get_object_or_404(Scenario.objects.select_for_update(), pk=scenario_id)
        step = get_object_or_404(ScenarioStep, pk=step_id, scenario=scenario)
        step.delete()
        scenario.version += 1
        scenario.save(update_fields=["version", "updated_at"])
        _activity(scenario, request.user, ScenarioActivity.Action.STEP_CHANGED, "Этап удалён")
    messages.success(request, "Этап сценария удалён.")
    return redirect("scenario_detail", scenario_id=scenario_id)
