from django.contrib import admin

from .models import Scenario, ScenarioStep, ScenarioActivity


class ScenarioStepInline(admin.TabularInline):
    model = ScenarioStep
    extra = 0
    fields = ("position", "kind", "title", "instructions")


@admin.register(Scenario)
class ScenarioAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "difficulty", "status", "email_template", "landing_page", "version", "updated_at")
    list_filter = ("status", "category", "difficulty")
    search_fields = ("name", "description", "sender_email")
    filter_horizontal = ("departments", "employees")
    exclude = ("created_by",)
    readonly_fields = ("version", "created_at", "updated_at")
    inlines = (ScenarioStepInline,)

    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        else:
            obj.version += 1
        super().save_model(request, obj, form, change)


@admin.register(ScenarioActivity)
class ScenarioActivityAdmin(admin.ModelAdmin):
    list_display = ("scenario", "action", "actor", "at")
    list_filter = ("action", "at")
    search_fields = ("scenario__name", "description")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
