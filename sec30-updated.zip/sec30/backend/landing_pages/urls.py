from django.urls import path
from . import views

urlpatterns = [
    path("", views.page_list, name="landing_page_list"),
    path("new/", views.page_create, name="landing_page_create"),
    path("<uuid:page_id>/", views.page_detail, name="landing_page_detail"),
    path("<uuid:page_id>/preview/", views.page_preview, name="landing_page_preview"),
    path("<uuid:page_id>/archive/", views.page_archive, name="landing_page_archive"),
]
