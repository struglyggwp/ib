import uuid

from django.conf import settings
from django.db import models


class LandingPage(models.Model):
    """HTML page: new uploads retain their exact original bytes; legacy pages remain readable."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField("Название", max_length=160)
    source_filename = models.CharField("Имя исходного файла", max_length=255)
    source_sha256 = models.CharField(max_length=64)
    sanitized_html = models.TextField("Очищенный HTML")  # Legacy snapshots from v0.19.1.
    original_html = models.BinaryField("Оригинальный HTML без изменений", blank=True, null=True, editable=False)
    source_charset = models.CharField("Кодировка файла", max_length=20, default="utf-8")
    internal_origin = models.URLField("Внутренний адрес сайта", max_length=255)
    active = models.BooleanField("Доступна для новых кампаний", default=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "учебная HTML-страница"
        verbose_name_plural = "учебные HTML-страницы"

    def __str__(self):
        return self.name
