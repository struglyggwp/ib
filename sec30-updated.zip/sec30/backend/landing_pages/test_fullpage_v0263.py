"""Full-window training pages, no credential submission and stable event tracking."""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign, CampaignParticipant, ParticipantEvent, TrainingLink
from employees.models import Employee
from .models import LandingPage


class FullPageTrainingTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = get_user_model().objects.create_superuser(
            'fullpage-admin', 'admin@example.test', 'TestPassword123!'
        )
        cls.page = LandingPage.objects.create(
            name='Тест прямой HTML-страницы', source_filename='original.html',
            source_sha256='a' * 64, source_charset='utf-8',
            original_html=(
                b'<!doctype html><html><head><meta charset="utf-8">'
                b'<style>body{background:#234567}</style></head><body>'
                b'<h1>Original Page</h1>'
                b'<form action="https://untrusted.invalid/" method="post">'
                b'<input type="password" name="password">'
                b'<button type="submit">Login</button></form></body></html>'
            ),
            sanitized_html='', internal_origin='http://training.test:8080',
            created_by=cls.admin,
        )
        cls.campaign = Campaign.objects.create(
            name='Тест direct HTML', status=Campaign.Status.RUNNING,
            landing_page=cls.page, created_by=cls.admin,
        )
        cls.employee = Employee.objects.create(
            first_name='Тест', last_name='Сотрудник', email='fullpage@example.test'
        )
        cls.participant = CampaignParticipant.objects.create(
            campaign=cls.campaign, employee=cls.employee,
        )
        cls.link = TrainingLink.objects.create(
            participant=cls.participant, created_by=cls.admin,
            expires_at=timezone.now() + timedelta(days=7),
        )

    def test_original_html_is_top_level_response_without_iframe(self):
        response = self.client.get(reverse('training_visit', args=[self.link.token]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Original Page')
        self.assertContains(response, 'background:#234567')
        self.assertNotContains(response, '<iframe')
        self.assertNotContains(response, 'Завершить упражнение')
        self.assertIn("form-action 'none'", response['Content-Security-Policy'])
        self.assertIn('sandbox allow-scripts', response['Content-Security-Policy'])
        self.assertIn(reverse('training_complete', args=[self.link.token]), response.content.decode('utf-8'))
        self.assertNotIn('postMessage', response.content.decode('utf-8'))
        self.assertEqual(ParticipantEvent.objects.filter(participant=self.participant,
            kind=ParticipantEvent.Kind.LINK_VISITED).count(), 1)

    def test_click_navigation_records_action_without_form_contents(self):
        endpoint = reverse('training_complete', args=[self.link.token])
        response = self.client.get(endpoint)
        self.assertContains(response, 'Это была учебная проверка')
        self.assertNotContains(response, 'password')
        self.assertEqual(ParticipantEvent.objects.filter(participant=self.participant,
            kind=ParticipantEvent.Kind.PAGE_INTERACTED).count(), 1)
        self.assertEqual(ParticipantEvent.objects.filter(participant=self.participant,
            kind=ParticipantEvent.Kind.TRAINING_COMPLETED).count(), 1)
        self.client.get(endpoint)
        self.assertEqual(ParticipantEvent.objects.filter(participant=self.participant,
            kind=ParticipantEvent.Kind.PAGE_INTERACTED).count(), 1)

    def test_revoked_link_does_not_complete(self):
        self.link.revoked = True
        self.link.save(update_fields=['revoked'])
        response = self.client.get(reverse('training_complete', args=[self.link.token]))
        self.assertEqual(response.status_code, 410)
        self.assertFalse(ParticipantEvent.objects.filter(participant=self.participant,
            kind=ParticipantEvent.Kind.PAGE_INTERACTED).exists())
