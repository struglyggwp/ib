import io
from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from campaigns.models import Campaign, CampaignParticipant, ParticipantEvent, TrainingLink
from email_templates.models import EmailTemplate
from employees.models import Employee
from delivery.models import CampaignDispatch

from .models import LandingPage
from .origins import normalize_origin, validate_origin


class RawHtmlStorageTests(TestCase):
    def test_exact_original_upload_is_stored_and_served_unchanged(self):
        user = get_user_model().objects.create_superuser(
            'rawadmin', 'rawadmin@example.test', 'SecurePassword!123abc'
        )
        self.client.force_login(user)
        source = (b'<!DOCTYPE html>\n<html><head><style>.test{background:url(data:image/png;base64,AAAA)}</style>'
                  b'</head><body><form action="/ignored"><input name="login"></form>'
                  b'<script>window.test=1</script><h1>Original</h1></body></html>')
        response = self.client.post(reverse('landing_page_create'), {
            'name': 'Сохранённый оригинал',
            'internal_origin': 'http://training.test:8080',
            'html_file': SimpleUploadedFile('original.html', source, content_type='text/html'),
        })
        self.assertEqual(response.status_code, 302)
        page = LandingPage.objects.get(name='Сохранённый оригинал')
        self.assertEqual(bytes(page.original_html), source)
        self.assertEqual(page.source_sha256, __import__('hashlib').sha256(source).hexdigest())
        preview = self.client.get(reverse('landing_page_preview', args=[page.pk]))
        self.assertEqual(preview.content, source)
        self.assertIn('sandbox', preview['Content-Security-Policy'])
        self.assertIn("script-src 'none'", preview['Content-Security-Policy'])
        self.assertIn("form-action 'none'", preview['Content-Security-Policy'])

    def test_windows_1251_bytes_remain_unchanged(self):
        user = get_user_model().objects.create_superuser(
            'cpadmin', 'cpadmin@example.test', 'SecurePassword!123abc'
        )
        self.client.force_login(user)
        source = '<html><meta charset="windows-1251"><h1>Привет</h1></html>'.encode('cp1251')
        response = self.client.post(reverse('landing_page_create'), {
            'name': 'Windows 1251', 'internal_origin': 'http://training.test:8080',
            'html_file': SimpleUploadedFile('original.html', source),
        })
        self.assertEqual(response.status_code, 302)
        page = LandingPage.objects.get(name='Windows 1251')
        preview = self.client.get(reverse('landing_page_preview', args=[page.pk]))
        self.assertEqual(preview.content, source)
        self.assertIn('windows-1251', preview['Content-Type'])

    def test_legacy_page_still_serves_existing_snapshot(self):
        user = get_user_model().objects.create_superuser(
            'legacyadmin', 'legacyadmin@example.test', 'SecurePassword!123abc'
        )
        page = LandingPage.objects.create(
            name='Legacy', source_filename='old.html', source_sha256='b' * 64,
            sanitized_html='<h1>Old snapshot</h1>', internal_origin='http://training.test:8080',
            created_by=user,
        )
        self.client.force_login(user)
        preview = self.client.get(reverse('landing_page_preview', args=[page.pk]))
        self.assertContains(preview, 'Old snapshot')


class LandingPageWorkflowTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = get_user_model().objects.create_superuser('pageadmin', 'pageadmin@example.test', 'SecurePassword!123abc')
        cls.template = EmailTemplate.objects.create(name='Шаблон', subject='Тест', text_body='Учебный текст', status='active', created_by=cls.admin)
        cls.employee = Employee.objects.create(first_name='Иван', last_name='Учебный', email='ivan@training.test')

    def test_upload_preview_and_campaign_tracking(self):
        self.client.force_login(self.admin)
        file = SimpleUploadedFile('page.html', b'<html><h1>Uploaded HTML</h1><script>alert(2)</script></html>', content_type='text/html')
        response = self.client.post(reverse('landing_page_create'), {'name': 'Тренировка', 'internal_origin': 'http://training.test:8080', 'html_file': file})
        self.assertEqual(response.status_code, 302)
        page = LandingPage.objects.get(name='Тренировка')
        preview = self.client.get(reverse('landing_page_preview', args=[page.pk]))
        self.assertContains(preview, 'Uploaded HTML')
        self.assertContains(preview, '<script>alert(2)</script>')
        self.assertEqual(bytes(page.original_html), b'<html><h1>Uploaded HTML</h1><script>alert(2)</script></html>')
        self.assertIn("sandbox", preview['Content-Security-Policy'])
        self.assertEqual(preview['X-Frame-Options'], 'SAMEORIGIN')
        campaign = Campaign.objects.create(name='Тест кампании', email_template=self.template, landing_page=page, status=Campaign.Status.RUNNING, created_by=self.admin)
        participant = CampaignParticipant.objects.create(campaign=campaign, employee=self.employee)
        link = TrainingLink.objects.create(participant=participant, created_by=self.admin, expires_at=timezone.now() + timedelta(days=7))
        # The admin copy-link control must use the configured page host, not the admin host.
        report = self.client.get(reverse("campaign_detail", args=[campaign.pk]))
        self.assertContains(report, f"http://training.test:8080/learn/{link.pk}/")
        self.client.logout()
        parent = self.client.get(reverse('training_visit', args=[link.pk]))
        self.assertEqual(parent.status_code, 200)
        self.assertContains(parent, 'Uploaded HTML')
        self.assertNotContains(parent, '<iframe')
        self.assertNotContains(parent, 'Завершить упражнение')
        self.assertIn('sandbox allow-scripts', parent['Content-Security-Policy'])
        self.assertIn(reverse('training_complete', args=[link.token]), parent.content.decode('utf-8'))
        self.assertTrue(ParticipantEvent.objects.filter(participant=participant, kind='link_visited').exists())
        content = self.client.get(reverse('training_page_content', args=[link.pk]))
        self.assertContains(content, 'Uploaded HTML')
        self.assertEqual(ParticipantEvent.objects.filter(participant=participant, kind='link_visited').count(), 1)
        self.assertIn('script-src', content['Content-Security-Policy'])
        self.assertIn('sandbox allow-scripts', content['Content-Security-Policy'])
        self.assertIn(reverse('training_complete', args=[link.token]), content.content.decode('utf-8'))
        self.assertNotContains(parent, '<iframe')
        submitted = self.client.post(reverse('training_visit', args=[link.pk]), {
            'action_triggered': '1', 'secret_input': 'NOT_FOR_STORAGE'
        })
        self.assertContains(submitted, 'Это была учебная проверка')
        self.assertTrue(ParticipantEvent.objects.filter(participant=participant, kind='page_interacted').exists())
        self.assertNotContains(submitted, 'NOT_FOR_STORAGE')
        self.assertEqual(ParticipantEvent.objects.filter(participant=participant, kind='page_interacted').count(), 1)
        self.assertEqual(self.client.get(reverse('landing_page_preview', args=[page.pk])).status_code, 302)  # login required
        link.revoked = True
        link.save(update_fields=['revoked'])
        self.assertEqual(self.client.get(reverse('training_page_content', args=[link.pk])).status_code, 410)

    def test_bad_domain_prevents_upload_and_open_redirect(self):
        self.client.force_login(self.admin)
        file = SimpleUploadedFile('page.html', b'<html><h1>Test</h1></html>')
        resp = self.client.post(reverse('landing_page_create'), {'name': 'Не разрешён', 'internal_origin': 'http://evil.example/unsafe-path', 'html_file': file})
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(LandingPage.objects.filter(name='Не разрешён').exists())

    @patch.dict('os.environ', {
        'SMTP_HOST': 'mailpit', 'SMTP_PORT': '1025', 'SMTP_USE_STARTTLS': '0',
        'SMTP_FROM_EMAIL': 'training@training.test',
        'SMTP_CAMPAIGN_ENABLED': '1', 'SMTP_ALLOWED_RECIPIENT_DOMAINS': 'training.test',
    })
    def test_one_click_dispatch_uses_selected_page_origin(self):
        self.client.force_login(self.admin)
        page = LandingPage.objects.create(name='Локальная страница', source_filename='page.html',
            source_sha256='b' * 64, sanitized_html='<html><p>Training</p></html>',
            internal_origin='http://training.test:8080', created_by=self.admin)
        campaign = Campaign.objects.create(name='Отправка с HTML', email_template=self.template, landing_page=page, created_by=self.admin)
        CampaignParticipant.objects.create(campaign=campaign, employee=self.employee)
        with self.captureOnCommitCallbacks(execute=False):
            response = self.client.post(reverse('campaign_start', args=[campaign.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(CampaignDispatch.objects.get(campaign=campaign).landing_base_url, 'http://training.test:8080')

    def test_preview_requires_permission(self):
        page = LandingPage.objects.create(name='Page', source_filename='a.html', source_sha256='a'*64,
                                          sanitized_html='<html><p>Safe</p></html>', internal_origin='http://127.0.0.1:8080', created_by=self.admin)
        user = get_user_model().objects.create_user('viewer', password='SecurePasswordForTests!')
        self.client.force_login(user)
        self.assertEqual(self.client.get(reverse('landing_page_preview', args=[page.pk])).status_code, 403)

    def test_old_campaign_without_page_unchanged(self):
        campaign = Campaign.objects.create(name='Old', status=Campaign.Status.RUNNING, created_by=self.admin)
        participant = CampaignParticipant.objects.create(campaign=campaign, employee=self.employee)
        link = TrainingLink.objects.create(participant=participant, created_by=self.admin, expires_at=timezone.now() + timedelta(days=7))
        self.assertContains(self.client.get(reverse('training_visit', args=[link.pk])), 'Как распознать')
        self.assertEqual(self.client.get(reverse('training_page_content', args=[link.pk])).status_code, 404)

    def test_origin_normalization(self):
        self.assertEqual(validate_origin('http://training.test:8080/'), 'http://training.test:8080')
        self.assertEqual(validate_origin('http://192.168.1.50:8080'), 'http://192.168.1.50:8080')
        self.assertEqual(validate_origin('http://portal.lan'), 'http://portal.lan')
        from django.core.exceptions import ValidationError
        self.assertEqual(normalize_origin('http://public.example/'), 'http://public.example')
        with self.assertRaises(ValidationError):
            normalize_origin('http://public.example/path')


class RegisteredHostTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        admin = get_user_model().objects.create_superuser('hostadmin', 'hostadmin@training.test', 'SecurePassword!123abc')
        cls.employee = Employee.objects.create(first_name='Тест', last_name='Сотрудник', email='host@training.test')
        cls.page1 = LandingPage.objects.create(name='Page A', source_filename='a.html', source_sha256='a'*64,
            sanitized_html='<h1>Alpha</h1>', internal_origin='http://alpha.test:8080', created_by=admin)
        cls.page2 = LandingPage.objects.create(name='Page B', source_filename='b.html', source_sha256='b'*64,
            sanitized_html='<h1>Beta</h1>', internal_origin='http://beta.lan:8080', created_by=admin)
        cls.campaign = Campaign.objects.create(name='LAN test', landing_page=cls.page1, status=Campaign.Status.RUNNING, created_by=admin)
        participant = CampaignParticipant.objects.create(campaign=cls.campaign, employee=cls.employee)
        cls.link = TrainingLink.objects.create(participant=participant, created_by=admin,
            expires_at=timezone.now() + timedelta(days=7))

    def test_registered_names_accept_tracking_without_env(self):
        url = reverse('training_visit', args=[self.link.pk])
        self.assertEqual(self.client.get(url, HTTP_HOST='alpha.test:8080').status_code, 200)
        self.assertEqual(self.client.get(url, HTTP_HOST='beta.lan:8080').status_code, 200)

    def test_unknown_hostname_rejected(self):
        url = reverse('training_visit', args=[self.link.pk])
        self.assertEqual(self.client.get(url, HTTP_HOST='unknown.test:8080').status_code, 400)
        self.assertEqual(self.client.get('/', HTTP_HOST='alpha.test:8080').status_code, 400)

    def test_admin_access_via_lan_ip(self):
        response = self.client.get('/admin/login/', HTTP_HOST='192.168.1.50:8080')
        self.assertEqual(response.status_code, 200)


class TrackingHostnameTests(TestCase):
    @patch.dict('os.environ', {'SMTP_TRACKING_BASE_URL': 'http://tracker.lan:8080', 'SMTP_OPEN_TRACKING_ENABLED': '1'})
    def test_optional_tracking_host_does_not_expose_admin(self):
        import uuid
        pixel_url = reverse('email_open_pixel', args=[uuid.uuid4()])
        pixel = self.client.get(pixel_url, HTTP_HOST='tracker.lan:8080')
        self.assertEqual(pixel.status_code, 200)
        self.assertEqual(pixel['Content-Type'], 'image/gif')
        self.assertEqual(self.client.get('/admin/login/', HTTP_HOST='tracker.lan:8080').status_code, 400)


class SandboxedInteractionCsrfTests(TestCase):
    """A legacy opaque-origin learner action must not turn into a CSRF 403."""

    @classmethod
    def setUpTestData(cls):
        from django.contrib.auth import get_user_model
        from django.utils import timezone
        from datetime import timedelta
        cls.admin = get_user_model().objects.create_superuser(
            "interaction-admin", "interaction@example.test", "TestPassword123!",
        )
        cls.employee = Employee.objects.create(first_name="Тест", last_name="Сотрудник", email="action@training.test")
        cls.page = LandingPage.objects.create(
            name="Загруженная страница", source_filename="page.html", source_sha256="c" * 64,
            sanitized_html='<html><body><button>Продолжить</button></body></html>',
            internal_origin="http://action.test:8080", created_by=cls.admin,
        )
        cls.campaign = Campaign.objects.create(
            name="Тест кнопки", status=Campaign.Status.RUNNING,
            landing_page=cls.page, created_by=cls.admin,
        )
        cls.participant = CampaignParticipant.objects.create(campaign=cls.campaign, employee=cls.employee)
        cls.link = TrainingLink.objects.create(
            participant=cls.participant, created_by=cls.admin,
            expires_at=timezone.now() + timedelta(days=1),
        )

    def test_opaque_origin_can_record_interaction_without_csrf_cookie(self):
        from django.test import Client
        action_url = reverse("training_interaction", args=[self.link.token])
        # Public personal links now serve source HTML directly, not a wrapper iframe.
        parent = self.client.get(reverse("training_visit", args=[self.link.token]))
        self.assertNotContains(parent, '<iframe')
        self.assertContains(parent, reverse("training_complete", args=[self.link.token]))
        visitor = Client(enforce_csrf_checks=True)
        result = visitor.post(action_url, {"action_triggered": "1", "password": "SENSITIVE_DO_NOT_STORE"},
                              HTTP_HOST="action.test:8080", HTTP_ORIGIN="null")
        self.assertEqual(result.status_code, 200)
        self.assertContains(result, "Это была учебная проверка")
        self.assertNotContains(result, "SENSITIVE_DO_NOT_STORE")
        self.assertEqual(ParticipantEvent.objects.filter(
            participant=self.participant, kind=ParticipantEvent.Kind.PAGE_INTERACTED,
        ).count(), 1)
        self.assertEqual(ParticipantEvent.objects.filter(
            participant=self.participant, kind=ParticipantEvent.Kind.TRAINING_COMPLETED,
        ).count(), 1)

    def test_duplicate_action_deduped_and_get_rejected(self):
        from django.test import Client
        visitor = Client(enforce_csrf_checks=True)
        url = reverse("training_interaction", args=[self.link.token])
        self.assertEqual(visitor.get(url).status_code, 405)
        for _ in range(2):
            self.assertEqual(visitor.post(url, {"action_triggered": "1"}, HTTP_ORIGIN="null").status_code, 200)
        self.assertEqual(ParticipantEvent.objects.filter(
            participant=self.participant, kind=ParticipantEvent.Kind.PAGE_INTERACTED,
        ).count(), 1)

    def test_admin_post_keeps_csrf_protection(self):
        from django.test import Client
        visitor = Client(enforce_csrf_checks=True)
        visitor.force_login(self.admin)
        result = visitor.post(reverse("campaign_create"), {"name": "Should not pass"}, HTTP_ORIGIN="null")
        self.assertEqual(result.status_code, 403)

    def test_revoked_link_rejected(self):
        self.link.revoked = True
        self.link.save(update_fields=["revoked"])
        from django.test import Client
        visitor = Client(enforce_csrf_checks=True)
        result = visitor.post(reverse("training_interaction", args=[self.link.token]),
                              {"action_triggered": "1"}, HTTP_ORIGIN="null")
        self.assertEqual(result.status_code, 410)
        self.assertFalse(ParticipantEvent.objects.filter(
            participant=self.participant, kind=ParticipantEvent.Kind.PAGE_INTERACTED,
        ).exists())
