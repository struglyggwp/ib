"""Validate a user-chosen URL origin without public DNS dependency.

An origin is an address, not a DNS record. Clients still need local DNS/hosts
and a reachable Nginx port. Registration in Django does NOT reroute traffic.
"""
import ipaddress
import re
from urllib.parse import urlsplit
from django.core.exceptions import ValidationError

LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$", flags=re.I)

def normalize_origin(value):
    value = (value or "").strip().rstrip("/")
    try:
        url = urlsplit(value)
        port = url.port
    except ValueError as exc:
        raise ValidationError("Некорректное имя или порт.") from exc
    if (url.scheme not in {"http", "https"} or not url.hostname
            or url.username or url.password or url.path or url.query
            or url.fragment or port == 0):
        raise ValidationError("Укажите http(s)://имя[:порт] без пути и параметров.")
    hostname = url.hostname.lower()
    if len(hostname) > 253 or not hostname.isascii():
        raise ValidationError("Укажите имя ASCII/Punycode длиной не более 253 символов.")
    try:
        address = ipaddress.ip_address(hostname)
    except ValueError:
        if not all(LABEL.fullmatch(part) for part in hostname.split('.')):
            raise ValidationError("Некорректное доменное имя.")
        normalized_host = hostname
    else:
        if (address.is_multicast or address.is_unspecified or address.is_link_local):
            raise ValidationError("Этот IP нельзя использовать для учебного веб-адреса.")
        normalized_host = f"[{hostname}]" if ':' in hostname else hostname
    default_port = 443 if url.scheme == 'https' else 80
    return f"{url.scheme}://{normalized_host}" + (f":{port}" if port and port != default_port else "")

def validate_origin(value):
    return normalize_origin(value)
