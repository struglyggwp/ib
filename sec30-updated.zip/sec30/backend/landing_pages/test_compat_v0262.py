"""Non-executing safety/compatibility checks for standalone uploaded HTML."""
from django.test import SimpleTestCase
from .response import _strip_embedded_csp_meta


class EmbeddedCspCompatibilityTests(SimpleTestCase):
    def test_own_csp_meta_removed_only_from_served_copy(self):
        original = (b'<html><head><meta http-equiv="Content-Security-Policy" '
                    b'content="script-src none"><meta charset="utf-8"></head>'
                    b'<body><button>OK</button></body></html>')
        served = _strip_embedded_csp_meta(original)
        self.assertNotIn(b'Content-Security-Policy', served)
        self.assertIn(b'<meta charset="utf-8">', served)
        self.assertIn(b'<button>OK</button>', served)
        self.assertIn(b'Content-Security-Policy', original)

    def test_does_not_alter_normal_page(self):
        original = b'<html><head><title>Training</title></head><body><p>OK</p></body></html>'
        self.assertEqual(_strip_embedded_csp_meta(original), original)
