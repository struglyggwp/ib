from django.core.exceptions import ValidationError
from django.http import HttpResponse
from django.test import RequestFactory, SimpleTestCase, override_settings
from landing_pages.middleware import RegisteredPageHostMiddleware
from landing_pages.origins import normalize_origin

class LocalAddressTests(SimpleTestCase):
    def test_custom_lan_host_and_http_port(self):
        self.assertEqual(normalize_origin('http://dudud.lan:8080/'),'http://dudud.lan:8080')
        self.assertEqual(normalize_origin('http://dudud.lan/'),'http://dudud.lan')
        self.assertEqual(normalize_origin('https://portal.corp.example/'),'https://portal.corp.example')
    def test_reject_credential_urls_and_paths(self):
        for origin in ('http://username:pass@dudud.lan','http://dudud.lan/path','ftp://dudud.lan'):
            with self.assertRaises(ValidationError): normalize_origin(origin)


@override_settings(ADMIN_HTTPS_ONLY=True, ADMIN_HOSTS=["awareness.internal"])
class AdminHttpsPolicyTests(SimpleTestCase):
    def test_requires_https_for_panel_and_allows_http_for_public_training(self):
        factory = RequestFactory(HTTP_HOST="awareness.internal")
        middleware = RegisteredPageHostMiddleware(lambda request: HttpResponse())

        self.assertEqual(middleware(factory.get("/admin/login/")).status_code, 403)
        self.assertEqual(middleware(factory.get("/admin/login/", secure=True)).status_code, 200)
        for path in ("/learn/", "/track/open/"):
            with self.subTest(path=path):
                self.assertEqual(middleware(factory.get(path)).status_code, 200)
