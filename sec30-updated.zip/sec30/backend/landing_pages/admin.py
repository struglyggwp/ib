from django.contrib import admin
from .models import LandingPage


@admin.register(LandingPage)
class LandingPageAdmin(admin.ModelAdmin):
    list_display = ("name", "internal_origin", "active", "created_at")
    list_filter = ("active", "created_at")
    search_fields = ("name", "source_filename", "internal_origin")
    readonly_fields = ("id", "source_filename", "source_sha256", "sanitized_html", "source_charset", "internal_origin", "created_by", "created_at")
    def has_add_permission(self, request):
        return False  # Upload through validated import form only.
    def has_change_permission(self, request, obj=None):
        return False
    def has_delete_permission(self, request, obj=None):
        return False
