from django import forms
from django.core.exceptions import ValidationError

from .origins import validate_origin


class UploadPageForm(forms.Form):
    name = forms.CharField(label="Название", max_length=160, widget=forms.TextInput(attrs={"class": "form-control"}))
    html_file = forms.FileField(label="HTML-файл SingleFile", help_text="HTML, UTF-8 или Windows-1251, до 8 МБ. Файл сохраняется без изменения разметки, стилей и изображений.")
    internal_origin = forms.CharField(label="Внутренний адрес", max_length=255,
                                      widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "http://dudud.lan:8080"}),
                                      help_text="Например, http://training.test:8080 или http://192.168.1.50:8080. Имя должно вести на сервер платформы во внутренней сети.")

    def clean_internal_origin(self):
        return validate_origin(self.cleaned_data["internal_origin"])

    def clean_html_file(self):
        file = self.cleaned_data["html_file"]
        if file.size == 0 or file.size > 8 * 1024 * 1024:
            raise ValidationError("Размер файла должен быть от 1 байта до 8 МБ.")
        if not file.name.lower().endswith((".html", ".htm")):
            raise ValidationError("Загрузите HTML-файл с расширением .html или .htm.")
        return file
