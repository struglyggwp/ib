from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("landing_pages", "0001_initial")]
    operations = [
        migrations.AddField(
            model_name="landingpage",
            name="original_html",
            field=models.BinaryField(blank=True, editable=False, null=True, verbose_name="Оригинальный HTML без изменений"),
        ),
        migrations.AddField(
            model_name="landingpage",
            name="source_charset",
            field=models.CharField(default="utf-8", max_length=20, verbose_name="Кодировка файла"),
        ),
    ]
