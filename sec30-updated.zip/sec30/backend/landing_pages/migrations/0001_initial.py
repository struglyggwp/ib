import uuid
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name="LandingPage",
            fields=[
                ("id", models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, serialize=False)),
                ("name", models.CharField(max_length=160, verbose_name="Название")),
                ("source_filename", models.CharField(max_length=255, verbose_name="Имя исходного файла")),
                ("source_sha256", models.CharField(max_length=64)),
                ("sanitized_html", models.TextField(verbose_name="Очищенный HTML")),
                ("internal_origin", models.URLField(max_length=255, verbose_name="Внутренний адрес сайта")),
                ("active", models.BooleanField(default=True, verbose_name="Доступна для новых кампаний")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("created_by", models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.PROTECT)),
            ],
            options={"verbose_name": "учебная HTML-страница", "verbose_name_plural": "учебные HTML-страницы", "ordering": ["-created_at"]},
        ),
    ]
