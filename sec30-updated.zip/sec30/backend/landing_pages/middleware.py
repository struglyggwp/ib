"""Accept multiple registered LAN hostnames without editing DJANGO_ALLOWED_HOSTS.

Host-header safety: this middleware runs before Django's SecurityMiddleware and
rejects unrecognised hosts. Registered landing hostnames serve public training
and tracking routes ONLY, never the administrative UI.
"""
import ipaddress
import os
from urllib.parse import urlsplit

from django.conf import settings
from django.core.exceptions import DisallowedHost
from django.http import HttpResponseBadRequest, HttpResponseForbidden
from django.http.request import split_domain_port


PUBLIC_TRAINING_PATHS = ("/learn/", "/track/open/")


def _private_ip(host):
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return (ip.is_private or ip.is_loopback) and not (
        ip.is_multicast or ip.is_unspecified or ip.is_link_local
    )


class RegisteredPageHostMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            raw_host = request.get_host()
        except DisallowedHost:
            return HttpResponseBadRequest("Неверное имя сайта")
        host, port = split_domain_port(raw_host)
        host = host.lower()
        if not host:
            return HttpResponseBadRequest("Неверное имя сайта")

        # The admin UI can be accessed using localhost or the LAN IP without a
        # per-computer ALLOWED_HOSTS edit. Do not grant the admin UI to branded
        # training aliases.
        admin_names = {h.lower() for h in settings.ADMIN_HOSTS if h != "*"}
        # Django test client uses testserver as its default Host.
        admin_names.add("testserver")
        public_training_path = request.path.startswith(PUBLIC_TRAINING_PATHS)
        if host in admin_names or _private_ip(host):
            if settings.ADMIN_HTTPS_ONLY and not public_training_path and not request.is_secure():
                return HttpResponseForbidden("Для входа в панель управления откройте её HTTPS-адрес.")
            return self.get_response(request)

        if not public_training_path:
            return HttpResponseBadRequest("Это имя доступно только для учебных ссылок")

        # Optional independent host for email-open signals. It does not expose admin.
        if request.path.startswith("/track/open/"):
            tracking_origin = os.environ.get("SMTP_TRACKING_BASE_URL", "").strip()
            if tracking_origin:
                try:
                    from .origins import normalize_origin
                    parsed_tracking = urlsplit(normalize_origin(tracking_origin))
                    requested_port = int(port) if port else (443 if request.is_secure() else 80)
                    expected_port = parsed_tracking.port or (443 if parsed_tracking.scheme == "https" else 80)
                    if (parsed_tracking.hostname == host and expected_port == requested_port
                            and parsed_tracking.scheme == request.scheme):
                        return self.get_response(request)
                except (ValueError, TypeError):
                    pass

        # A hostname is authorised only after an admin created a landing page
        # with that exact origin. Compare scheme and port to prevent mismatches.
        from .models import LandingPage
        for origin in LandingPage.objects.values_list("internal_origin", flat=True):
            try:
                parsed = urlsplit(origin)
                configured_port = parsed.port or (443 if parsed.scheme == "https" else 80)
            except ValueError:
                continue  # Malformed legacy record must not turn into a 500.
            requested_port = int(port) if port else (443 if request.is_secure() else 80)
            if (parsed.hostname == host and configured_port == requested_port
                    and parsed.scheme == request.scheme):
                return self.get_response(request)
        return HttpResponseBadRequest("Учебный адрес не зарегистрирован")
