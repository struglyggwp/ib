"""Unmodified storage and controlled, isolated training interaction bridge."""
import re
import secrets
import json
from html import escape

from django.http import HttpResponse


PAGE_CSP = (
    "sandbox; default-src 'none'; script-src 'none'; connect-src 'none'; "
    "img-src data:; font-src data:; style-src 'unsafe-inline'; "
    "form-action 'none'; base-uri 'none'; frame-ancestors 'self'"
)

# An additional script is inserted into the *served copy only*.
# The original HTML stored in the database is never changed.
# Injected in the served copy of the uploaded HTML, never written to storage.
# It never reads any form field or sends a form to the server. User interactions
# navigate to a distinct completion URL that records only an event and time.
INTERACTION_BRIDGE = r"""(function(){
  var completed = false;
  var target = __COMPLETION_URL__;
  function complete(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }
    if (completed) return;
    completed = true;
    window.location.assign(target);
  }
  document.addEventListener('submit', complete, true);
  document.addEventListener('click', function(event) {
    var node = event.target;
    if (node && node.nodeType !== 1) node = node.parentElement;
    if (!node || !node.closest) return;
    var trigger = node.closest(
      'button, input[type="submit"], input[type="button"], input[type="image"], ' +
      '[role="button"], [onclick], a[href]'
    );
    if (trigger) complete(event);
  }, true);
})();"""



def _payload(page):
    if page.original_html is not None:
        return bytes(page.original_html), page.source_charset
    return page.sanitized_html.encode('utf-8'), 'utf-8'


# Some uploaded standalone HTML files contain their own CSP <meta> policy.
# It can block the strictly nonce-authorized training controller even though
# the server response sends the more restrictive policy below. Remove ONLY
# CSP meta elements from the served copy. Stored bytes and admin preview stay
# intact, and the server's sandbox/CSP remain the security boundary.
_META_CSP = re.compile(
    rb'<meta\s+(?=[^>]*\bhttp-equiv\s*=\s*(?:[\"\']?content-security-policy[\"\']?))[^>]*>',
    flags=re.IGNORECASE,
)


def _strip_embedded_csp_meta(source: bytes) -> bytes:
    return _META_CSP.sub(b'', source)


def _inject_script(source: bytes, script: bytes):
    # Insert at start of head when present, avoiding parsing or reserialization.
    for pattern in (rb'<head\b[^>]*>', rb'<body\b[^>]*>'):
        match = re.search(pattern, source, flags=re.IGNORECASE)
        if match:
            return source[:match.end()] + script + source[match.end():]
    end = re.search(rb'</body\s*>', source, flags=re.IGNORECASE)
    if end:
        return source[:end.start()] + script + source[end.start():]
    return source + script


def static_page_response(page, *, interaction_capture=False, completion_url=None):
    payload, charset = _payload(page)
    csp = PAGE_CSP
    if interaction_capture:
        if not completion_url or not completion_url.startswith('/learn/'):
            raise ValueError("A local completion URL is required for an interactive page")
        nonce = secrets.token_urlsafe(24)
        # Only this one injected controller can execute. Original scripts remain inert.
        script_body = INTERACTION_BRIDGE.replace(
            "__COMPLETION_URL__", json.dumps(completion_url, ensure_ascii=True)
        )
        controller = (
            f'<script nonce="{escape(nonce, quote=True)}">{script_body}</script>'
        ).encode('ascii')
        payload = _strip_embedded_csp_meta(payload)
        payload = _inject_script(payload, controller)
        csp = (
            "sandbox allow-scripts; default-src 'none'; "
            f"script-src 'nonce-{nonce}'; script-src-attr 'none'; "
            "connect-src 'none'; img-src data:; font-src data:; "
            "style-src 'unsafe-inline'; form-action 'none'; "
            "base-uri 'none'; frame-ancestors 'self'"
        )
    response = HttpResponse(payload, content_type=f'text/html; charset={charset}')
    response['Content-Security-Policy'] = csp
    response['X-Frame-Options'] = 'SAMEORIGIN'
    response['Cache-Control'] = 'private, no-store'
    response['Referrer-Policy'] = 'no-referrer'
    response['X-Robots-Tag'] = 'noindex, nofollow, noarchive'
    response['Cross-Origin-Resource-Policy'] = 'same-origin'
    return response
