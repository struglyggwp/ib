import hashlib

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import ProtectedError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from .forms import UploadPageForm
from .models import LandingPage
from .response import static_page_response


@login_required
@permission_required("landing_pages.view_landingpage", raise_exception=True)
@require_GET
def page_list(request):
    pages = LandingPage.objects.all().order_by("-created_at")
    return render(request, "landing_pages/list.html", {"pages": pages})


@login_required
@permission_required("landing_pages.add_landingpage", raise_exception=True)
@require_http_methods(["GET", "POST"])
def page_create(request):
    form = UploadPageForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        source = form.cleaned_data["html_file"].read()
        # Preserve every byte of the uploaded HTML. Charset detection is for the
        # HTTP Content-Type header only; no parser, sanitizer or rewriting runs.
        try:
            source.decode("utf-8-sig")
            source_charset = "utf-8"
        except UnicodeDecodeError:
            source_charset = "windows-1251"
        page = LandingPage.objects.create(
            name=form.cleaned_data["name"],
            source_filename=form.cleaned_data["html_file"].name[:255],
            source_sha256=hashlib.sha256(source).hexdigest(),
            internal_origin=form.cleaned_data["internal_origin"],
            sanitized_html="",  # Used only by pre-v0.19.2 snapshots.
            original_html=source,
            source_charset=source_charset,
            created_by=request.user,
        )
        messages.success(request, "HTML сохранён без изменений. Предпросмотр работает в изоляции.")
        return redirect("landing_page_detail", page_id=page.pk)
    return render(request, "landing_pages/form.html", {"form": form})


@login_required
@permission_required("landing_pages.view_landingpage", raise_exception=True)
@require_GET
def page_detail(request, page_id):
    page = get_object_or_404(LandingPage, pk=page_id)
    return render(request, "landing_pages/detail.html", {"page": page, "campaign_count": page.campaigns.count()})


@login_required
@permission_required("landing_pages.view_landingpage", raise_exception=True)
@require_GET
def page_preview(request, page_id):
    page = get_object_or_404(LandingPage, pk=page_id)
    return static_page_response(page)


@login_required
@permission_required("landing_pages.change_landingpage", raise_exception=True)
@require_POST
def page_archive(request, page_id):
    page = get_object_or_404(LandingPage, pk=page_id)
    # Existing running campaigns keep access to their previously selected page.
    page.active = False
    page.save(update_fields=["active"])
    messages.success(request, "Страница архивирована. Новые кампании не смогут её выбрать.")
    return redirect("landing_page_detail", page_id=page.pk)
