from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from .models import Department, Employee, Position


class EmployeeCatalogTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="tester", password="test-password-123")
        self.user.user_permissions.add(*Permission.objects.filter(
            content_type__app_label="employees", codename__in=["view_employee", "add_employee"],
        ))
        self.client.force_login(self.user)

    def test_employee_list_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse("employee_list"))
        self.assertEqual(response.status_code, 302)

    def test_create_employee(self):
        response = self.client.post(reverse("employee_create"), {
            "first_name": "Иван", "last_name": "Иванов", "middle_name": "Иванович",
            "email": "ivanov@example.test", "department": "", "position": "", "is_active": "on",
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Employee.objects.filter(email="ivanov@example.test").exists())

    def test_employee_email_is_unique(self):
        Employee.objects.create(first_name="Иван", last_name="Иванов", email="same@example.test")
        response = self.client.post(reverse("employee_create"), {
            "first_name": "Пётр", "last_name": "Петров", "email": "same@example.test",
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Employee.objects.filter(email="same@example.test").count(), 1)

    def test_search_by_email(self):
        Employee.objects.create(first_name="Иван", last_name="Иванов", email="ivanov@example.test")
        response = self.client.get(reverse("employee_list"), {"q": "ivanov@"})
        self.assertContains(response, "ivanov@example.test")

    def test_department_and_position_relationships(self):
        department = Department.objects.create(name="ИТ")
        position = Position.objects.create(name="Инженер")
        employee = Employee.objects.create(first_name="Анна", last_name="Смирнова", email="anna@example.test", department=department, position=position)
        self.assertEqual(employee.department.name, "ИТ")
        self.assertEqual(employee.position.name, "Инженер")

    def test_catalog_paginates_filtered_results(self):
        Employee.objects.bulk_create([
            Employee(first_name="Иван", last_name="Иванов", email=f"{num:02d}@example.test")
            for num in range(26)
        ])
        url = reverse("employee_list")
        first_page = self.client.get(url, {"q": "@example.test"})
        self.assertEqual(len(first_page.context["page"]), 25)
        self.assertContains(first_page, "?q=%40example.test&amp;page=2")
        second_page = self.client.get(url, {"q": "@example.test", "page": 2})
        self.assertEqual(len(second_page.context["page"]), 1)

    def upload_csv(self, content, encoding="utf-8"):
        upload = SimpleUploadedFile("staff.csv", content.encode(encoding), content_type="text/csv")
        return self.client.post(reverse("employee_csv_import"), {"file": upload})

    def test_csv_preview_requires_confirmation_and_preserves_encoding(self):
        self.user.user_permissions.add(*Permission.objects.filter(
            content_type__app_label="employees", codename__in=["add_department", "add_position"],
        ))
        response = self.upload_csv(
            "first_name;last_name;email;department;position;is_active\n"
            "Ирина;Иванова;IRINA@example.test;Отдел;Инженер;нет\n"
            "Павел;Петров;pavel@example.test;отдел;Инженер;да\n", encoding="cp1251",
        )
        self.assertContains(response, "Подтвердить импорт")
        self.assertContains(response, "Ирина")
        self.assertFalse(Employee.objects.exists())
        self.assertFalse(Department.objects.exists())

        confirm = {"confirm": response.context["preview"]["token"]}
        response = self.client.post(reverse("employee_csv_import"), confirm)
        self.assertRedirects(response, reverse("employee_list"))
        irina = Employee.objects.get(email="irina@example.test")
        self.assertFalse(irina.is_active)
        self.assertEqual(irina.position.name, "Инженер")
        self.assertEqual(Department.objects.count(), 1)
        self.assertEqual(Employee.objects.count(), 2)
        self.assertContains(self.client.post(reverse("employee_csv_import"), confirm), "Предпросмотр устарел")
        self.assertEqual(Employee.objects.count(), 2)

    def test_csv_reports_oversized_field_on_its_row(self):
        response = self.upload_csv(
            "first_name,last_name,email\n"
            "Ирина,Иванова,irina@example.test\n"
            f"{'И' * 101},Петров,pavel@example.test\n"
        )
        self.assertContains(response, "Строка 3 — first_name")
        self.assertIsNone(response.context["preview"])
        self.assertFalse(Employee.objects.exists())

    def test_csv_rechecks_duplicates_after_preview(self):
        response = self.upload_csv(
            "first_name,last_name,email\n"
            "Ирина,Иванова,irina@example.test\n"
            "Павел,Петров,pavel@example.test\n"
        )
        Employee.objects.create(first_name="Павел", last_name="Петров", email="PAVEL@example.test")
        result = self.client.post(reverse("employee_csv_import"), {"confirm": response.context["preview"]["token"]})
        self.assertContains(result, "Строка 3 — pavel@example.test уже есть")
        self.assertFalse(Employee.objects.filter(email="irina@example.test").exists())

    def test_csv_cannot_create_dictionary_entries_without_permission(self):
        response = self.upload_csv("first_name,last_name,email,department\nИрина,Иванова,irina@example.test,Отдел\n")
        self.assertContains(response, "нужны права на справочник")
        self.assertIsNone(response.context["preview"])
        self.assertFalse(Department.objects.exists())
