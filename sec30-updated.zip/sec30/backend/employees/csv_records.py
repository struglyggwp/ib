import csv
import io

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models.functions import Lower

from .models import Department, Employee, Position


REQUIRED_COLUMNS = {"first_name", "last_name", "email"}
OPTIONAL_COLUMNS = {"middle_name", "department", "position", "is_active"}
TEXT_FIELDS = {
    "first_name": Employee._meta.get_field("first_name"),
    "last_name": Employee._meta.get_field("last_name"),
    "middle_name": Employee._meta.get_field("middle_name"),
    "email": Employee._meta.get_field("email"),
    "department": Department._meta.get_field("name"),
    "position": Position._meta.get_field("name"),
}
TRUE_VALUES = {"", "1", "true", "yes", "да"}
FALSE_VALUES = {"0", "false", "no", "нет"}
MAX_ERRORS = 25


def read_records(upload):
    raw = upload.read()
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        try:
            content = raw.decode("cp1251")
        except UnicodeDecodeError:
            return [], ["Сохраните CSV в UTF-8 или Windows-1251."]

    stream = io.StringIO(content, newline="")
    header = stream.readline()
    stream.seek(0)
    delimiter = ";" if header.count(";") > header.count(",") else ","
    reader = csv.reader(stream, delimiter=delimiter, strict=True)
    rows, errors, seen = [], [], set()

    try:
        columns = [value.strip() for value in next(reader, [])]
        if not REQUIRED_COLUMNS.issubset(columns):
            return [], ["В заголовке нужны столбцы first_name, last_name и email."]
        if len(set(columns)) != len(columns):
            return [], ["Названия столбцов не должны повторяться."]

        for values in reader:
            if len(errors) >= MAX_ERRORS:
                break
            line = reader.line_num
            if not values:
                continue
            if len(values) > len(columns):
                errors.append(f"Строка {line} — значений больше, чем заголовков столбцов.")
                continue
            cells = dict(zip(columns, values))
            row = {"line": line}
            errors_before_row = len(errors)
            for name, field in TEXT_FIELDS.items():
                value = cells.get(name, "").strip()
                if name == "email":
                    value = value.lower()
                if "\x00" in value:
                    errors.append(f"Строка {line} — {name} содержит недопустимый символ.")
                    continue
                if not value and name in OPTIONAL_COLUMNS:
                    row[name] = ""
                    continue
                try:
                    row[name] = field.clean(value, None)
                except ValidationError as error:
                    errors.extend(f"Строка {line} — {name}. {message}" for message in error.messages)

            active = cells.get("is_active", "").strip().lower()
            if active not in TRUE_VALUES and active not in FALSE_VALUES:
                errors.append(f"Строка {line} — is_active. Укажите да/нет, true/false или 1/0.")
            if row.get("email") in seen:
                errors.append(f"Строка {line} — {row['email']} повторяется в файле.")
            if len(errors) == errors_before_row:
                row["is_active"] = active in TRUE_VALUES
                rows.append(row)
                seen.add(row["email"])
    except csv.Error:
        errors.append(f"Строка {reader.line_num} — ошибка формата CSV. Проверьте кавычки и размер поля.")

    if not rows and not errors:
        errors.append("В CSV-файле нет строк для импорта.")
    return rows, errors


def _by_lower(field, manager, values):
    matches = {}
    values = sorted(set(values))
    for start in range(0, len(values), 1000):
        batch = values[start:start + 1000]
        for instance in manager.alias(normalized=Lower(field)).filter(normalized__in=batch).order_by("pk"):
            matches.setdefault(getattr(instance, field).lower(), instance)
    return matches


def _names(rows, field):
    names = {}
    for row in rows:
        name = row[field]
        if name:
            names.setdefault(name.lower(), name)
    return names


def check_records(rows, user):
    emails = _by_lower("email", Employee.objects, (row["email"] for row in rows))
    errors = [
        f"Строка {row['line']} — {row['email']} уже есть в каталоге."
        for row in rows if row["email"] in emails
    ]
    for field, model in (("department", Department), ("position", Position)):
        if user.has_perm(f"employees.add_{field}"):
            continue
        existing = _by_lower("name", model.objects, _names(rows, field))
        errors.extend(
            f"Строка {row['line']} — для добавления значения {field} «{row[field]}» нужны права на справочник."
            for row in rows if row[field] and row[field].lower() not in existing
        )
    return errors


def _resolve_names(model, rows, field, can_create):
    names = _names(rows, field)
    existing = _by_lower("name", model.objects, names)
    missing = [model(name=names[key]) for key in sorted(names.keys() - existing.keys())]
    if missing and not can_create:
        raise ValidationError("Справочники изменились. Проверьте CSV ещё раз.")
    model.objects.bulk_create(missing, batch_size=500, ignore_conflicts=True)
    if missing:
        existing.update(_by_lower("name", model.objects, (obj.name.lower() for obj in missing)))
    return existing


@transaction.atomic
def import_records(rows, user):
    conflicts = check_records(rows, user)
    if conflicts:
        raise ValidationError(conflicts)
    departments = _resolve_names(Department, rows, "department", user.has_perm("employees.add_department"))
    positions = _resolve_names(Position, rows, "position", user.has_perm("employees.add_position"))
    Employee.objects.bulk_create([
        Employee(
            first_name=row["first_name"],
            last_name=row["last_name"],
            middle_name=row["middle_name"],
            email=row["email"],
            is_active=row["is_active"],
            department=departments.get(row["department"].lower()),
            position=positions.get(row["position"].lower()),
        )
        for row in rows
    ], batch_size=500)
