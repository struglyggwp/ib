from time import time
from uuid import uuid4

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods

from .csv_records import MAX_ERRORS, check_records, import_records, read_records
from .forms import CSVImportForm, EmployeeForm
from .models import Department, Employee


IMPORT_DRAFT_KEY = "employee_import_draft"
IMPORT_DRAFT_LIFETIME = 30 * 60


@login_required
@permission_required("employees.view_employee", raise_exception=True)
def employee_list(request):
    qs = Employee.objects.select_related("department", "position").order_by("last_name", "first_name", "pk")
    query = request.GET.get("q", "").strip()[:200]
    department = request.GET.get("department", "").strip()
    status = request.GET.get("status", "").strip()
    if query:
        qs = qs.filter(Q(first_name__icontains=query) | Q(last_name__icontains=query) | Q(middle_name__icontains=query) | Q(email__icontains=query))
    if department.isascii() and department.isdecimal() and len(department) <= 18:
        qs = qs.filter(department_id=int(department))
    if status in ("active", "inactive"):
        qs = qs.filter(is_active=(status == "active"))
    page = Paginator(qs, 25).get_page(request.GET.get("page"))
    return render(request, "employees/list.html", {
        "page": page, "query": query, "selected_department": department,
        "selected_status": status, "departments": Department.objects.filter(is_active=True),
    })


@login_required
@permission_required("employees.add_employee", raise_exception=True)
@require_http_methods(["GET", "POST"])
def employee_create(request):
    form = EmployeeForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        employee = form.save()
        messages.success(request, "Сотрудник добавлен в каталог.")
        if request.user.has_perm("employees.view_employee"):
            return redirect("employee_detail", employee_id=employee.pk)
        return redirect("dashboard")
    return render(request, "employees/form.html", {"form": form, "page_title": "Новый сотрудник"})


@login_required
@permission_required("employees.change_employee", raise_exception=True)
@require_http_methods(["GET", "POST"])
def employee_edit(request, employee_id):
    employee = get_object_or_404(Employee, pk=employee_id)
    form = EmployeeForm(request.POST or None, instance=employee)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Данные сотрудника обновлены.")
        if request.user.has_perm("employees.view_employee"):
            return redirect("employee_detail", employee_id=employee.pk)
        return redirect("dashboard")
    return render(request, "employees/form.html", {"form": form, "page_title": "Изменить сотрудника", "employee": employee})


@login_required
@permission_required("employees.view_employee", raise_exception=True)
def employee_detail(request, employee_id):
    employee = get_object_or_404(Employee.objects.select_related("department", "position"), pk=employee_id)
    return render(request, "employees/detail.html", {"employee": employee})


@login_required
@permission_required("employees.add_employee", raise_exception=True)
@require_http_methods(["GET", "POST"])
def csv_import(request):
    form = CSVImportForm()
    preview = None
    errors = []
    if request.method == "POST" and "confirm" in request.POST:
        draft = request.session.get(IMPORT_DRAFT_KEY)
        if not draft or draft["token"] != request.POST["confirm"] or draft["expires"] <= time():
            errors.append("Предпросмотр устарел. Загрузите CSV повторно.")
        else:
            request.session.pop(IMPORT_DRAFT_KEY, None)
            try:
                import_records(draft["rows"], request.user)
            except ValidationError as error:
                errors.extend(error.messages)
            except IntegrityError:
                errors.append("Данные изменились во время импорта. Загрузите CSV повторно.")
            else:
                messages.success(request, f"Импортировано сотрудников: {len(draft['rows'])}.")
                return redirect("employee_list" if request.user.has_perm("employees.view_employee") else "employee_csv_import")
    else:
        request.session.pop(IMPORT_DRAFT_KEY, None)
        if request.method == "POST":
            form = CSVImportForm(request.POST, request.FILES)
            if form.is_valid():
                upload = form.cleaned_data["file"]
                rows, errors = read_records(upload)
                if not errors:
                    errors = check_records(rows, request.user)
                if not errors:
                    token = uuid4().hex
                    request.session[IMPORT_DRAFT_KEY] = {
                        "token": token, "rows": rows, "expires": time() + IMPORT_DRAFT_LIFETIME,
                    }
                    preview = {"token": token, "rows": rows[:15], "count": len(rows), "name": upload.name}

    return render(request, "employees/import.html", {
        "form": form, "preview": preview, "errors": errors[:MAX_ERRORS],
        "errors_limited": len(errors) >= MAX_ERRORS,
    })
