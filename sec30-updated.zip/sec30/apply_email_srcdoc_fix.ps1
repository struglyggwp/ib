param(
    [string]$ProjectRoot = (Get-Location).Path
)
$ErrorActionPreference = 'Stop'
$renderFile = Join-Path $ProjectRoot 'backend\email_templates\rendering.py'
$formFile = Join-Path $ProjectRoot 'backend\email_templates\forms.py'
foreach ($file in @($renderFile, $formFile)) {
    if (-not (Test-Path -LiteralPath $file)) { throw "File not found: $file" }
}
$encoding = New-Object System.Text.UTF8Encoding($false)
$render = [System.IO.File]::ReadAllText($renderFile)
$form = [System.IO.File]::ReadAllText($formFile)
$helper = @'
def extract_embedded_email(source):
    """Extract HTML email from a webmail viewer export's iframe[srcdoc].

    The extracted markup still goes through the usual email sanitizer.
    """
    if not source or "srcdoc" not in source.lower():
        return source or ""
    outer = BeautifulSoup(source, "html.parser")
    frame = outer.find("iframe", srcdoc=True)
    if frame is None:
        return source
    classes = " ".join(" ".join(node.get("class", [])) for node in outer.find_all(True))
    exported_viewer = "_emails__content__mail_" in classes or "_iframe-wrapper_" in classes
    if not exported_viewer and len(outer.get_text(" ", strip=True)) > 80:
        return source
    embedded = str(frame.get("srcdoc") or "").strip()
    if "<" not in embedded and "&lt;" in embedded:
        embedded = html.unescape(embedded)
    inner = BeautifulSoup(embedded, "html.parser")
    if not embedded or not inner.find(("html", "body", "table", "div", "p", "a", "img", "span")):
        return source
    return embedded


'@
if ($render.Contains('def extract_embedded_email(source):')) {
    Write-Host 'HTML renderer already contains this fix; skipping renderer patch.'
} else {
    $anchor1 = 'def substitute(value, *, escape_values=False):'
    $anchor2 = '    soup = BeautifulSoup(source or "", "html.parser")'
    if (-not $render.Contains($anchor1) -or -not $render.Contains($anchor2)) {
        throw 'This rendering.py has a different structure. Nothing changed. Do not overwrite a newer version.'
    }
    $render = $render.Replace($anchor1, $helper + "`n`n" + $anchor1)
    $render = $render.Replace($anchor2, '    source = extract_embedded_email(source)' + "`n" + $anchor2)
}
if ($form.Contains('from .rendering import extract_embedded_email')) {
    Write-Host 'HTML upload form already contains this fix.'
} else {
    $anchor3 = 'from .models import EmailTemplate'
    $anchor4 = 'return payload.decode(coding)'
    if (-not $form.Contains($anchor3) -or -not $form.Contains($anchor4)) {
        throw 'This forms.py has a different structure. Nothing changed. Do not overwrite a newer version.'
    }
    $form = $form.Replace($anchor3, $anchor3 + "`n" + 'from .rendering import extract_embedded_email')
    $form = $form.Replace($anchor4, 'return extract_embedded_email(payload.decode(coding))')
}
# Backup before any write; an existing backup is never overwritten.
foreach ($pair in @(@($renderFile,$render),@($formFile,$form))) {
    $file = $pair[0]
    $newContents = $pair[1]
    $oldContents = [System.IO.File]::ReadAllText($file)
    if ($oldContents -ne $newContents) {
        $backup = $file + '.before_srcdoc_v0264.bak'
        if (-not (Test-Path -LiteralPath $backup)) {
            [System.IO.File]::Copy($file,$backup)
        }
        [System.IO.File]::WriteAllText($file,$newContents,$encoding)
        Write-Host "Patched: $file"
        Write-Host "Backup:  $backup"
    }
}
Write-Host 'Completed. Rebuild web and worker. No database migrations needed.'
