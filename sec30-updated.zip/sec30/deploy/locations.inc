location /static/ {
    alias /srv/static/;
    expires 1h;
    add_header X-Content-Type-Options nosniff always;
}

# Training tokens are secrets: do not include them in reverse-proxy access logs.
# Do not log tracking tokens or IP/UA for individual email opens.
location /track/open/ {
    access_log off;
    proxy_pass http://web:8000;
    proxy_http_version 1.1;
    proxy_set_header Host $http_host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 30s;
    add_header Referrer-Policy "no-referrer" always;
    add_header Cache-Control "private, no-store, max-age=0" always;
}

# Do not log personal training tokens and downloaded page paths.
location /learn/ {
    access_log off;
    proxy_pass http://web:8000;
    proxy_http_version 1.1;
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 60s;
    add_header Referrer-Policy "no-referrer" always;
    add_header Cache-Control "no-store" always;
}

location / {
    proxy_pass http://web:8000;
    proxy_http_version 1.1;
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;
    proxy_redirect off;
    proxy_read_timeout 60s;
}
