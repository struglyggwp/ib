# Security Awareness Platform v0.22.2

Обновление **с v0.22.1 на v0.22.2**. Данные сотрудников, кампаний, SMTP-рассылок, индивидуальных ссылок и событий сохраняются.

## Что нового

- **«+ Добавить сотрудников»** в карточке выполняющейся кампании и в списке кампаний.
  - Сотрудники выбираются из существующего справочника. Уже участвующие скрыты.
  - Если письма ещё отправляются, новые записи добавляются в очередь.
  - Если очередь закончилась, она возобновляется **только для новых сотрудников**; предыдущим повторно ничего не отправляется.
  - Сохраняются существующие разрешённые домены получателей и ограничения скорости.
- **«■ Остановить»** в списке и карточке кампании. Блокирует неотправленные письма и делает учебные ссылки неактивными. Письма, уже принятые SMTP, вернуть нельзя. Отдельный этап письма, уже находящегося в передаче, может завершиться.
- **«Удалить»** с подтверждением. Убирает кампанию из интерфейса и останавливает её. **Это мягкое удаление**: сведения и история остаются в PostgreSQL для аудита и восстановления.
- Новая миграция `campaigns.0010_campaign_soft_delete`, новые тесты `campaigns.test_lifecycle_v0222`.

## Установка на Windows PowerShell

1. Оставьте прежнюю базу PostgreSQL и узнайте Compose project:

```powershell
cd C:\security_awareness_platform_v0_22_1
docker compose ls
```

2. Используйте **точное имя** проекта, которое показывает `docker compose ls`:

```powershell
$project = "security_awareness_platform_v0_22_1"  # замените, если имя другое
```

3. Создайте резервную копию базы:

```powershell
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness awareness > backup_v0221.sql"
Get-Item .\backup_v0221.sql | Select-Object Name, Length
```

Если значения `POSTGRES_USER`/`POSTGRES_DB` у вас изменены, замените `awareness` в команде соответствующими значениями. Убедитесь, что файл непустой; сохраните его вне каталога, который собираетесь удалить.

4. Распакуйте ZIP в `C:\security_awareness_platform_v0_22_2` (в каталоге должны лежать `docker-compose.yml` и `backend`). Скопируйте прежний `.env`:

```powershell
Copy-Item C:\security_awareness_platform_v0_22_1\.env C:\security_awareness_platform_v0_22_2\.env
cd C:\security_awareness_platform_v0_22_2
```

5. Поднимите новый код с **тем же** `$project`, чтобы использовать существующие Docker volumes:

```powershell
docker compose -p $project --profile mailtest up -d --build
```

Не запускайте `docker compose down -v`: это удаляет volumes вместе с данными.

6. Проверьте миграции и тесты:

```powershell
docker compose -p $project ps
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py showmigrations campaigns
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py test campaigns.test_lifecycle_v0222
docker compose -p $project exec web python manage.py test
```

Миграция `0010_campaign_soft_delete` должна быть применена (символ `[X]` в `showmigrations`). При сбоях см. `docker compose -p $project logs --tail=150 web worker`.

## Проверка в интерфейсе

1. Откройте `http://127.0.0.1:8080/campaigns/`.
2. Для выполняющейся кампании нажмите «+ Сотрудники», выберите одного нового тестового участника и добавьте.
3. Проверьте увеличение числа участников; в Mailpit (`http://127.0.0.1:8025/`) должно появиться **одно новое письмо**, без повтора предыдущим адресатам.
4. Нажмите «■ Стоп»: неотправленные письма будут заблокированы. Попытка добавить новых получателей после остановки будет отклонена.
5. Нажмите «Удалить», подтвердите. Кампания исчезнет из списков, но история останется в базе.

## Техническая граница

Полные Django-тесты и реальная SMTP-отправка не выполнялись при локальной сборке этого ZIP. Статическая проверка синтаксиса и конфигурации проведена. Не начинайте рабочую рассылку до проверки на тестовых получателях.
