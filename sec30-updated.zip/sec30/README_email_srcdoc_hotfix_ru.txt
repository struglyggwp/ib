Исправление HTML-писем из iframe[srcdoc] без замены всего проекта

Причина: экспорт почтового клиента содержит не сам HTML-письма, а обертку
<div><iframe srcdoc="&lt;html&gt;...">. Обработчик удаляет iframe.

Порядок:
1) Скопируйте apply_email_srcdoc_fix.ps1 в C:\sec29.
2) Откройте PowerShell и выполните:

cd C:\sec29
powershell -NoProfile -ExecutionPolicy Bypass -File .\apply_email_srcdoc_fix.ps1 -ProjectRoot C:\sec29

docker compose -p sec29 up -d --build web worker nginx

Если имя Compose-проекта отличается от sec29, замените его.

3) Проверьте реальное извлечение ранее сохраненного письма:

docker compose -p sec29 exec web python manage.py shell -c "from delivery.models import CampaignDispatch; from email_templates.rendering import extract_embedded_email; d=CampaignDispatch.objects.order_by('-created_at').first(); h=extract_embedded_email(d.template_html); print('HTML_LENGTH:', len(h), 'HAS_BODY:', '<body' in h.lower(), 'HAS_TABLE:', '<table' in h.lower(), 'HAS_IMG:', '<img' in h.lower()); print(repr(h[:150]))"

4) Отправьте новое тестовое письмо в Mailpit или контролируемую Zimbra.
Ранее доставленные письма не изменятся.

Скрипт делает резервные копии двух изменяемых модулей и не трогает базу,
сценарии, кампании и HTML-страницы. При несовпадении структуры исходников
скрипт прекращает работу. Тесты на текущей машине пользователя не запускались.
