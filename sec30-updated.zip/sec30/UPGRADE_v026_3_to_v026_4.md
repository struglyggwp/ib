# Обновление v0.26.3 → v0.26.4

1. Распакуйте новый архив в `C:\sec26_v0264`.
2. Скопируйте `.env` из старой рабочей папки, где запущена версия v0.26.3. Не копируйте `.env.example` поверх рабочего `.env`.
3. В PowerShell запустите:

```powershell
cd C:\sec26_v0264
docker compose -p sec29 up -d --build web worker nginx
```

Замените `sec29` фактическим Compose-именем существующего проекта из `docker compose ls -a`. Иначе создастся новая база.

4. Проверка:

```powershell
docker compose -p sec29 exec web python manage.py test email_templates.test_html_srcdoc_v0264
docker compose -p sec29 exec web python manage.py check
```

5. Отправьте новое тестовое письмо на контролируемый ящик через **новую** кампанию. Уже переданные SMTP письма исправить нельзя. В шаблоне и ранее созданной рассылке сохраняются старые данные, но обработчик теперь извлекает их содержимое при отправке.

**Важно:** не выполняйте `down -v`. Миграции не менялись. Если тесты не прошли, смотрите `docker compose -p sec29 logs --tail=100 web worker`.
