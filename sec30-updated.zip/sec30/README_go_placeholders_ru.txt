# Точечное исправление Go-переменных в HTML-письмах

Поддержка: {{.LastName}}, {{.FirstName}}, {{ .FirstName }}, {{.MiddleName}},
{{.Email}}, {{.Department}}, {{.Position}}, {{.CompanyName}}.
Старый формат {{last_name}}, {{first_name}} и остальные сохраняется.

Куда устанавливать: текущий проект C:\sec29 (либо фактическая папка программы).

1. Скопируйте apply_go_placeholders.ps1 в папку проекта.
2. PowerShell:

   cd C:\sec29
   powershell -NoProfile -ExecutionPolicy Bypass -File .\apply_go_placeholders.ps1 -ProjectRoot C:\sec29

3. Пересоберите только web и worker:

   docker compose -p sec29 up -d --build web worker

   Если в docker compose ls -a фактическое имя проекта другое, замените sec29.

4. Проверка:

   docker compose -p sec29 exec web python manage.py check

5. Запустите новую тестовую рассылку с уже загруженным HTML-шаблоном.
   При формировании нового письма имена будут подставлены автоматически.

Патч предварительно проверяет исходники обоих файлов; если их структура
отличается, ничего не перезаписывает. Перед изменением создаёт .bak-копии.
Не затрагивает миграции базы, существующие кампании, данные и исходные HTML-шаблоны.
Уже отправленные письма не изменятся.
