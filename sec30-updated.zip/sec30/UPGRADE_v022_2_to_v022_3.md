# Обновление Security Awareness Platform v0.22.2 → v0.22.3

## Важно: сохранить существующую БД

Поскольку Docker Compose имя проекта определяет имена volumes, **используйте прежний Compose project**.

В PowerShell в старой папке:

```powershell
cd C:\security_awareness_platform_v0_22_2
docker compose ls
$project = "security_awareness_platform_v0_22_2"  # заменить, если в docker compose ls иное имя
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness awareness > backup_v0222.sql"
Get-Item backup_v0222.sql | Select-Object Name,Length
```

Распаковать ZIP в `C:\security_awareness_platform_v0_22_3` и выполнить:

```powershell
Copy-Item C:\security_awareness_platform_v0_22_2\.env C:\security_awareness_platform_v0_22_3\.env
cd C:\security_awareness_platform_v0_22_3
docker compose -p $project --profile mailtest up -d --build
```

Не выполнять `down -v`: удаляет volumes. Если старый Compose-проект тоже запущен, сначала остановите его обычным `docker compose -p $project down`, **без `-v`**.

Проверка:

```powershell
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py test campaigns.test_resume_v0223
docker compose -p $project ps
```

Страница входа: `http://127.0.0.1:8080/admin/login/`.

### Продолжить остановленную кампанию

В карточке кампании после `Остановить` появится кнопка `Продолжить кампанию`. Она вернёт в очередь **только те письма**, которые не успели отправить и были заблокированы действием оператора. SMTP-accepted письма не повторяются, `failed` и неоднозначные `sending` остаются как были. Предыдущая история и токены ссылок сохраняются. Если новых писем нет, вновь открываются существующие учебные ссылки.

### Проверка собственной Zimbra

1. Убедитесь, что Mailpit и реальная Zimbra не используются одновременно для одной и той же проверки.
2. В Zimbra создайте адрес отправителя и тестового получателя в принадлежащем вам почтовом домене; включите SMTP authentication и TLS для submission (обычно 587).
3. В `.env` укажите `SMTP_HOST`, `SMTP_PORT=587`, `SMTP_USE_STARTTLS=1`, `SMTP_USE_SSL=0`, `SMTP_USERNAME`, `SMTP_PASSWORD`, `SMTP_FROM_EMAIL`, `SMTP_TEST_RECIPIENTS` и `SMTP_ALLOWED_RECIPIENT_DOMAINS`.
4. Пересоздайте `web worker`: `docker compose -p $project up -d --force-recreate web worker`.
5. Проверьте `Test-NetConnection <ZIMBRA_HOST> -Port 587` на Windows, затем SMTP диагностику в интерфейсе.
6. Сначала проверьте одиночное техническое письмо только в разрешённый тестовый ящик.

### Внутренний DNS для собственного имени

Чтобы собственное учебное имя `training.example.test` открывало сервер платформы по LAN, настройте его A-запись в **контролируемой внутренней DNS-зоне** с IP компьютера с Docker, например `192.168.1.50`. Убедитесь, что у Nginx опубликован порт `${NGINX_HTTP_PORT:-8080}` на адресе локальной сети, открыт брандмауэр только для нужной подсети, а браузеры используют внутренний DNS. Используйте `http://training.example.test:8080` или выделенный reverse proxy на порту 80 для адреса без порта. Не подменяйте чужие публичные домены.

Пример проверки:

```powershell
Resolve-DnsName training.example.test
Test-NetConnection 192.168.1.50 -Port 8080
curl.exe http://training.example.test:8080/health/
```
