# Обновление до Security Awareness Platform v0.25 на Windows + Docker Desktop

**Исходники новой сборки:** v0.22.4 из последнего доступного полного ZIP. Если каталог `C:\security_awareness_platform_v0_24` содержит дополнительные изменения, сделанные после v0.22.4, их сначала нужно сравнить с новой сборкой, иначе они пропадут. Обновление не изменяет файлы старого каталога.

## 1. Резервная копия, проверка проекта

Откройте PowerShell:

```powershell
cd C:\security_awareness_platform_v0_24
docker compose ls
docker compose ps
```

Обязательно подставьте старое имя Compose-проекта из `docker compose ls`:

```powershell
$project = 'security_awareness_platform_v0_24'
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness -d awareness > backup_before_v025.sql"
Get-Item .\backup_before_v025.sql | Select-Object Name,Length
```

Если файл пустой либо резервное копирование завершилось ошибкой, **не продолжайте обновление**. Если имя БД/пользователь изменены через `.env`, используйте соответствующие значения вместо `awareness`. Не выполняйте `docker compose down -v`.

## 2. Распаковка и настройки

Распакуйте `security_awareness_platform_v0_25.zip` в `C:\security_awareness_platform_v0_25`, чтобы в корне лежали `Dockerfile`, `docker-compose.yml`, `backend`.

```powershell
Copy-Item C:\security_awareness_platform_v0_24\.env C:\security_awareness_platform_v0_25\.env
cd C:\security_awareness_platform_v0_25
```

**Сохраните то же значение `$project`.** Тогда Compose будет использовать прежние PostgreSQL и Redis volumes и обновит контейнеры старого проекта, а не создаст новые базы в другом проекте.

## 3. Сборка и миграции

Для **Zimbra** и внешнего SMTP (Mailpit не требуется):

```powershell
docker compose -p $project up -d --build
```

Для **локального Mailpit**, если TCP 8025 свободен:

```powershell
docker compose -p $project --profile mailtest up -d --build
```

Если TCP 8025 занят старым Mailpit другого проекта, остановите именно старый контейнер либо переназначьте в новом `docker-compose.yml` опубликованный порт интерфейса Mailpit. Не останавливайте чужую БД.

`entrypoint.sh` автоматически делает `python manage.py migrate --noinput` при старте `web`.

```powershell
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py showmigrations scenarios
docker compose -p $project exec web python manage.py test email_templates.test_html_upload_v025 scenarios.test_reintroduced_v025
```

Если используете роль `ИБ-оператор`, переустановите разрешения группы:

```powershell
docker compose -p $project exec web python manage.py setup_awareness_roles
```

Команда обновит разрешения существующих групп, но не назначает пользователей.

## 4. Использование

1. `/templates/new/`: создать шаблон, выбрать HTML-файл `.html/.htm`, указать тему письма и статус «Активный», сохранить; в «Предпросмотре» проверить стили и ссылки.
2. `/scenarios/new/`: создать сценарий, выбрать загруженное письмо, учебную страницу (при необходимости), аудиторию, From и статус «Готов».
3. `/scenarios/`: открыть сценарий, добавить этапы, нажать «Создать кампанию».
4. `/campaigns/new/?scenario=<uuid>`: проверить предварительно заполненные поля и сохранить кампанию.
5. Запустить кампанию из её карточки с существующими ограничениями SMTP; тестировать сначала на собственных адресах.

**Важно:** изменения в письме или сценарии после запуска не переписывают уже подготовленные к отправке сообщения и не меняют отправленные письма.
