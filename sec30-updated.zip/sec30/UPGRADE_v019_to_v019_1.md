# Обновление Security Awareness Platform v0.19 → v0.19.1

## Что исправлено

- `LANDING_ALLOWED_ORIGINS` больше не нужен и не проверяется при создании HTML-страницы или запуске кампании.
- `http://` и `https://` принимаются для локальных имён `.test`, `.internal`, `.lan`, `.home.arpa`, `.localhost`, `localhost` и частных IPv4/IPv6.
- Все зарегистрированные имена учебных страниц обслуживает один Nginx и Django. Добавлять их по одному в `DJANGO_ALLOWED_HOSTS` не нужно.
- Внутренние учебные адреса разрешены только для персональных ссылок и пикселей отслеживания; административную панель по ним открыть нельзя.
- История кампаний, SMTP-отправка, токены, открытие писем и переходы сохранены.
- Модели и миграции v0.19 не менялись, новая миграция не нужна.

## Обновление с сохранением PostgreSQL

Используй в PowerShell **реальное имя работающего проекта** из `docker compose ls`. Пример ниже использует `security_awareness_platform_v0_18`, но имя может отличаться.

```powershell
cd C:\security_awareness_platform_v0_19
docker compose ls
$project = "security_awareness_platform_v0_18"  # ЗАМЕНИ при необходимости
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness awareness > backup_v019.sql"
Get-Item .\backup_v019.sql | Select-Object Name,Length
```

Если архив уже распакован в `C:\security_awareness_platform_v0_19_1`, скопируй настройки:

```powershell
Copy-Item C:\security_awareness_platform_v0_19\.env C:\security_awareness_platform_v0_19_1\.env
cd C:\security_awareness_platform_v0_19_1
# Не нужно удалять старые Docker volumes, не используй down -v.
docker compose -p $project --profile mailtest up -d --build
```

`LANDING_ALLOWED_ORIGINS` можно удалить из `.env`, но его присутствие не мешает. `DJANGO_ALLOWED_HOSTS` продолжает задавать админские имена по желанию, но новые страницы больше не требуют редактировать его.

## Чтобы страница открывалась на другом компьютере

1. Выясни IPv4-адрес Windows-компьютера, где запущен Docker: `ipconfig`. Допустим, это `192.168.1.50`.
2. Для доступа из LAN добавь в `.env`: `NGINX_BIND_ADDRESS=192.168.1.50` и пересоздай Nginx: `docker compose -p $project up -d --force-recreate nginx`.
3. На локальном DNS создай A-запись `training.test -> 192.168.1.50`. Для проверки на одном Windows-клиенте (PowerShell от администратора) можно внести строку `192.168.1.50 training.test` в `C:\Windows\System32\drivers\etc\hosts`.
4. В `/pages/new/` укажи **`http://training.test:8080`**. Обращай внимание на `:8080`: Nginx сейчас публикует порт 8080, а не 80.
5. Если Windows Firewall блокирует соединение, разреши входящий TCP 8080 только из своей частной локальной сети. Не открывай порт в интернете.
6. На ПК сотрудника проверь `http://training.test:8080/learn/<персональный-токен>/` через письмо. Само имя в браузере открывается только при рабочем DNS/hosts, Docker не управляет DNS автоматически.

**Важно:** `https://` на нестандартном имени потребует отдельного TLS-терминатора и доверенного сертификата. Текущий Nginx обслуживает HTTP. Для адреса без `:8080` можно один раз поставить `NGINX_HTTP_PORT=80` в `.env` и пересоздать Nginx, если порт 80 свободен. Для HTTPS нужен отдельный TLS-терминатор и доверенный сертификат.

## Диагностика

```powershell
docker compose -p $project ps
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py test
```

Не переписывай вручную модели или миграции. При ошибке покажи `docker compose -p $project logs --tail=120 web nginx`.
