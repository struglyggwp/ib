﻿# Исправление ошибки PowerShell в патче персонализации

Причина: предыдущий .ps1 был сохранён как UTF-8 без BOM. Windows PowerShell 5.1
иногда считывает его как системную ANSI-кодировку и ломает русскоязычные строки.
Сам PowerShell-патч не выполнился, файлы Django не изменены.

1. Скопируйте apply_go_placeholders.ps1 из этого ZIP в C:\sec30 с заменой старого файла.
2. В PowerShell:
   cd C:\sec30
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\apply_go_placeholders.ps1 -ProjectRoot C:\sec30
   docker compose -p sec30 up -d --build web worker
3. Тест:
   docker compose -p sec30 exec web python manage.py shell -c "from email_templates.rendering import substitute; print(substitute('{{.LastName}} {{.FirstName}}'))"

Ожидается: Иванов Алексей (данные предварительного просмотра).
Не нужно трогать PostgreSQL, Docker volumes или миграции.
