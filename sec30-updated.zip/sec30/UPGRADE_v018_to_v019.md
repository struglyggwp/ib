# Обновление Security Awareness Platform v0.18 → v0.19

Обновление сохраняет ранее созданные кампании, сотрудников, шаблоны, SMTP-настройки, открытые ссылки и события. Ни одного старого файла миграций изменять не нужно.

## 1. Резервная копия PostgreSQL

В **Windows PowerShell** из папки действующей v0.18:

```powershell
cd C:\security_awareness_platform_v0_18
docker compose ls
```

Укажи **точное** имя проекта из `docker compose ls` (если запускал v0.18 без `-p`, вероятно, это `security_awareness_platform_v0_18`):

```powershell
$project = "security_awareness_platform_v0_18"
docker compose -p $project exec -T db pg_dump -U awareness -d awareness -f /tmp/awareness.sql
# Перенести копию из контейнера на Windows:
$db = (docker compose -p $project ps -q db).Trim()
docker cp "${db}:/tmp/awareness.sql" "C:\security_awareness_platform_v0_18\backup_v018.sql"
Get-Item C:\security_awareness_platform_v0_18\backup_v018.sql | Select-Object Name,Length
```

Пароли в вывод не вводи. `POSTGRES_USER`/`POSTGRES_DB` в команде замени, если они у тебя отличаются от `awareness`. Проверь, что SQL-файл не пустой и хранится отдельно от текущей папки перед удалением каких-либо файлов.

## 2. Подготовить новую папку

Распакуй ZIP так, чтобы существовал путь `C:\security_awareness_platform_v0_19\docker-compose.yml`.

```powershell
Copy-Item C:\security_awareness_platform_v0_18\.env C:\security_awareness_platform_v0_19\.env
notepad C:\security_awareness_platform_v0_19\.env
```

Добавь **одну** новую строку для первого теста на том же ПК:

```env
LANDING_ALLOWED_ORIGINS=http://127.0.0.1:8080
```

Это не публичная DNS-проверка, а перечень веб-адресов, которые разрешено вставлять в персональные ссылки. Для отдельного внутреннего имени (пример `training.test`) добавь:

```env
LANDING_ALLOWED_ORIGINS=http://127.0.0.1:8080,http://training.test:8080
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1,training.test
```

Если пользователи переходят со **своих ПК**, не указывай `127.0.0.1` в ссылках для них: это будет их собственный компьютер! Настрой внутренний DNS, где `training.test` указывает на IP Windows/Docker-хоста, и при необходимости:

```env
NGINX_BIND_ADDRESS=192.168.1.50
```

Вместо `192.168.1.50` укажи IP твоего Windows-хоста. Порт 8080 нужно разрешить только доверенным адресам внутренней сети в Windows Firewall. Внешний интернет-порт не открывай. Если используется реальный домен, для него нужен корректный HTTPS и соответствующий сертификат.

## 3. Запуск поверх старых Docker volumes

```powershell
cd C:\security_awareness_platform_v0_18
docker compose -p $project down
cd C:\security_awareness_platform_v0_19
docker compose -p $project --profile mailtest up -d --build
```

`down` без `-v` не удаляет именованные тома. Сохраняй старое имя Compose-проекта при запуске, иначе Docker создаст отдельную базу. Если Mailpit не нужен, можно не указывать `--profile mailtest`.

## 4. Проверить

```powershell
docker compose -p $project ps
docker compose -p $project logs --tail=100 web
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py test
```

После первой загрузки автоматически выполняется миграция `landing_pages.0001_initial` и `campaigns.0007_campaign_landing_page`. Она только добавляет новую таблицу и **необязательную** связь с кампанией. Предыдущие кампании не изменяются.

## 5. Проверить HTML-страницу

1. Открой `http://127.0.0.1:8080/pages/` и нажми «Загрузить HTML».
2. Название: «Учебная страница», выбери `.html` из SingleFile, внутренний адрес `http://127.0.0.1:8080`.
3. Посмотри безопасный предпросмотр.
4. В `http://127.0.0.1:8080/campaigns/new/` выбери письмо, страницу и тестового сотрудника.
5. Запусти кампанию одной кнопкой. Открой полученную ссылку из Mailpit / Zimbra.
6. В отчёте должно появиться событие «Переход по ссылке» с серверным временем. Открытие HTML-письма отслеживается существующим пикселем.

Сохранённый HTML показывается **как статическая учебная копия**, без работающих скриптов, форм отправки, внешних ссылок, сторонних картинок и SVG. CSS и изображения `data:image/png|jpeg|gif|webp` сохраняются по возможности, сложные страницы могут визуально отличаться от оригинала. Ни пароль, ни введённые данные формы не отправляются и не сохраняются.

## Если после обновления 400 Bad Request на учебном домене

Добавь внутреннее имя хоста (без порта) в `DJANGO_ALLOWED_HOSTS` и пересоздай `web` и `worker`:

```powershell
docker compose -p $project --profile mailtest up -d --force-recreate web worker
```

## Если нужен откат

Не удаляй volumes. Останови v0.19 через `docker compose -p $project down`, вернись к исходникам v0.18 и запусти с тем же `$project`. Новые таблицы/колонки остаются в базе и игнорируются старым кодом; для полного отката схемы лучше использовать проверенную SQL-копию и отдельный восстановленный volume. До проверки нельзя делать `down -v`.
