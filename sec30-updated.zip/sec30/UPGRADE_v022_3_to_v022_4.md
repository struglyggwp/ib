# Обновление v0.22.3 → v0.22.4 (Windows PowerShell)

Новая версия исправляет HTML-стили и заменяет ссылки в отправляемом письме персональной учебной ссылкой. Настройки Zimbra, Mailpit, Nginx и данные PostgreSQL сохраняются.

## 1. Проверьте имя работающего Docker Compose проекта

```powershell
cd C:\security_awareness_platform_v0_22_3
docker compose ls
```

В переменной ниже поставьте **имя проекта из команды** (оно может отличаться от имени папки):

```powershell
$project = "security_awareness_platform_v0_22_3"
```

## 2. Резервная копия базы

```powershell
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness awareness > backup_v0223.sql"
Get-Item .\backup_v0223.sql | Select-Object Name,Length
```

Если база называется иначе, возьмите её имя и пользователя из своих настроек PostgreSQL. Проверьте, что резервная копия не пуста и не содержит сообщение об ошибке.

## 3. Установка

Распакуйте `security_awareness_platform_v0_22_4.zip` в `C:\security_awareness_platform_v0_22_4` и перенесите существующий `.env`:

```powershell
Copy-Item C:\security_awareness_platform_v0_22_3\.env C:\security_awareness_platform_v0_22_4\.env
cd C:\security_awareness_platform_v0_22_4
docker compose -p $project --profile mailtest up -d --build
```

`-p $project` нужен для сохранения прежних томов PostgreSQL. **Не используйте `docker compose down -v`**, это удаляет volumes.

## 4. Проверка

```powershell
docker compose -p $project ps
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py test delivery.test_rendering_v0224
```

При необходимости в `docker compose ... logs worker --tail 80` можно увидеть ошибки отправки, если SMTP недоступен.

В интерфейсе откройте «Шаблоны писем → Предпросмотр». CSS из блока `<style>` теперь переносится в inline-стили; текст правил CSS в самом письме показываться не должен.

Для реальной проверки новой генерации сформируйте **новое тестовое письмо для разрешённого получателя в Mailpit**. В уже доставленных письмах CSS/ссылки не обновятся. В новом письме все исходные гиперссылки, включая URL, вставленные обычным текстом, должны вести на персональный `/learn/<token>/`. Если исходных ссылок нет, добавляется стандартная учебная ссылка. Пиксель учёта открытия письма сохраняется.

## Особенности

- HTML-кнопки, реализованные тегом `<a href="...">`, сохраняют текст и оформление, но ведут только на учебный адрес.
- Внешние HTML-формы и скрипты не поддерживаются в письмах (как и раньше).
- Дизайн зависит от поддержки inline CSS почтовым клиентом. Внешние стилевые файлы не загружаются.
- Если в редактор HTML было вставлено *буквально* `body { color:... }` без тега `<style>`, исправьте сам шаблон: код не может отличить такой текст от обычного содержания письма.
