# Security Awareness Platform

Панель для внутренних учебных кампаний. Через неё ведут каталог сотрудников, подготавливают материалы и смотрят отчёты.

## Запуск локально

Нужен Docker с Compose. Скопируйте `.env.example` в `.env` и замените значения `DJANGO_SECRET_KEY`, `DJANGO_SUPERUSER_PASSWORD` и `POSTGRES_PASSWORD` собственными. Для доступа только с этого компьютера установите `NGINX_BIND_ADDRESS=127.0.0.1`.

```console
docker compose --profile mailtest up -d --build
docker compose exec web python manage.py setup_awareness_roles
```

Панель доступна по [http://127.0.0.1:8080/](http://127.0.0.1:8080/), Mailpit — по [http://127.0.0.1:8025/](http://127.0.0.1:8025/). Войдите с учётной записью из `.env`. Группы операторов и аудиторов назначаются пользователям в админке Django. Отправка кампаний при первом запуске выключена.

## Работа в панели

1. Добавьте сотрудников из каталога или проверьте CSV в предпросмотре и подтвердите импорт.
2. Создайте кампанию из готового сценария или выберите свои материалы. Укажите сотрудников и подразделения, сохраните черновик.
3. Проверяйте состояние очереди и статистику в карточке кампании. Отчёт различает приём сообщения SMTP и события обучения.

## Обновление установки

Сделайте резервную копию PostgreSQL. Распакуйте новую версию и перенесите ваш локальный `.env`. Сохраните прежнее имя Compose-проекта из `docker compose ls` и используйте его во всех командах. Именованный том PostgreSQL должен остаться подключённым.

```console
docker compose -p ИМЯ_ПРОЕКТА up -d --build
docker compose -p ИМЯ_ПРОЕКТА exec web python manage.py setup_awareness_roles
docker compose -p ИМЯ_ПРОЕКТА exec web python manage.py check
```

Сценарии обновления с более ранних версий и изменения по выпускам описаны в файлах `UPGRADE_*.md` и `CHANGELOG_*.md`. Предыдущая редакция README сохранена в [истории](docs/README_HISTORY.md).

## Эксплуатация

- [Панель по HTTPS и отдельные учебные адреса](docs/ADMIN_HTTPS.md)
- [Резервное копирование и диагностика](docs/OPERATIONS.md)
- [SMTP и интерпретация событий](docs/ZIMBRA_AND_TRACKING.md)

Если брокер не подтвердил постановку задачи, проверьте статус на экране «Рассылка». После восстановления Redis администратор может вручную выполнить `docker compose exec web python manage.py dispatch_pending`. Команда работает с кампаниями, у которых остались записи в ожидании. Записи, зависшие в состоянии начатой передачи, сверяются с журналом SMTP.

## Тесты и архив

```console
docker compose exec web python manage.py check
docker compose exec web python manage.py makemigrations --check --dry-run
docker compose exec web python manage.py test --noinput
python scripts/package_release.py sec30-release.zip
```

CI запускает те же тесты на PostgreSQL 16. В ZIP включаются исходники и демонстрационные настройки из `.env.example`. Рабочий `.env`, дампы, файлы с расширением `.bak` и сертификаты хранятся за пределами архива.
