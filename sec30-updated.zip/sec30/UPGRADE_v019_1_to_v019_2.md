# Обновление Security Awareness Platform v0.19.1 → v0.19.2

## Что изменилось

Импорт SingleFile больше не запускает HTML-с sanitizer: **байты загруженного HTML сохраняются без изменений** в PostgreSQL (новое поле `landing_pages_landingpage.original_html`). В предпросмотре и по ссылке кампании выдаётся оригинал, включая исходный CSS, изображения, атрибуты, форму и script-теги. При просмотре сохранённого оригинала скрипты и отправка форм остаются **заблокированы браузером**. Во время кампании в выдаваемую копию добавляется изолированный обработчик, который реагирует на нажатие кнопки, ссылки или попытку отправки формы и показывает учебную обратную связь. Значения полей не читаются и не сохраняются; скрипты из загруженного файла не исполняются. При этом никакой HTML-код не вырезается.

Добавлено отдельное событие `page_interacted` для отчёта и CSV; прежние события сохранены.

Исторические страницы, которые раньше были очищены при загрузке, автоматически восстановить невозможно: **загрузите их из исходных SingleFile HTML заново** и выберите новую запись в кампании. Старые кампании и события сохраняются.

## Команды (Windows PowerShell)

```powershell
cd C:\security_awareness_platform_v0_19_1
docker compose ls
# Подставьте действительное имя проекта из docker compose ls
$project = "security_awareness_platform_v0_18"
# Замените имя проекта на ваше!
cmd /c "docker compose -p $project exec -T db pg_dump -U awareness awareness > backup_v0191.sql"
Get-Item .\backup_v0191.sql | Select-Object Name,Length
```

Убедитесь, что файл резервной копии существует и размер больше нуля. Распакуйте архив в `C:\security_awareness_platform_v0_19_2`.

```powershell
Copy-Item C:\security_awareness_platform_v0_19_1\.env C:\security_awareness_platform_v0_19_2\.env
cd C:\security_awareness_platform_v0_19_2
docker compose -p $project --profile mailtest up -d --build
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py makemigrations --check --dry-run
docker compose -p $project exec web python manage.py test
```

Старые Docker volumes не удаляйте: **не используйте** `docker compose down -v`.

## Проверка

1. Откройте `http://127.0.0.1:8080/pages/` и загрузите оригинальный файл HTML.
2. Откройте страницу предпросмотра и убедитесь, что текст, встроенные изображения и оформление присутствуют.
3. Выберите эту страницу в кампании. Формирование персональных ссылок, SMTP, учёт открытий письма и переходов не изменялись.

Ограничения размера HTML (8 МБ), допустимых расширений и адресов локальной сети остались прежними. Полные Django-тесты необходимо выполнить в контейнере.
