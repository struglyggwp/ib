# Обновление Security Awareness Platform v0.26.1 → v0.26.2

## Установка в существующий проект `sec26` на Windows PowerShell

1. Сохраните рабочий `.env` и сделайте резервную копию базы. **Не используйте `docker compose down -v`**.
2. Распакуйте новый ZIP в `C:\sec26_v0262`.
3. Перенесите `.env`:

```powershell
Copy-Item C:\sec26_v0261\.env C:\sec26_v0262\.env
cd C:\sec26_v0262
docker compose -p sec26 up -d --build web worker nginx
docker compose -p sec26 ps
docker compose -p sec26 exec web python manage.py check
```

Если предыдущий рабочий каталог был `C:\sec26`, замените исходный путь для `.env` на него. Если фактическое имя Docker Compose-проекта не `sec26`, возьмите его из `docker compose ls`.

Не нужно запускать профиль Mailpit заново, если внешний порт 8025 занят старым экземпляром.

## Проверка

```powershell
docker compose -p sec26 exec web python manage.py test landing_pages.test_compat_v0262 delivery.test_fallback_v0262
docker compose -p sec26 logs --tail 100 web worker nginx
```

1. Создайте тестовую кампанию с одной разрешённой тестовой учётной записью.
2. Откройте **персональную ссылку** вида `/learn/<uuid>/`, а не предпросмотр из панели.
3. Нажмите кнопку. Ожидается страница «Это была учебная проверка» и регистрация события без данных формы.
4. Отправьте новое письмо с HTML-шаблоном. Старые сообщения Mailpit не меняются.
5. Если HTML-письмо всё равно отображается некорректно, приложите сам `.html`. Веб-экспорт со скриптами и изображениями в CSS не гарантирует корректного отображения в почтовом клиенте.

Изоляция загруженных страниц и запрет передачи введённых паролей сохранены намеренно.
