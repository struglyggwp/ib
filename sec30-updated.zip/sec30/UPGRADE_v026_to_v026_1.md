# Обновление Security Awareness Platform v0.26 → v0.26.1

## 1. Условия

Инструкция рассчитана на каталог `C:\sec26` и существующий Docker Compose проект `sec26` из предыдущих запусков. Если имя другое, проверьте `docker compose ls` и скорректируйте `$project`. **Не удаляйте Docker volumes.**

## 2. Распаковка и настройки

Распакуйте ZIP v0.26.1 в `C:\sec26_v0261`, затем в PowerShell:

```powershell
$project = 'sec26'
Copy-Item C:\sec26\.env C:\sec26_v0261\.env
cd C:\sec26_v0261
```

Если старая база нужна, используйте **тот же** `-p sec26`, иначе Docker создаст новые пустые volumes. Для резервной копии базы выполните из старого каталога перед обновлением:

```powershell
cd C:\sec26
cmd /c "docker compose -p sec26 exec -T db pg_dump -U awareness -d awareness > backup_v026.sql"
Get-Item .\backup_v026.sql | Select Name,Length
```

Если POSTGRES_USER или POSTGRES_DB в `.env` отличаются, подставьте фактические значения. Резервная копия не должна быть пустой.

## 3. Запуск

```powershell
cd C:\sec26_v0261
docker compose -p sec26 up -d --build web worker nginx
docker compose -p sec26 ps
```

Эти команды не требуют запуска нового Mailpit и потому не пытаются занять порт 8025. Ранее запущенный Mailpit остаётся в том же Docker-проекте. Если есть иная конфигурация или нужный отдельный Mailpit, включайте профиль `mailtest` осознанно.

## 4. Проверки

```powershell
docker compose -p sec26 exec web python manage.py check
docker compose -p sec26 exec web python manage.py test email_templates.test_html_upload_v025 landing_pages.tests delivery.test_rendering_v0261
```

Затем заново загрузите HTML-письмо через «Шаблоны» (или замените файл в редактировании существующего шаблона), откройте предпросмотр и отправьте новое тестовое письмо в Mailpit. Уже отправленные письма не изменяются.

Откройте учебную ссылку тестовой кампании. Внизу больше нет панели. Нажатие кнопки или учебной формы по-прежнему фиксируется без сохранения значений, введённых в форму.

## 5. Если оформление по-прежнему отличается

Для email по-прежнему требуется совместимая с почтовыми клиентами верстка. Картинки по относительным ссылкам или на недоступных внешних серверах не будут работать. Для анализа нужны сам загружаемый HTML и скриншот письма после отправки.
