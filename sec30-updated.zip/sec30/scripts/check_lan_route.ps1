param(
    [string]$HostName = "dudud.lan",
    [int]$Port = 8080,
    [string]$PlatformIP = ""
)

$ErrorActionPreference = "Continue"
Write-Host "=== Проверка имени и доступа Security Awareness Platform ==="
Write-Host "Имя: $HostName; порт: $Port"
Write-Host "(1) DNS:"
Resolve-DnsName -Name $HostName -Type A -ErrorAction Continue | Select-Object Name,IPAddress | Format-Table -AutoSize
Write-Host "(2) Доступность TCP:"
Test-NetConnection -ComputerName $HostName -Port $Port -InformationLevel Detailed | Select-Object ComputerName,RemoteAddress,TcpTestSucceeded | Format-List
$uri = "http://${HostName}:${Port}/track/open/00000000-0000-0000-0000-000000000000.gif"
Write-Host "(3) Путь учёта открытий (ожидается HTTP 200 image/gif, даже для неизвестного токена):"
curl.exe --noproxy '*' -sS -o NUL -w 'HTTP %{http_code}; IP %{remote_ip}\n' $uri
if ($PlatformIP) {
    Write-Host "(4) Обход DNS только для диагностики (НЕ меняет DNS/hosts):"
    curl.exe --noproxy '*' --resolve "${HostName}:${Port}:${PlatformIP}" -sS -o NUL -w 'HTTP %{http_code}; IP %{remote_ip}\n' $uri
}
Write-Host "Если (4) даёт 200, а (3) нет: исправьте внутренний DNS/hosts."
Write-Host "Если оба не 200, проверьте порт Docker, Nginx и зарегистрированный URL страницы."
