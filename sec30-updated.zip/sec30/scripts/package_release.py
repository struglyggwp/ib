"""Build a ZIP from the project sources and public deployment examples."""
import argparse
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = {
    ".dockerignore",
    ".env.example",
    ".gitignore",
    "Dockerfile",
    "README.md",
    "README_RU.txt",
    "README_email_srcdoc_hotfix_ru.txt",
    "README_go_placeholders_ru.txt",
    "apply_email_srcdoc_fix.ps1",
    "apply_go_placeholders.ps1",
    "docker-compose.yml",
    "entrypoint.sh",
    "requirements.txt",
}
SOURCE_TYPES = {
    ".github": {".yml", ".yaml"},
    "backend": {".py", ".html", ".css", ".js", ".svg", ".png", ".jpg", ".woff2"},
    "deploy": {".conf", ".inc", ".template", ".yml"},
    "docs": {".md"},
    "examples": {".html", ".csv"},
    "scripts": {".ps1", ".py"},
}
EXCLUDED_DIRS = {"__pycache__", "media", "staticfiles", "tls"}


def is_release_source(path):
    if len(path.parts) == 1:
        return path.name in ROOT_FILES or (
            path.suffix == ".md" and path.name.startswith(("CHANGELOG_", "UPGRADE_"))
        )
    top, *subpath = path.parts
    suffixes = SOURCE_TYPES.get(top)
    if not suffixes or path.suffix not in suffixes:
        return False
    return not any(
        name.startswith(".") or name.lower().startswith("backup")
        or ".bak" in name.lower() or name.lower() in EXCLUDED_DIRS
        for name in subpath
    )


def build_release(destination):
    sources = [
        path.relative_to(ROOT)
        for path in ROOT.rglob("*")
        if path.is_file() and not path.is_symlink() and is_release_source(path.relative_to(ROOT))
    ]
    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(destination, "x", compression=ZIP_DEFLATED) as archive:
        for relative in sorted(sources):
            archive.write(ROOT / relative, (Path("sec30") / relative).as_posix())
    return len(sources)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="Path to a new release ZIP")
    args = parser.parse_args()
    print(f"{args.output}: {build_release(args.output)} files")
