﻿param(
    [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'

function Replace-Once([string]$Text, [string]$Old, [string]$New, [string]$Label) {
    if (-not $Text.Contains($Old)) {
        throw "Не найден ожидаемый участок: $Label. Файлы проекта отличаются; ничего не изменено."
    }
    if ($Text.IndexOf($Old) -ne $Text.LastIndexOf($Old)) {
        throw "Ожидаемый участок встречается несколько раз: $Label. Ничего не изменено."
    }
    return $Text.Replace($Old, $New)
}

$goAliases = @'
_GO_ALIASES = {
    ".FirstName": "first_name",
    ".LastName": "last_name",
    ".MiddleName": "middle_name",
    ".Email": "email",
    ".Department": "department",
    ".Position": "position",
    ".CompanyName": "company_name",
}
'@

$deliveryPath = Join-Path $ProjectRoot 'backend\delivery\rendering.py'
$previewPath  = Join-Path $ProjectRoot 'backend\email_templates\rendering.py'
foreach ($path in @($deliveryPath, $previewPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Файл не найден: $path. Проверьте -ProjectRoot; ничего не изменено."
    }
}

$delivery = [System.IO.File]::ReadAllText($deliveryPath, [System.Text.Encoding]::UTF8).Replace("`r`n", "`n")
$preview  = [System.IO.File]::ReadAllText($previewPath,  [System.Text.Encoding]::UTF8).Replace("`r`n", "`n")

if ($delivery.Contains('_GO_ALIASES') -and $preview.Contains('_GO_ALIASES')) {
    Write-Host 'Поддержка Go-переменных уже присутствует. Изменения не нужны.' -ForegroundColor Green
    exit 0
}
if ($delivery.Contains('_GO_ALIASES') -or $preview.Contains('_GO_ALIASES')) {
    throw 'Патч применён частично. Проверьте файлы вручную; ничего не изменено.'
}

$oldDeliveryPattern = '_VARIABLE = re.compile(r"{{\s*([a-z_]+)\s*}}")'
$newDeliveryPattern = '_VARIABLE = re.compile(r"{{\s*(\.[A-Za-z_][A-Za-z0-9_]*|[a-z_]+)\s*}}")' + "`n" + $goAliases
$newDelivery = Replace-Once $delivery $oldDeliveryPattern $newDeliveryPattern 'delivery: regex'

$oldDeliveryReplace = @'
    def replace(source, escape=False):
        return _VARIABLE.sub(
            lambda m: (html.escape(str(values[m.group(1)]), quote=True) if escape else str(values[m.group(1)]))
            if m.group(1) in values else m.group(0), source or ""
        )
'@
$newDeliveryReplace = @'
    def replace(source, escape=False):
        def replacement(match):
            key = _GO_ALIASES.get(match.group(1), match.group(1))
            if key not in values:
                return match.group(0)
            value = str(values[key])
            return html.escape(value, quote=True) if escape else value
        return _VARIABLE.sub(replacement, source or "")
'@
$newDelivery = Replace-Once $newDelivery $oldDeliveryReplace $newDeliveryReplace 'delivery: replace'

$oldPreviewPattern = '_TOKEN = re.compile(r"{{\s*([a-z_]+)\s*}}")'
$newPreviewPattern = '_TOKEN = re.compile(r"{{\s*(\.[A-Za-z_][A-Za-z0-9_]*|[a-z_]+)\s*}}")' + "`n" + $goAliases
$newPreview = Replace-Once $preview $oldPreviewPattern $newPreviewPattern 'email_templates: regex'

$oldPreviewKey = "        key = match.group(1)`n        if key not in VARIABLES:"
$newPreviewKey = "        key = _GO_ALIASES.get(match.group(1), match.group(1))`n        if key not in VARIABLES:"
$newPreview = Replace-Once $newPreview $oldPreviewKey $newPreviewKey 'email_templates: preview'

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$deliveryBackup = "$deliveryPath.bak_go_aliases_$stamp"
$previewBackup = "$previewPath.bak_go_aliases_$stamp"
Copy-Item -LiteralPath $deliveryPath -Destination $deliveryBackup -ErrorAction Stop
Copy-Item -LiteralPath $previewPath -Destination $previewBackup -ErrorAction Stop

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
try {
    [System.IO.File]::WriteAllText($deliveryPath, $newDelivery, $utf8NoBom)
    [System.IO.File]::WriteAllText($previewPath, $newPreview, $utf8NoBom)
} catch {
    Copy-Item -LiteralPath $deliveryBackup -Destination $deliveryPath -Force
    Copy-Item -LiteralPath $previewBackup -Destination $previewPath -Force
    throw
}
Write-Host 'Готово: поддержка {{.FirstName}} и {{.LastName}} добавлена.' -ForegroundColor Green
Write-Host "Резервные копии: $deliveryBackup ; $previewBackup"
