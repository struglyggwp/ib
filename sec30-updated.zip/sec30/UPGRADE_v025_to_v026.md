# Обновление v0.25 → v0.26

1. Не удаляйте Docker volumes. Для сохранения данных используйте тот же Compose project (`-p`), что и в старой сборке. Проверьте `docker compose ls`.
2. Перед изменениями сделайте резервную копию PostgreSQL средствами `pg_dump`.
3. Распакуйте новую версию в отдельную папку, перенесите `.env` из предыдущей версии.
4. В папке новой версии выполните:

```powershell
# Замените sec26 на имя существующего проекта из docker compose ls
$project = "sec26"
docker compose -p $project config --quiet
docker compose -p $project up -d --build
# Для локального Mailpit, только если внешний порт 8025 свободен:
# docker compose -p $project --profile mailtest up -d --build
docker compose -p $project exec web python manage.py check
docker compose -p $project exec web python manage.py test campaigns.test_scenario_selection_v026 scenarios.test_reintroduced_v025
```

5. Откройте `/campaigns/new/`. Выберите сценарий со статусом «Готов». После обновления страницы отметьте сотрудников и/или подразделения, задайте название и нажмите «Сохранить кампанию».
6. Откройте созданную кампанию и проверьте имя сценария, ревизию, участников, письмо и страницу, затем запустите тестовую отправку.

**Важно:** если в `sec26` работает Mailpit с портом 8025, не запускайте второй экземпляр с тем же портом. SMTP разрешения и ограничения получателей не менялись. Проверяйте сначала на своих тестовых адресах.
