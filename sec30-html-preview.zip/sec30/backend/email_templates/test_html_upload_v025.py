import base64
from html import escape

from bs4 import BeautifulSoup

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse

from .models import EmailTemplate
from .rendering import sanitize_email_html


class HtmlEmailImportTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_superuser(
            username="html-importer", email="importer@example.test", password="test-password-123"
        )
        self.client.force_login(self.user)

    def _post(self, file):
        return self.client.post(reverse("email_template_create"), {
            "name": "Импортированное письмо", "category": "awareness", "tags": "training",
            "subject": "Учебное уведомление", "html_body": "", "text_body": "",
            "description": "", "status": "active", "html_file": file,
        })

    def test_upload_stores_html_and_preview_removes_active_content(self):
        original = ('<html><head><style>p {color:red}</style></head><body>'
                    '<p>Здравствуйте!</p><a href="https://example.org">Читать</a>'
                    '<script>alert(1)</script></body></html>')
        response = self._post(SimpleUploadedFile("notice.html", original.encode(), content_type="text/html"))
        self.assertEqual(response.status_code, 302)
        template = EmailTemplate.objects.get(name="Импортированное письмо")
        self.assertEqual(template.html_body, original)
        safe, replaced = sanitize_email_html(template.html_body, training_url="https://training.example.test/learn/token/")
        self.assertEqual(replaced, 1)
        self.assertIn('href="https://training.example.test/learn/token/"', safe)
        self.assertNotIn("<script", safe)
        self.assertNotIn("https://example.org", safe)
        self.assertIn("color", safe)

    def test_upload_with_windows_1251_declaration(self):
        original = '<html><head><meta charset="windows-1251"></head><body>Тест</body></html>'
        response = self._post(SimpleUploadedFile("letter.htm", original.encode("cp1251")))
        self.assertEqual(response.status_code, 302)
        self.assertIn("Тест", EmailTemplate.objects.get(name="Импортированное письмо").html_body)

    def test_rejects_wrong_extension(self):
        response = self._post(SimpleUploadedFile("payload.exe", b"<p>Test</p>"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "только файлы .html и .htm")
        self.assertFalse(EmailTemplate.objects.exists())

    def test_rejects_oversized_upload(self):
        response = self._post(SimpleUploadedFile("big.html", b"a" * (5 * 1024 * 1024 + 1)))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "превышает 5 МБ")
        self.assertFalse(EmailTemplate.objects.exists())

    def test_upload_edits_existing_template_without_losing_other_fields(self):
        tpl = EmailTemplate.objects.create(
            name="Старое письмо", subject="Осталась тема", html_body="<p>Старое</p>", created_by=self.user
        )
        response = self.client.post(reverse("email_template_edit", args=[tpl.pk]), {
            "name": "Старое письмо", "category": "general", "tags": "",
            "subject": "Осталась тема", "html_body": "<p>Старое</p>", "text_body": "",
            "description": "", "status": "active",
            "html_file": SimpleUploadedFile("replacement.html", '<p>Новое</p>'.encode()),
        })
        self.assertEqual(response.status_code, 302)
        tpl.refresh_from_db()
        self.assertEqual(tpl.html_body, "<p>Новое</p>")
        self.assertEqual(tpl.subject, "Осталась тема")


    def test_uploaded_viewer_export_previews_actual_message_without_saving(self):
        raster = base64.b64encode(b"sample").decode()
        message = (
            '<style>.letter { color: red; }</style><table><tr><td class="letter">'
            'Привет, {{.FirstName}}'
            '<img src="https://images.example.test/logo.jpg" alt="Логотип">'
            f'<img src="data:image/png;base64,{raster}" alt="Встроенное изображение">'
            '<script>alert(1)</script></td></tr></table>'
        )
        wrapped = f'<iframe srcdoc="{escape(message, quote=True)}"></iframe>'
        response = self.client.post(reverse("email_template_upload_preview"), {
            "html_file": SimpleUploadedFile("message.html", wrapped.encode()),
        })

        self.assertEqual(response.status_code, 200)
        document = response.json()["document"]
        preview = BeautifulSoup(document, "html.parser")
        self.assertEqual(preview.select_one("td").get_text(strip=True), "Привет, Алексей")
        self.assertIn("color: red", preview.select_one("td")["style"])
        self.assertIn("img-src data:", document)
        self.assertIn(f"data:image/png;base64,{raster}", document)
        self.assertNotIn("images.example.test", document)
        self.assertNotIn("alert(1)", document)
        self.assertFalse(EmailTemplate.objects.exists())

    def test_preview_rejects_wrong_extension_and_requires_edit_permission(self):
        url = reverse("email_template_upload_preview")
        response = self.client.post(url, {"html_file": SimpleUploadedFile("message.txt", b"<p>Text</p>")})
        self.assertEqual(response.status_code, 400)
        self.assertIn(".html", response.json()["error"])

        visitor = get_user_model().objects.create_user(username="preview-visitor")
        self.client.force_login(visitor)
        response = self.client.post(url, {"html_file": SimpleUploadedFile("message.html", b"<p>Text</p>")})
        self.assertEqual(response.status_code, 403)

    def test_saved_template_opens_as_rendered_email(self):
        response = self._post(SimpleUploadedFile("letter.html", '<p>Текст письма</p>'.encode()))
        preview = self.client.get(response["Location"])
        page = BeautifulSoup(preview.content, "html.parser")
        frame = page.select_one("iframe.email-preview-frame")
        self.assertTrue(frame.has_attr("sandbox"))
        self.assertIn("<p>Текст письма</p>", frame["srcdoc"])
        self.assertIsNone(page.select_one("pre.code-preview"))
