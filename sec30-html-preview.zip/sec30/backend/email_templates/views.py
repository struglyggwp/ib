from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Q
from django.db.models.deletion import ProtectedError
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.loader import render_to_string
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods, require_POST

from .forms import EmailTemplateForm, read_email_html
from .models import EmailTemplate
from .rendering import VARIABLES, preview_html, substitute


def _preview_document(fragment, text=""):
    if not (fragment.strip() or text.strip()):
        return ""
    return render_to_string("email_templates/preview_document.html", {
        "fragment": fragment,
        "text": text,
    })


def _render_form(request, form, page_title, item=None):
    # Browsers clear the file input after a failed save. Keep the rendered
    # preview visible and explain that the file must be selected again.
    uploaded_html = getattr(form, "cleaned_data", {}).get("html_file")
    source = uploaded_html if uploaded_html is not None else form["html_body"].value()
    return render(request, "email_templates/form.html", {
        "form": form,
        "page_title": page_title,
        "item": item,
        "preview_document": _preview_document(preview_html(source), substitute(form["text_body"].value())),
        "reselect_file": uploaded_html is not None,
    })


@login_required
@require_POST
@never_cache
def template_upload_preview(request):
    if not (request.user.has_perm("email_templates.add_emailtemplate")
            or request.user.has_perm("email_templates.change_emailtemplate")):
        raise PermissionDenied
    uploaded = request.FILES.get("html_file")
    if uploaded is None:
        return JsonResponse({"error": "Выберите HTML-файл."}, status=400)
    try:
        source = read_email_html(uploaded)
    except ValidationError as error:
        return JsonResponse({"error": error.messages[0]}, status=400)
    document = _preview_document(preview_html(source))
    if not document:
        return JsonResponse({"error": "В файле нет содержимого для предпросмотра."}, status=422)
    return JsonResponse({"document": document})


@login_required
@permission_required("email_templates.view_emailtemplate", raise_exception=True)
def template_list(request):
    qs = EmailTemplate.objects.select_related("created_by")
    query = request.GET.get("q", "").strip()
    category = request.GET.get("category", "").strip()
    status = request.GET.get("status", "").strip()
    if query:
        qs = qs.filter(
            Q(name__icontains=query) | Q(subject__icontains=query)
            | Q(tags__icontains=query) | Q(description__icontains=query)
        )
    if category in EmailTemplate.Category.values:
        qs = qs.filter(category=category)
    if status in EmailTemplate.Status.values:
        qs = qs.filter(status=status)
    return render(request, "email_templates/list.html", {
        "templates": qs, "query": query, "selected_category": category,
        "selected_status": status, "categories": EmailTemplate.Category.choices,
        "statuses": EmailTemplate.Status.choices,
    })


@login_required
@permission_required("email_templates.add_emailtemplate", raise_exception=True)
@require_http_methods(["GET", "POST"])
def template_create(request):
    form = EmailTemplateForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.created_by = request.user
        item.save()
        messages.success(request, "Шаблон письма создан.")
        if request.user.has_perm("email_templates.view_emailtemplate"):
            return redirect("email_template_detail", template_id=item.pk)
        return redirect("dashboard")
    return _render_form(request, form, "Новый шаблон")


@login_required
@permission_required("email_templates.view_emailtemplate", raise_exception=True)
def template_detail(request, template_id):
    item = get_object_or_404(EmailTemplate.objects.select_related("created_by"), pk=template_id)
    return render(request, "email_templates/detail.html", {
        "item": item,
        "preview_subject": substitute(item.subject),
        "preview_document": _preview_document(preview_html(item.html_body), substitute(item.text_body)),
    })


@login_required
@permission_required("email_templates.change_emailtemplate", raise_exception=True)
@require_http_methods(["GET", "POST"])
def template_edit(request, template_id):
    item = get_object_or_404(EmailTemplate, pk=template_id)
    form = EmailTemplateForm(request.POST or None, request.FILES or None, instance=item)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Изменения шаблона сохранены.")
        if request.user.has_perm("email_templates.view_emailtemplate"):
            return redirect("email_template_detail", template_id=item.pk)
        return redirect("dashboard")
    return _render_form(request, form, "Изменить шаблон", item)


@login_required
@permission_required("email_templates.delete_emailtemplate", raise_exception=True)
@require_POST
def template_delete(request, template_id):
    item = get_object_or_404(EmailTemplate, pk=template_id)
    try:
        item.delete()
    except ProtectedError:
        messages.error(request, "Нельзя удалить шаблон, используемый сценарием. Сначала смените шаблон в сценарии.")
        if request.user.has_perm("email_templates.view_emailtemplate"):
            return redirect("email_template_detail", template_id=item.pk)
        return redirect("dashboard")
    messages.success(request, "Шаблон удалён.")
    return redirect("email_template_list" if request.user.has_perm("email_templates.view_emailtemplate") else "dashboard")


@login_required
@permission_required("email_templates.view_emailtemplate", raise_exception=True)
def template_preview(request, template_id):
    item = get_object_or_404(EmailTemplate, pk=template_id)
    fragment = preview_html(item.html_body)
    text = substitute(item.text_body)
    return render(request, "email_templates/preview.html", {
        "item": item,
        "preview_subject": substitute(item.subject),
        "preview_text": text if fragment.strip() else "",
        "preview_document": _preview_document(fragment, text),
        "variables": VARIABLES,
    })
