"""Safely import uploaded .html/.htm files into an email template.

The original HTML remains an editable database field; sending sanitizes it using
email_templates.rendering. Uploads never become public files or executable assets.
"""
import re
from pathlib import Path

from django import forms

from .models import EmailTemplate
from .rendering import extract_embedded_email

MAX_EMAIL_HTML_BYTES = 5 * 1024 * 1024


def decode_uploaded_html(payload):
    """Accept UTF-8 (including BOM) or explicitly declared Windows-1251."""
    if b"\x00" in payload:
        raise forms.ValidationError("HTML-файл содержит двоичные данные.")
    head = payload[:4096].lower()
    coding = "utf-8-sig"
    if re.search(rb"charset\s*=\s*['\"]?\s*(?:windows-1251|cp1251)\b", head):
        coding = "cp1251"
    try:
        return extract_embedded_email(payload.decode(coding))
    except UnicodeDecodeError as exc:
        raise forms.ValidationError("Не удалось прочитать файл. Сохраните его в UTF-8 или Windows-1251 с meta charset.") from exc


def read_email_html(uploaded):
    if Path(uploaded.name).suffix.lower() not in (".html", ".htm"):
        raise forms.ValidationError("Допускаются только файлы .html и .htm.")
    if uploaded.size > MAX_EMAIL_HTML_BYTES:
        raise forms.ValidationError("HTML-файл превышает 5 МБ.")
    data = uploaded.read(MAX_EMAIL_HTML_BYTES + 1)
    if len(data) > MAX_EMAIL_HTML_BYTES:
        raise forms.ValidationError("HTML-файл превышает 5 МБ.")
    return decode_uploaded_html(data)


class EmailTemplateForm(forms.ModelForm):
    html_file = forms.FileField(
        label="Загрузить HTML-письмо (.html, .htm)", required=False,
        widget=forms.ClearableFileInput(attrs={"class": "form-control", "accept": ".html,.htm,text/html"}),
        help_text="До 5 МБ. При сохранении файл заменит HTML-версию письма.",
    )

    class Meta:
        model = EmailTemplate
        fields = ("name", "category", "tags", "subject", "html_body", "text_body", "description", "status")
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Например, Приглашение на обучение"}),
            "category": forms.Select(attrs={"class": "form-select"}),
            "tags": forms.TextInput(attrs={"class": "form-control", "placeholder": "обучение, безопасность, внутренние коммуникации"}),
            "subject": forms.TextInput(attrs={"class": "form-control"}),
            "html_body": forms.Textarea(attrs={"class": "form-control code-area", "rows": 14, "spellcheck": "false"}),
            "text_body": forms.Textarea(attrs={"class": "form-control", "rows": 10}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "status": forms.Select(attrs={"class": "form-select"}),
        }
        help_texts = {
            "html_body": "Безопасный HTML и базовые CSS. Все ссылки заменяются персональной учебной ссылкой; если их нет, ссылка добавится автоматически.",
            "text_body": "Текстовая альтернатива для почтовых клиентов без HTML.",
            "tags": "Несколько тегов разделяйте запятыми.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.order_fields((
            "name", "category", "tags", "subject", "html_file", "html_body",
            "text_body", "description", "status",
        ))

    def clean_tags(self):
        raw = self.cleaned_data.get("tags", "")
        tags = []
        seen = set()
        for item in raw.split(","):
            tag = " ".join(item.split())
            key = tag.casefold()
            if tag and key not in seen:
                tags.append(tag)
                seen.add(key)
        return ", ".join(tags)

    def clean_html_file(self):
        uploaded = self.cleaned_data.get("html_file")
        return read_email_html(uploaded) if uploaded is not None else None

    def clean(self):
        cleaned = super().clean()
        html_from_file = cleaned.get("html_file")
        if html_from_file is not None:
            cleaned["html_body"] = html_from_file
        if not cleaned.get("html_body", "").strip() and not cleaned.get("text_body", "").strip():
            raise forms.ValidationError("Заполните хотя бы одну версию письма: HTML или текстовую, либо загрузите HTML-файл.")
        return cleaned
