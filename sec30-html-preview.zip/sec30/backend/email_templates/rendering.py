"""Email-safe rendering: inline common CSS and route all clickable links to training.

Templates are saved unchanged. Only the prepared email copy is rewritten.
Remote scripts, forms, media and active HTML are removed before delivery.
"""
import base64
import binascii
import hashlib
import html
import re
from urllib.parse import urlsplit

import bleach
import tinycss2
try:
    from bleach.css_sanitizer import CSSSanitizer
except ImportError:  # Legacy Bleach compatibility for offline renderer tests.
    CSSSanitizer = None
from bs4 import BeautifulSoup, NavigableString, Tag

VARIABLES = {
    "first_name": "Алексей",
    "last_name": "Иванов",
    "middle_name": "Сергеевич",
    "email": "alexey.ivanov@example.test",
    "department": "Отдел обучения",
    "position": "Специалист",
    "company_name": "Учебная организация",
}

_TOKEN = re.compile(r"{{\s*(\.[A-Za-z_][A-Za-z0-9_]*|[a-z_]+)\s*}}")
_GO_ALIASES = {
    ".FirstName": "first_name",
    ".LastName": "last_name",
    ".MiddleName": "middle_name",
    ".Email": "email",
    ".Department": "department",
    ".Position": "position",
    ".CompanyName": "company_name",
}
# Text nodes containing an unlinked URL must be rewritten as well. Otherwise
# email clients could autolink the external destination themselves.
_VISIBLE_URL = re.compile(r"(?i)(?<![\w@])(?:https?://|www\.)[^\s<>\"'\u00ab\u00bb]+")
_VISIBLE_URL_END = '.,;:!?)]}'
_ALLOWED_CSS = frozenset({
    "color", "background", "background-color", "font", "font-family", "font-size", "font-weight",
    "font-style", "line-height", "letter-spacing", "text-align", "text-decoration",
    "vertical-align", "margin", "margin-top", "margin-bottom", "margin-left", "margin-right",
    "padding", "padding-top", "padding-bottom", "padding-left", "padding-right",
    "width", "min-width", "max-width", "height", "min-height", "max-height",
    "border", "border-top", "border-bottom", "border-left", "border-right",
    "border-color", "border-width", "border-style", "border-radius", "box-shadow",
    "display", "border-collapse", "border-spacing", "white-space", "text-transform",
    "overflow-wrap", "word-break", "float", "direction", "list-style-type",
})
_CSS_SANITIZER = CSSSanitizer(allowed_css_properties=_ALLOWED_CSS) if CSSSanitizer else None
ALLOWED_TAGS = set(bleach.sanitizer.ALLOWED_TAGS) | {
    "p", "br", "div", "span", "h1", "h2", "h3", "h4", "table", "thead", "tbody",
    "tr", "td", "th", "strong", "em", "u", "hr", "blockquote", "ul", "ol", "li",
    "center", "small", "sup", "sub", "img",
}
ALLOWED_ATTRIBUTES = {
    "*": ["style", "title", "width", "height", "align", "valign", "dir", "bgcolor"],
    "a": ["href", "style", "title"],
    "img": ["src", "alt", "width", "height", "style", "title"],
    "table": ["cellpadding", "cellspacing", "border", "width", "align", "style", "bgcolor"],
    "td": ["colspan", "rowspan", "style", "title", "width", "height", "align", "valign", "bgcolor"],
    "th": ["colspan", "rowspan", "style", "title", "width", "height", "align", "valign", "bgcolor"],
}
_DROP_WITH_CONTENTS = {"script", "iframe", "object", "embed", "svg", "math", "form", "input", "button", "textarea", "select", "video", "audio", "template", "title", "meta", "link", "base"}


def extract_embedded_email(source):
    """Unwrap an HTML-email viewer export with a real email in iframe[srcdoc].

    Browsers store the original document as HTML-escaped srcdoc, while email
    clients remove the iframe entirely. This operation is deliberately separate
    from the later email sanitizer: extracted markup is *never* sent raw.
    """
    if not source or "srcdoc" not in source.lower():
        return source or ""
    outer = BeautifulSoup(source, "html.parser")
    frame = outer.find("iframe", srcdoc=True)
    if frame is None:
        return source
    classes = " ".join(" ".join(node.get("class", [])) for node in outer.find_all(True))
    exported_viewer = "_emails__content__mail_" in classes or "_iframe-wrapper_" in classes
    # Preserve an intentional mixed-content document; do not discard its text.
    if not exported_viewer and len(outer.get_text(" ", strip=True)) > 80:
        return source
    embedded = str(frame.get("srcdoc") or "").strip()
    if "<" not in embedded and "&lt;" in embedded:
        embedded = html.unescape(embedded)
    inner = BeautifulSoup(embedded, "html.parser")
    if not embedded or not inner.find(("html", "body", "table", "div", "p", "a", "img", "span")):
        return source
    return embedded


def substitute(value, *, escape_values=False):
    def replace(match):
        key = _GO_ALIASES.get(match.group(1), match.group(1))
        if key not in VARIABLES:
            return match.group(0)
        result = VARIABLES[key]
        return html.escape(result, quote=True) if escape_values else result
    return _TOKEN.sub(replace, value or "")


def _safe_declarations(source):
    """Explicit CSS property allowlist and no URL-bearing CSS expressions."""
    result = {}
    for decl in tinycss2.parse_declaration_list(source or "", skip_whitespace=True, skip_comments=True):
        if decl.type != "declaration" or decl.lower_name not in _ALLOWED_CSS:
            continue
        value = tinycss2.serialize(decl.value).strip()
        # Never allow external loading, browser expressions, or CSS directives.
        if not value or re.search(r"(?i)url\s*\(|expression\s*\(|@|\\", value):
            continue
        result[decl.lower_name] = value
    return result


def _inline_styles(soup):
    css_rules = []
    for element in list(soup.find_all("style")):
        stylesheet = element.get_text() or ""
        for rule in tinycss2.parse_stylesheet(stylesheet, skip_whitespace=True, skip_comments=True):
            if rule.type != "qualified-rule":
                continue
            selector = tinycss2.serialize(rule.prelude).strip()
            props = _safe_declarations(tinycss2.serialize(rule.content))
            if not props or not selector or len(selector) > 200:
                continue
            # A simple selectors subset suffices for standard email templates;
            # no pseudo classes/functions or external stylesheet fetches.
            if not re.fullmatch(r"[\w.\-#\s>,]+", selector):
                continue
            css_rules.append((selector, props))
        element.decompose()

    by_node = {}
    for selector, props in css_rules:
        try:
            selected = soup.select(selector)
        except Exception:  # malformed or unsupported CSS selectors
            continue
        for node in selected:
            if not isinstance(node, Tag):
                continue
            by_node.setdefault(id(node), {}).update(props)

    for node in soup.find_all(True):
        declarations = by_node.get(id(node), {})
        declarations.update(_safe_declarations(node.get("style", "")))  # inline wins
        if declarations:
            node["style"] = "; ".join(f"{k}: {v}" for k, v in declarations.items())
        elif node.has_attr("style"):
            del node["style"]


def _rewrite_visible_urls(soup, training_url):
    """Convert bare URL text to safe training links before mail-client autolinking."""
    count = 0
    for node in list(soup.find_all(string=True)):
        if not isinstance(node, NavigableString) or node.parent is None:
            continue
        if node.parent.name in ("a", "style", "script"):
            continue
        source = str(node)
        matches = list(_VISIBLE_URL.finditer(source))
        if not matches:
            continue
        pieces = []
        offset = 0
        for match in matches:
            candidate = match.group(0)
            matched_url = candidate.rstrip(_VISIBLE_URL_END)
            if not matched_url:
                continue
            pieces.append(NavigableString(source[offset:match.start()]))
            link = soup.new_tag("a", href=training_url)
            link.string = "Открыть учебную страницу"
            pieces.append(link)
            pieces.append(NavigableString(candidate[len(matched_url):]))
            offset = match.end()
            count += 1
        if pieces:
            pieces.append(NavigableString(source[offset:]))
            for item in pieces:
                node.insert_before(item)
            node.extract()
    return count


# Keep uploaded images without letting arbitrary file/javascript URLs reach clients.
_DATA_IMAGE = re.compile(r"(?is)^data:image/(png|jpeg|gif|webp);base64,([A-Za-z0-9+/=\s]+)$")
_MAX_IMAGE_BYTES = 3 * 1024 * 1024
_MAX_IMAGE_COUNT = 24


def _prepare_images(soup, image_assets=None, *, allow_remote_images=True):
    """Allow regular HTTPS images and supported embedded raster images.

    Sending converts embedded data images to MIME CID attachments. Preview keeps
    data URLs locally. No SVG, JS URLs, file URLs or HTML-in-data are accepted.
    """
    seen = {}
    for img in list(soup.find_all("img")):
        src = str(img.get("src") or "").strip()
        data_image = _DATA_IMAGE.fullmatch(src)
        if data_image:
            try:
                data = base64.b64decode(re.sub(r"\s+", "", data_image.group(2)), validate=True)
            except (ValueError, binascii.Error):
                img.decompose()
                continue
            if not data or len(data) > _MAX_IMAGE_BYTES:
                img.decompose()
                continue
            if image_assets is not None:
                digest = hashlib.sha256(data).hexdigest()[:32]
                cid = f"training-image-{digest}@local"
                if cid not in seen and len(image_assets) >= _MAX_IMAGE_COUNT:
                    img.decompose()
                    continue
                if cid not in seen:
                    image_assets.append((cid, "image/" + data_image.group(1).lower(), data))
                    seen[cid] = True
                img["src"] = "cid:" + cid
        else:
            # Untrusted HTML must not embed local/network resources with exotic
            # schemes; only absolute HTTP(S) image references are usable.
            try:
                url = urlsplit(src)
                good = (url.scheme.lower() in ("http", "https") and url.hostname
                        and not url.username and not url.password and len(src) <= 2048
                        and not any(ord(c) < 32 for c in src))
            except ValueError:
                good = False
            if not good:
                img.decompose()
                continue
            if not allow_remote_images:
                del img["src"]
        # Prevent browser-initiated srcset fetches from third-party destinations.
        for attr in ("srcset", "data-src", "data-srcset", "onerror", "onload"):
            img.attrs.pop(attr, None)


def sanitize_email_html(source, *, training_url="#", image_assets=None, allow_remote_images=True):
    """Returns (safe HTML fragment, replaced clickable-link count).

    `training_url` must be generated by the platform, never from HTML content.
    Preview uses a non-navigating anchor (#).
    """
    source = extract_embedded_email(source)
    soup = BeautifulSoup(source or "", "html.parser")
    # Webpage exports sometimes put their static fallback in <noscript>.
    # Preserve its text/content, but sanitize the resulting markup below.
    for fallback in list(soup.find_all("noscript")):
        fallback.unwrap()
    # An HTML email must not post forms, but preserve its explanatory contents.
    for form in list(soup.find_all("form")):
        form.unwrap()
    for button in list(soup.find_all("button")):
        replacement = soup.new_tag("a", href=training_url)
        replacement.string = button.get_text(" ", strip=True) or "Открыть учебную страницу"
        button.replace_with(replacement)
    for node in list(soup.find_all(True)):
        if node.name in _DROP_WITH_CONTENTS:
            node.decompose()
    _inline_styles(soup)
    _prepare_images(soup, image_assets=image_assets, allow_remote_images=allow_remote_images)

    replaced = 0
    for anchor in soup.find_all("a"):
        if anchor.has_attr("href"):
            old_href = str(anchor.get("href") or "")
            anchor["href"] = training_url
            replaced += 1
            visible = anchor.get_text(" ", strip=True)
            if _VISIBLE_URL.fullmatch(visible) or visible == old_href:
                anchor.clear()
                anchor.string = "Открыть учебную страницу"
    replaced += _rewrite_visible_urls(soup, training_url)

    body = soup.body or soup
    # `body` style does not survive fragment rendering, so keep a wrapper.
    body_contents = body.decode_contents() if isinstance(body, Tag) else str(body)
    if getattr(body, "name", "") == "body" and body.get("style"):
        body_contents = '<div style="' + html.escape(body["style"], quote=True) + '">' + body_contents + '</div>'

    cleaner_kwargs = dict(
        tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRIBUTES,
        protocols={"https", "http", "data", "cid"}, strip=True, strip_comments=True,
    )
    if _CSS_SANITIZER is not None:
        cleaner_kwargs["css_sanitizer"] = _CSS_SANITIZER
    else:
        cleaner_kwargs["styles"] = list(_ALLOWED_CSS)
    safe = bleach.clean(body_contents, **cleaner_kwargs)
    return safe, replaced


def preview_html(value):
    safe, _ = sanitize_email_html(substitute(value, escape_values=True), allow_remote_images=False)
    return safe
