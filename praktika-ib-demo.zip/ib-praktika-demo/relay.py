"""Publish a local port for the app on Docker's internal network."""

import asyncio


async def forward(source, destination):
    while data := await asyncio.wait_for(source.read(65536), timeout=30):
        destination.write(data)
        await asyncio.wait_for(destination.drain(), timeout=30)
    destination.write_eof()


async def relay(client_reader, client_writer):
    upstream_writer = None
    try:
        try:
            upstream_reader, upstream_writer = await asyncio.wait_for(
                asyncio.open_connection("app", 8080), timeout=3
            )
        except (OSError, TimeoutError):
            client_writer.write(
                b"HTTP/1.1 503 Service Unavailable\r\n"
                b"Connection: close\r\nContent-Length: 0\r\n\r\n"
            )
            await asyncio.wait_for(client_writer.drain(), timeout=3)
            return

        async with asyncio.TaskGroup() as streams:
            streams.create_task(forward(client_reader, upstream_writer))
            streams.create_task(forward(upstream_reader, client_writer))
    except* (OSError, TimeoutError):
        pass
    finally:
        client_writer.close()
        if upstream_writer is not None:
            upstream_writer.close()


async def main():
    server = await asyncio.start_server(relay, "0.0.0.0", 8080)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
