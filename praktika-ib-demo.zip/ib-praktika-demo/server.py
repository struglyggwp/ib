"""HTTP and SQLite service for the self-contained synthetic training demo."""

from contextlib import closing
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import sqlite3
from urllib.parse import unquote, urlsplit


mimetypes.add_type("font/woff", ".woff")

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "dist"
DATABASE = Path(os.environ.get("DATA_DIR", ROOT / "data")) / "demo.sqlite3"

SCENARIOS = [
    {
        "id": "gov",
        "name": "Портал заявлений",
        "category": "Госуслуги",
        "description": "Учебное уведомление о статусе заявления в вымышленном ведомстве.",
        "sender": "Учебный портал заявлений",
        "subject": "Учебное заявление обновлено",
        "body": "Это письмо из демокампании. В учебном портале появился новый статус вымышленного заявления. Откройте страницу упражнения, чтобы продолжить.",
        "prompt": "Введите учебный код, показанный на странице.",
    },
    {
        "id": "hr",
        "name": "Кадровый документ",
        "category": "Кадры",
        "description": "Упражнение на проверку уведомления о кадровом документе.",
        "sender": "Демоотдел кадров",
        "subject": "Учебный документ для ознакомления",
        "body": "Это письмо из демокампании. В демонстрационном кабинете доступен вымышленный кадровый документ. Откройте страницу упражнения, чтобы продолжить.",
        "prompt": "Введите учебный код, показанный на странице.",
    },
    {
        "id": "it",
        "name": "Проверка доступа",
        "category": "ИТ-служба",
        "description": "Учебное уведомление о доступе к внутреннему кабинету.",
        "sender": "Демонстрационная ИТ-служба",
        "subject": "Учебное уведомление о доступе",
        "body": "Это письмо из демокампании. В учебном кабинете доступна проверка условной заявки. Откройте страницу упражнения, чтобы продолжить.",
        "prompt": "Введите учебный код, показанный на странице.",
    },
    {
        "id": "delivery",
        "name": "Статус отправления",
        "category": "Доставка",
        "description": "Упражнение на проверку уведомления о вымышленной посылке.",
        "sender": "Учебная служба доставки",
        "subject": "Обновление по учебному отправлению",
        "body": "Это письмо из демокампании. У вымышленной посылки появился новый статус. Откройте страницу упражнения, чтобы продолжить.",
        "prompt": "Введите учебный код, показанный на странице.",
    },
]
GROUPS = [
    {"id": "ops", "name": "Операции"},
    {"id": "it", "name": "ИТ"},
    {"id": "hr", "name": "Кадры"},
    {"id": "finance", "name": "Финансы"},
]
GROUP_MEMBERS = [
    [
        "Анна Морозова", "Михаил Соколов", "Дарья Крылова",
        "Артём Волков", "Елена Рябова", "Олег Миронов",
        "Нина Гаврилова", "Денис Петров", "Алиса Новикова",
    ],
    [
        "Иван Белов", "Ксения Тихонова", "Сергей Орлов",
        "Полина Лебедева", "Максим Ковалёв", "Ирина Беляева",
        "Виктор Панов", "Яна Семёнова", "Павел Медведев",
    ],
    [
        "Вера Данилова", "Глеб Фролов", "Лидия Карпова",
        "Мария Климова", "Илья Савельев", "Ольга Зорина",
        "Тимур Громов", "Софья Денисова", "Роман Юдин",
    ],
    [
        "Виктория Романова", "Кирилл Назаров", "Алина Макарова",
        "Андрей Игнатов", "Светлана Руднева", "Юлия Маслова",
        "Пётр Осипов", "Марина Горина", "Лев Соловьёв",
    ],
]

PEOPLE = []
for group, names in zip(GROUPS, GROUP_MEMBERS, strict=True):
    for name in names:
        person_id = len(PEOPLE) + 1
        PEOPLE.append({
            "id": person_id,
            "name": name,
            "group_id": group["id"],
            "initials": "".join(part[0] for part in name.split()),
            "email": f"participant-{person_id:02}@training.test",
        })

SCENARIO_IDS = {scenario["id"] for scenario in SCENARIOS}
GROUP_IDS = {group["id"] for group in GROUPS}
EVENTS = {
    "opened": ("opened_at", None),
    "clicked": ("clicked_at", "opened_at"),
    "input": ("input_at", "clicked_at"),
}
RECIPIENT_SQL = "person_id, scenario_id, opened_at, clicked_at, input_at"
MAX_JSON_BYTES = 16 * 1024

SCHEMA = """
CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'completed'))
);
CREATE TABLE IF NOT EXISTS recipients (
    campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    person_id INTEGER NOT NULL,
    scenario_id TEXT NOT NULL,
    opened_at TEXT,
    clicked_at TEXT CHECK (clicked_at IS NULL OR opened_at IS NOT NULL),
    input_at TEXT CHECK (input_at IS NULL OR clicked_at IS NOT NULL),
    PRIMARY KEY (campaign_id, person_id)
);
"""


class RequestError(Exception):
    def __init__(self, status, message):
        self.status = status
        self.message = message


def timestamp(moment=None):
    if moment is None:
        moment = datetime.now(timezone.utc)
    return moment.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def connect():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def initialize_database():
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
    with closing(connect()) as db, db:
        db.executescript(SCHEMA)
        db.execute("BEGIN IMMEDIATE")
        if db.execute("SELECT 1 FROM campaigns LIMIT 1").fetchone():
            return

        seed = [
            ("Вводное упражнение", 5, "completed", {"ops": "gov", "finance": "delivery"}, (13, 7, 2)),
            ("Проверка кадров и ИТ", 12, "completed", {"hr": "hr", "it": "it"}, (14, 8, 3)),
            ("Осенняя проверка ИБ", 18, "active", {
                "ops": "gov", "it": "it", "hr": "hr", "finance": "delivery",
            }, (26, 14, 4)),
        ]
        for name, day, status, assignments, counts in seed:
            started = datetime(2026, 11, day, 6, 30, tzinfo=timezone.utc)
            campaign_id = db.execute(
                "INSERT INTO campaigns (name, created_at, status) VALUES (?, ?, ?)",
                (name, timestamp(started), status),
            ).lastrowid
            members = [person for person in PEOPLE if person["group_id"] in assignments]
            for index, person in enumerate(members):
                rank = (index * 13 + 5) % len(members)
                opened = started + timedelta(hours=index % 7, minutes=(index * 11) % 45 + 4)
                clicked = opened + timedelta(minutes=index % 9 + 1)
                entered = clicked + timedelta(seconds=index * 3 + 5)
                db.execute(
                    """INSERT INTO recipients
                       (campaign_id, person_id, scenario_id, opened_at, clicked_at, input_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        campaign_id,
                        person["id"],
                        assignments[person["group_id"]],
                        timestamp(opened) if rank < counts[0] else None,
                        timestamp(clicked) if rank < counts[1] else None,
                        timestamp(entered) if rank < counts[2] else None,
                    ),
                )


def state():
    with closing(connect()) as db, db:
        db.execute("BEGIN")
        campaigns = {
            row["id"]: {**dict(row), "recipients": []}
            for row in db.execute(
                "SELECT id, name, created_at, status FROM campaigns ORDER BY id DESC"
            )
        }
        for row in db.execute(
            f"SELECT campaign_id, {RECIPIENT_SQL} FROM recipients ORDER BY person_id"
        ):
            recipient = dict(row)
            campaigns[recipient.pop("campaign_id")]["recipients"].append(recipient)
    return {"scenarios": SCENARIOS, "groups": GROUPS, "people": PEOPLE, "campaigns": list(campaigns.values())}


def expected_keys(value, keys):
    if not isinstance(value, dict) or value.keys() != keys:
        raise RequestError(HTTPStatus.BAD_REQUEST, "Проверьте поля запроса.")


def json_object(entries):
    parsed = dict(entries)
    if len(parsed) != len(entries):
        raise ValueError("Duplicate JSON properties")
    return parsed


def create_campaign(data):
    expected_keys(data, {"name", "assignments"})
    name = data["name"]
    if not isinstance(name, str) or not 1 <= len(name.strip()) <= 90 or not name.strip().isprintable():
        raise RequestError(HTTPStatus.BAD_REQUEST, "Введите название кампании длиной от 1 до 90 символов.")
    rows = data["assignments"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= len(GROUPS):
        raise RequestError(HTTPStatus.BAD_REQUEST, "Назначьте сценарии хотя бы одной группе.")

    assignments = {}
    for row in rows:
        expected_keys(row, {"scenario_id", "groups"})
        scenario_id, groups = row["scenario_id"], row["groups"]
        if not isinstance(scenario_id, str) or scenario_id not in SCENARIO_IDS:
            raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите сценарий из каталога.")
        if not isinstance(groups, list) or not 1 <= len(groups) <= len(GROUPS):
            raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите группы для сценария.")
        for group in groups:
            if not isinstance(group, str) or group not in GROUP_IDS:
                raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите группу демоучастников.")
            if group in assignments:
                raise RequestError(HTTPStatus.BAD_REQUEST, "Назначьте каждой группе один сценарий.")
            assignments[group] = scenario_id

    with closing(connect()) as db, db:
        campaign_id = db.execute(
            "INSERT INTO campaigns (name, created_at, status) VALUES (?, ?, 'active')",
            (name.strip(), timestamp()),
        ).lastrowid
        db.executemany(
            "INSERT INTO recipients (campaign_id, person_id, scenario_id) VALUES (?, ?, ?)",
            [
                (campaign_id, person["id"], assignments[person["group_id"]])
                for person in PEOPLE if person["group_id"] in assignments
            ],
        )
    return {"id": campaign_id}


def record_event(data):
    expected_keys(data, {"campaign_id", "person_id", "event"})
    campaign_id, person_id, event = data["campaign_id"], data["person_id"], data["event"]
    if type(campaign_id) is not int or not 0 < campaign_id < 2**63:
        raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите кампанию.")
    if type(person_id) is not int or not 1 <= person_id <= len(PEOPLE):
        raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите демоучастника.")
    if not isinstance(event, str) or event not in EVENTS:
        raise RequestError(HTTPStatus.BAD_REQUEST, "Выберите учебное событие.")
    column, prerequisite = EVENTS[event]

    with closing(connect()) as db, db:
        db.execute("BEGIN IMMEDIATE")
        recipient = db.execute(
            f"SELECT {RECIPIENT_SQL} FROM recipients WHERE campaign_id = ? AND person_id = ?",
            (campaign_id, person_id),
        ).fetchone()
        if recipient is None:
            raise RequestError(HTTPStatus.NOT_FOUND, "Участника нет в этой кампании.")
        result = dict(recipient)
        if result[column] is not None:
            return result
        campaign = db.execute("SELECT status FROM campaigns WHERE id = ?", (campaign_id,)).fetchone()
        if campaign["status"] != "active":
            raise RequestError(HTTPStatus.CONFLICT, "Кампания завершена.")
        if prerequisite and result[prerequisite] is None:
            raise RequestError(HTTPStatus.CONFLICT, "Выполните предыдущий шаг в демопочте.")
        result[column] = timestamp()
        db.execute(
            f"UPDATE recipients SET {column} = ? WHERE campaign_id = ? AND person_id = ?",
            (result[column], campaign_id, person_id),
        )
    return result


class DemoHandler(BaseHTTPRequestHandler):
    server_version = "TrainingDemo"
    sys_version = ""

    def log_message(self, format, *args):
        # Keep request paths, browser metadata and submitted values out of access logs.
        return

    def respond(self, status, body, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; script-src 'self'; style-src 'self'; "
            "img-src 'self'; font-src 'self'; connect-src 'self'; "
            "base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
        )
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def respond_json(self, status, value):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.respond(status, body, "application/json; charset=utf-8")

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            path = urlsplit(self.path).path
            if path == "/healthz":
                with closing(connect()) as db:
                    db.execute("SELECT 1 FROM campaigns LIMIT 1").fetchone()
                self.respond_json(HTTPStatus.OK, {"status": "ok"})
                return
            if path == "/api/state":
                self.respond_json(HTTPStatus.OK, state())
                return
            if path == "/":
                path = "/index.html"
            relative_path = Path(unquote(path).lstrip("/"))
            if any(part.startswith(".") for part in relative_path.parts):
                raise RequestError(HTTPStatus.NOT_FOUND, "Страница не найдена.")
            asset = (STATIC / relative_path).resolve()
            if not asset.is_relative_to(STATIC) or not asset.is_file():
                raise RequestError(HTTPStatus.NOT_FOUND, "Страница не найдена.")
            content_type = mimetypes.guess_type(asset.name)[0] or "application/octet-stream"
            if content_type.startswith("text/"):
                content_type += "; charset=utf-8"
            self.respond(HTTPStatus.OK, asset.read_bytes(), content_type)
        except RequestError as error:
            self.respond_json(error.status, {"error": error.message})
        except (sqlite3.Error, OSError):
            self.respond_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "Данные пока недоступны."})

    def json_body(self):
        fetch_site = self.headers.get("Sec-Fetch-Site")
        origin = self.headers.get("Origin")
        if fetch_site and fetch_site != "same-origin":
            raise RequestError(HTTPStatus.FORBIDDEN, "Откройте приложение напрямую.")
        if not fetch_site and origin:
            try:
                origin_url = urlsplit(origin)
            except ValueError:
                raise RequestError(HTTPStatus.FORBIDDEN, "Откройте приложение напрямую.") from None
            if origin_url.scheme not in {"http", "https"} or origin_url.netloc != self.headers.get("Host"):
                raise RequestError(HTTPStatus.FORBIDDEN, "Откройте приложение напрямую.")
        if self.headers.get_content_type() != "application/json":
            raise RequestError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Ожидается запрос JSON.")
        if self.headers.get("Transfer-Encoding"):
            raise RequestError(HTTPStatus.BAD_REQUEST, "Укажите длину запроса.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise RequestError(HTTPStatus.BAD_REQUEST, "Укажите длину запроса.") from None
        if not 0 < length <= MAX_JSON_BYTES:
            raise RequestError(HTTPStatus.BAD_REQUEST, "Размер запроса вне допустимого диапазона.")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise RequestError(HTTPStatus.BAD_REQUEST, "Запрос получен не полностью.")
        try:
            return json.loads(raw.decode("utf-8"), object_pairs_hook=json_object)
        except (UnicodeError, ValueError, RecursionError):
            raise RequestError(HTTPStatus.BAD_REQUEST, "Проверьте формат JSON.") from None

    def do_POST(self):
        try:
            if self.path == "/api/campaigns":
                self.respond_json(HTTPStatus.CREATED, create_campaign(self.json_body()))
            elif self.path == "/api/demo-event":
                self.respond_json(HTTPStatus.OK, record_event(self.json_body()))
            else:
                raise RequestError(HTTPStatus.NOT_FOUND, "Действие не найдено.")
        except RequestError as error:
            self.respond_json(error.status, {"error": error.message})
        except (sqlite3.Error, OSError):
            self.respond_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "Данные пока недоступны."})


if __name__ == "__main__":
    initialize_database()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8080"))
    with ThreadingHTTPServer((host, port), DemoHandler) as server:
        print(f"Практика ИБ · http://{host}:{port}", flush=True)
        server.serve_forever()
